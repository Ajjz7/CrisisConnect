import { useState, useEffect, useCallback, useRef } from 'react';
import axios from 'axios';

/**
 * Custom hook for making API requests with axios
 * 
 * @param {string} url - The initial URL to fetch data from
 * @param {Object} options - Configuration options for the request
 * @param {string} options.method - HTTP method (GET, POST, PUT, DELETE)
 * @param {Object} options.headers - Request headers
 * @param {Object|null} options.data - Request body data for POST/PUT requests
 * @param {boolean} options.withCredentials - Whether to include credentials in the request
 * @param {boolean} options.autoFetch - Whether to fetch data automatically on mount
 * @returns {Object} - State and functions for handling the fetch request
 */
const useFetch = (url, options = {}) => {
  // Default options
  const defaultOptions = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    },
    data: null,
    withCredentials: true,
    autoFetch: true
  };

  // Merge default options with user-provided options
  const fetchOptions = { ...defaultOptions, ...options };
  
  // States for data, loading, and error
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // Use a ref to store the latest url and options for use in callbacks
  const urlRef = useRef(url);
  const optionsRef = useRef(fetchOptions);
  
  // Update refs when props change
  useEffect(() => {
    urlRef.current = url;
    optionsRef.current = { ...defaultOptions, ...options };
  }, [url, options]);

  // Fetch data function (memoized with useCallback)
  const fetchData = useCallback(async (customUrl, customOptions = {}) => {
    // Allow overriding url and options for manual fetches
    const requestUrl = customUrl || urlRef.current;
    const requestOptions = { ...optionsRef.current, ...customOptions };
    
    if (!requestUrl) {
      setError(new Error('No URL provided'));
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      const { method, headers, data, withCredentials } = requestOptions;
      
      const config = {
        method,
        url: requestUrl,
        headers,
        withCredentials
      };
      
      // Add data to request if provided
      if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
        config.data = data;
      }
      
      const response = await axios(config);
      setData(response.data);
      
      return response.data;
    } catch (err) {
      setError(err);
      throw err; // Allow caller to catch and handle error
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial fetch on mount (if autoFetch is true)
  useEffect(() => {
    if (fetchOptions.autoFetch && url) {
      fetchData();
    }
  }, [fetchData, url]);

  // Refetch data with current URL and options
  const refetch = useCallback(() => {
    return fetchData();
  }, [fetchData]);

  // Post data to the URL
  const postData = useCallback((data, customUrl) => {
    return fetchData(customUrl, {
      method: 'POST',
      data
    });
  }, [fetchData]);

  // Put data to the URL
  const putData = useCallback((data, customUrl) => {
    return fetchData(customUrl, {
      method: 'PUT',
      data
    });
  }, [fetchData]);

  // Delete request to the URL
  const deleteData = useCallback((customUrl) => {
    return fetchData(customUrl, {
      method: 'DELETE'
    });
  }, [fetchData]);

  // Function to clear previous data
  const clearData = useCallback(() => {
    setData(null);
  }, []);

  // Function to clear previous error
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Return state and functions for component to use
  return {
    data,
    loading,
    error,
    fetchData,
    refetch,
    postData,
    putData,
    deleteData,
    clearData,
    clearError
  };
};

export default useFetch;