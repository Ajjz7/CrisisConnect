import { useContext, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthContext from '../contexts/AuthContext';

/**
 * Custom hook for authentication functionality
 * 
 * This hook provides a wrapper around the AuthContext with additional
 * utility functions for common authentication operations
 * 
 * @returns {Object} Authentication state and functions
 */
const useAuth = () => {
  const authContext = useContext(AuthContext);
  const navigate = useNavigate();

  // If no context is available, throw an error
  if (!authContext) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  // Extract values from context
  const { 
    currentUser, 
    loading, 
    error, 
    register, 
    login, 
    socialLogin, 
    logout, 
    isAuthenticated 
  } = authContext;

  /**
   * Register a new user and redirect to login page
   * 
   * @param {Object} userData - User registration data
   * @param {Object} options - Additional options
   * @param {string} options.redirectTo - Path to redirect after successful registration
   * @returns {Promise} Registration result
   */
  const registerUser = useCallback(async (userData, options = {}) => {
    try {
      const result = await register(userData);
      
      // Redirect after successful registration
      if (options.redirectTo) {
        navigate(options.redirectTo, { 
          state: { registration: 'success' } 
        });
      } else {
        navigate('/login', { 
          state: { registration: 'success' } 
        });
      }
      
      return result;
    } catch (err) {
      // Let the caller handle the error
      throw err;
    }
  }, [register, navigate]);

  /**
   * Log in a user and redirect to dashboard
   * 
   * @param {Object} credentials - User login credentials
   * @param {Object} options - Additional options
   * @param {string} options.redirectTo - Path to redirect after successful login
   * @returns {Promise} Login result
   */
  const loginUser = useCallback(async (credentials, options = {}) => {
    try {
      const result = await login(credentials);
      
      // Redirect after successful login
      if (options.redirectTo) {
        navigate(options.redirectTo);
      } else {
        navigate('/dashboard');
      }
      
      return result;
    } catch (err) {
      // Let the caller handle the error
      throw err;
    }
  }, [login, navigate]);

  /**
   * Log in with a social provider
   * 
   * @param {string} provider - Social provider (google, facebook, linkedin)
   */
  const socialLoginUser = useCallback((provider) => {
    socialLogin(provider);
  }, [socialLogin]);

  /**
   * Log out a user and redirect to home page
   * 
   * @param {Object} options - Additional options
   * @param {string} options.redirectTo - Path to redirect after successful logout
   * @returns {Promise} Logout result
   */
  const logoutUser = useCallback(async (options = {}) => {
    try {
      await logout();
      
      // Redirect after successful logout
      if (options.redirectTo) {
        navigate(options.redirectTo);
      } else {
        navigate('/');
      }
    } catch (err) {
      console.error('Logout error:', err);
      throw err;
    }
  }, [logout, navigate]);

  /**
   * Check if user is authenticated and redirect if not
   * 
   * @param {string} redirectTo - Path to redirect if not authenticated
   * @returns {boolean} Authentication status
   */
  const requireAuth = useCallback((redirectTo = '/login') => {
    if (!loading && !isAuthenticated) {
      navigate(redirectTo, { 
        state: { from: location.pathname } 
      });
      return false;
    }
    return isAuthenticated;
  }, [isAuthenticated, loading, navigate]);

  /**
   * Check if user has required role
   * 
   * @param {string|string[]} requiredRole - Required role(s)
   * @returns {boolean} Whether user has required role
   */
  const hasRole = useCallback((requiredRole) => {
    if (!currentUser) return false;
    
    if (Array.isArray(requiredRole)) {
      return requiredRole.includes(currentUser.role);
    }
    
    return currentUser.role === requiredRole;
  }, [currentUser]);

  /**
   * Check if user has required role and redirect if not
   * 
   * @param {string|string[]} requiredRole - Required role(s)
   * @param {string} redirectTo - Path to redirect if not authorized
   * @returns {boolean} Authorization status
   */
  const requireRole = useCallback((requiredRole, redirectTo = '/dashboard') => {
    if (!loading && isAuthenticated) {
      if (!hasRole(requiredRole)) {
        navigate(redirectTo);
        return false;
      }
      return true;
    }
    return false;
  }, [isAuthenticated, loading, hasRole, navigate]);

  // Return all auth context values plus additional helper functions
  return {
    currentUser,
    loading,
    error,
    isAuthenticated,
    registerUser,
    loginUser,
    socialLoginUser,
    logoutUser,
    requireAuth,
    hasRole,
    requireRole
  };
};

export default useAuth;