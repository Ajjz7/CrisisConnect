/**
 * Utility functions for geolocation operations
 */

// Earth radius in kilometers
const EARTH_RADIUS_KM = 6371;
// Earth radius in miles
const EARTH_RADIUS_MI = 3958.8;

/**
 * Get current position using browser's Geolocation API
 * 
 * @param {Object} options - Geolocation options
 * @param {boolean} options.enableHighAccuracy - Enable high accuracy
 * @param {number} options.timeout - Maximum time to wait for location
 * @param {number} options.maximumAge - Maximum age of cached position
 * @returns {Promise<GeolocationPosition>} Geolocation position
 */
export const getCurrentPosition = (options = {}) => {
  const defaultOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0
  };
  
  const geolocationOptions = { ...defaultOptions, ...options };
  
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(resolve, reject, geolocationOptions);
  });
};

/**
 * Watch position changes using browser's Geolocation API
 * 
 * @param {Function} successCallback - Callback for position updates
 * @param {Function} errorCallback - Callback for errors
 * @param {Object} options - Geolocation options
 * @returns {number} Watch ID that can be used to clear the watch
 */
export const watchPosition = (successCallback, errorCallback, options = {}) => {
  const defaultOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0
  };
  
  const geolocationOptions = { ...defaultOptions, ...options };
  
  if (!navigator.geolocation) {
    errorCallback(new Error('Geolocation is not supported by your browser'));
    return null;
  }
  
  return navigator.geolocation.watchPosition(
    successCallback,
    errorCallback,
    geolocationOptions
  );
};

/**
 * Clear a position watch
 * 
 * @param {number} watchId - Watch ID returned by watchPosition
 */
export const clearPositionWatch = (watchId) => {
  if (watchId && navigator.geolocation) {
    navigator.geolocation.clearWatch(watchId);
  }
};

/**
 * Convert degrees to radians
 * 
 * @param {number} degrees - Angle in degrees
 * @returns {number} Angle in radians
 */
export const degreesToRadians = (degrees) => {
  return degrees * (Math.PI / 180);
};

/**
 * Calculate distance between two points using the Haversine formula
 * 
 * @param {number} lat1 - Latitude of first point in degrees
 * @param {number} lon1 - Longitude of first point in degrees
 * @param {number} lat2 - Latitude of second point in degrees
 * @param {number} lon2 - Longitude of second point in degrees
 * @param {boolean} inMiles - Whether to return distance in miles (default: true)
 * @returns {number} Distance between points in miles or kilometers
 */
export const calculateDistance = (lat1, lon1, lat2, lon2, inMiles = true) => {
  const dLat = degreesToRadians(lat2 - lat1);
  const dLon = degreesToRadians(lon2 - lon1);
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(degreesToRadians(lat1)) * Math.cos(degreesToRadians(lat2)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const radius = inMiles ? EARTH_RADIUS_MI : EARTH_RADIUS_KM;
  
  return radius * c;
};

/**
 * Check if a location is within a certain radius of another location
 * 
 * @param {number} centerLat - Latitude of center point in degrees
 * @param {number} centerLon - Longitude of center point in degrees
 * @param {number} pointLat - Latitude of test point in degrees
 * @param {number} pointLon - Longitude of test point in degrees
 * @param {number} radiusMiles - Radius in miles
 * @returns {boolean} Whether the point is within the radius
 */
export const isWithinRadius = (centerLat, centerLon, pointLat, pointLon, radiusMiles) => {
  const distance = calculateDistance(centerLat, centerLon, pointLat, pointLon, true);
  return distance <= radiusMiles;
};

/**
 * Find points within a radius of a center point
 * 
 * @param {Object} center - Center point coordinates
 * @param {number} center.latitude - Latitude of center point
 * @param {number} center.longitude - Longitude of center point
 * @param {Array<Object>} points - Array of points to check
 * @param {number} radiusMiles - Radius in miles
 * @returns {Array<Object>} Points within the radius
 */
export const findPointsWithinRadius = (center, points, radiusMiles) => {
  if (!center || !Array.isArray(points)) {
    return [];
  }
  
  return points.filter(point => {
    // Skip points without proper coordinates
    if (!point.latitude || !point.longitude) {
      return false;
    }
    
    return isWithinRadius(
      center.latitude,
      center.longitude,
      point.latitude,
      point.longitude,
      radiusMiles
    );
  });
};

/**
 * Convert location coordinates to a human-readable address
 * (Requires Google Maps Geocoding API)
 * 
 * @param {number} latitude - Latitude in degrees
 * @param {number} longitude - Longitude in degrees
 * @returns {Promise<string>} Human-readable address
 */
export const getAddressFromCoordinates = async (latitude, longitude) => {
  try {
    // Check if Google Maps API is available
    if (!window.google || !window.google.maps || !window.google.maps.Geocoder) {
      throw new Error('Google Maps Geocoder not available');
    }
    
    const geocoder = new window.google.maps.Geocoder();
    const response = await new Promise((resolve, reject) => {
      geocoder.geocode(
        { location: { lat: latitude, lng: longitude } },
        (results, status) => {
          if (status === 'OK' && results[0]) {
            resolve(results);
          } else {
            reject(new Error(`Geocoding failed: ${status}`));
          }
        }
      );
    });
    
    return response[0].formatted_address;
  } catch (error) {
    console.error('Error getting address:', error);
    // Fallback to coordinates string
    return `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
  }
};

/**
 * Get coordinates from an address
 * (Requires Google Maps Geocoding API)
 * 
 * @param {string} address - Human-readable address
 * @returns {Promise<Object>} Coordinates {latitude, longitude}
 */
export const getCoordinatesFromAddress = async (address) => {
  try {
    // Check if Google Maps API is available
    if (!window.google || !window.google.maps || !window.google.maps.Geocoder) {
      throw new Error('Google Maps Geocoder not available');
    }
    
    const geocoder = new window.google.maps.Geocoder();
    const response = await new Promise((resolve, reject) => {
      geocoder.geocode(
        { address },
        (results, status) => {
          if (status === 'OK' && results[0]) {
            resolve(results);
          } else {
            reject(new Error(`Geocoding failed: ${status}`));
          }
        }
      );
    });
    
    const location = response[0].geometry.location;
    return {
      latitude: location.lat(),
      longitude: location.lng()
    };
  } catch (error) {
    console.error('Error getting coordinates:', error);
    throw error;
  }
};

/**
 * Get the bounding box (rectangle) for a point and radius
 * 
 * @param {number} latitude - Latitude of center point in degrees
 * @param {number} longitude - Longitude of center point in degrees
 * @param {number} radiusMiles - Radius in miles
 * @returns {Object} Bounding box coordinates
 */
export const getBoundingBox = (latitude, longitude, radiusMiles) => {
  const latRadians = degreesToRadians(latitude);
  const lonRadians = degreesToRadians(longitude);
  
  const radiusEarth = EARTH_RADIUS_MI;
  const latChange = radiusMiles / radiusEarth;
  const lonChange = radiusMiles / (radiusEarth * Math.cos(latRadians));
  
  const latRadiansChange = latChange;
  const lonRadiansChange = lonChange;
  
  return {
    north: latitude + latRadiansChange * (180 / Math.PI),
    south: latitude - latRadiansChange * (180 / Math.PI),
    east: longitude + lonRadiansChange * (180 / Math.PI),
    west: longitude - lonRadiansChange * (180 / Math.PI)
  };
};

/**
 * Check if the browser supports geolocation
 * 
 * @returns {boolean} Whether geolocation is supported
 */
export const isGeolocationSupported = () => {
  return 'geolocation' in navigator;
};

/**
 * Format coordinates as a readable string
 * 
 * @param {number} latitude - Latitude in degrees
 * @param {number} longitude - Longitude in degrees
 * @param {number} precision - Number of decimal places
 * @returns {string} Formatted coordinates string
 */
export const formatCoordinates = (latitude, longitude, precision = 6) => {
  if (isNaN(latitude) || isNaN(longitude)) {
    return 'Invalid coordinates';
  }
  
  const lat = latitude.toFixed(precision);
  const lon = longitude.toFixed(precision);
  
  const latDirection = latitude >= 0 ? 'N' : 'S';
  const lonDirection = longitude >= 0 ? 'E' : 'W';
  
  return `${Math.abs(lat)}° ${latDirection}, ${Math.abs(lon)}° ${lonDirection}`;
};

/**
 * Fallback method to estimate location using IP address
 * (Requires external IP geolocation service)
 * 
 * @returns {Promise<Object>} Estimated location {latitude, longitude, accuracy}
 */
export const getLocationByIP = async () => {
  try {
    const response = await fetch('https://ipapi.co/json/');
    const data = await response.json();
    
    if (data.error) {
      throw new Error('IP geolocation failed');
    }
    
    return {
      latitude: parseFloat(data.latitude),
      longitude: parseFloat(data.longitude),
      accuracy: 10000, // IP-based geolocation is not very accurate (10km)
      city: data.city,
      region: data.region,
      country: data.country_name
    };
  } catch (error) {
    console.error('Error getting location by IP:', error);
    throw error;
  }
};

export default {
  getCurrentPosition,
  watchPosition,
  clearPositionWatch,
  calculateDistance,
  isWithinRadius,
  findPointsWithinRadius,
  getAddressFromCoordinates,
  getCoordinatesFromAddress,
  getBoundingBox,
  isGeolocationSupported,
  formatCoordinates,
  getLocationByIP
};