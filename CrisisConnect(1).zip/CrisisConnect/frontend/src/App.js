import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

// Layouts
import MainLayout from './layouts/MainLayout';
import AuthLayout from './layouts/AuthLayout';

// Authentication Pages
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

// Main Pages
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import CrisisMap from './pages/CrisisMap';
import Resources from './pages/Resources';
import Profile from './pages/Profile';
import Settings from './pages/Settings';

// Crisis Reporting
import CrisisReport from './pages/CrisisReport';
import ReportDetail from './pages/ReportDetail';
import Reports from './pages/Reports';

// Info Pages
import About from './pages/About';
import Contact from './pages/Contact';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import Help from './pages/Help';

// Other
import NotFound from './pages/NotFound';
import Notifications from './pages/Notifications';
import Messages from './pages/Messages';

// Context
import { AuthProvider, useAuth } from './contexts/AuthContext';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <div className="loading-spinner">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

const App = () => {
  const [appReady, setAppReady] = useState(false);

  useEffect(() => {
    // Initialize Firebase
    if (window.firebase) {
      console.log('Firebase initialized from window object');
    } else {
      console.warn('Firebase not initialized');
    }

    // Check if browser supports geolocation for crisis reporting
    if (!navigator.geolocation) {
      console.warn('Geolocation is not supported by this browser');
    }

    // App is ready
    setAppReady(true);
  }, []);

  if (!appReady) {
    return (
      <div className="app-loading">
        <div className="app-loading-spinner"></div>
        <div className="app-loading-text">Loading The Crisis Connect Platform...</div>
      </div>
    );
  }

  return (
    <AuthProvider>
      <Router>
        <Toaster position="top-right" />
        <Routes>
          {/* Auth Routes */}
          <Route element={<AuthLayout />}>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
          </Route>

          {/* Main Routes with MainLayout */}
          <Route element={<MainLayout />}>
            {/* Public Routes */}
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/help" element={<Help />} />
            <Route path="/resources" element={<Resources />} />
            <Route path="/crisis-map" element={<CrisisMap />} />

            {/* Protected Routes */}
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
            <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
            <Route path="/messages" element={<ProtectedRoute><Messages /></ProtectedRoute>} />
            <Route path="/reports" element={<ProtectedRoute><Reports /></ProtectedRoute>} />
            <Route path="/reports/:id" element={<ProtectedRoute><ReportDetail /></ProtectedRoute>} />
            <Route path="/crisis/report" element={<ProtectedRoute><CrisisReport /></ProtectedRoute>} />
            <Route path="/crisis/report/:id" element={<ProtectedRoute><CrisisReport /></ProtectedRoute>} />
          </Route>

          {/* 404 Not Found */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
};

export default App;