import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import reportWebVitals from './reportWebVitals';
import './styles/index.css';

// Initialize Firebase (if needed) - commented out until Firebase config is available
// import { initializeFirebase } from './services/firebaseService';
// initializeFirebase();

// Setup any global error tracking or monitoring (if needed)
// import * as Sentry from '@sentry/react';
// Sentry.init({ dsn: process.env.REACT_APP_SENTRY_DSN });

// Register service worker for offline capabilities (if needed)
// import * as serviceWorkerRegistration from './serviceWorkerRegistration';
// serviceWorkerRegistration.register();

// Load environment variables
const appEnv = process.env.NODE_ENV || 'development';
console.log(`CrisisConnect running in ${appEnv} environment`);

// Create root for React app
const container = document.getElementById('root');
const root = createRoot(container);

// Render the app
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Measure performance in development
if (process.env.NODE_ENV === 'development') {
  reportWebVitals(console.log);
}