import axios from 'axios';

// API base URL
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';
const AI_API_URL = process.env.REACT_APP_FASTAPI_URL || 'http://localhost:8000';

/**
 * Crisis service for handling all crisis-related API calls
 */
const crisisService = {
  /**
   * Get crisis reports near a location
   * 
   * @param {Object} params - Query parameters
   * @param {number} params.latitude - Latitude coordinate
   * @param {number} params.longitude - Longitude coordinate
   * @param {number} params.radius - Search radius in miles (default: 25)
   * @returns {Promise<Object>} Crisis reports response
   */
  getCrisisReports: async (params = {}) => {
    try {
      const response = await axios.get(`${API_URL}/crisis/reports`, {
        params,
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to fetch crisis reports');
      } else if (error.request) {
        throw new Error('No response from server. Please try again later.');
      } else {
        throw new Error('Failed to fetch crisis reports. Please try again.');
      }
    }
  },

  /**
   * Get crisis reports submitted by the current user
   * 
   * @returns {Promise<Object>} User's crisis reports
   */
  getUserReports: async () => {
    try {
      const response = await axios.get(`${API_URL}/crisis/user-reports`, {
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to fetch your reports');
      } else {
        throw new Error('Failed to fetch your reports. Please try again.');
      }
    }
  },

  /**
   * Create a new crisis report
   * 
   * @param {Object|FormData} data - Crisis report data (can be FormData for file uploads)
   * @returns {Promise<Object>} Created crisis report
   */
  createCrisisReport: async (data) => {
    try {
      // Determine if we're sending FormData or JSON
      const isFormData = data instanceof FormData;
      
      const response = await axios.post(`${API_URL}/crisis/report`, data, {
        withCredentials: true,
        headers: isFormData ? {
          'Content-Type': 'multipart/form-data'
        } : {
          'Content-Type': 'application/json'
        }
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to create report');
      } else if (error.request) {
        throw new Error('No response from server. Please try again later.');
      } else {
        throw new Error('Failed to create report. Please try again.');
      }
    }
  },

  /**
   * Vote on a crisis report
   * 
   * @param {number} reportId - ID of the report to vote on
   * @param {string} voteType - Type of vote ('up' or 'down')
   * @returns {Promise<Object>} Vote response
   */
  voteOnReport: async (reportId, voteType) => {
    try {
      const response = await axios.post(`${API_URL}/crisis/vote/${reportId}`, {
        vote: voteType
      }, {
        withCredentials: true
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to record vote');
      } else {
        throw new Error('Failed to record vote. Please try again.');
      }
    }
  },

  /**
   * Get detailed information about a specific crisis report
   * 
   * @param {number} reportId - ID of the report to retrieve
   * @returns {Promise<Object>} Crisis report details
   */
  getCrisisReportDetails: async (reportId) => {
    try {
      const response = await axios.get(`${API_URL}/crisis/report/${reportId}`, {
        withCredentials: true
      });
      
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to fetch report details');
      } else {
        throw new Error('Failed to fetch report details. Please try again.');
      }
    }
  },

  /**
   * Find emergency resources based on crisis type and location
   * 
   * @param {Object} criteria - Search criteria
   * @param {string} criteria.location - Location name
   * @param {string} criteria.crisis_type - Type of crisis
   * @param {Array<string>} criteria.user_needs - Specific user needs
   * @param {string} criteria.severity - Crisis severity (low, medium, high)
   * @param {boolean} criteria.special_needs - Whether user has special needs
   * @param {boolean} criteria.has_children - Whether user has children
   * @param {boolean} criteria.has_pets - Whether user has pets
   * @param {boolean} criteria.transportation - Whether user has transportation
   * @returns {Promise<Object>} Matched resources
   */
  findEmergencyResources: async (criteria) => {
    try {
      const response = await axios.post(`${AI_API_URL}/ai/match_resources`, criteria);
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to find emergency resources');
      } else {
        throw new Error('Failed to find emergency resources. Please try again.');
      }
    }
  },

  /**
   * Get safety instructions for a specific crisis type
   * 
   * @param {string} crisisType - Type of crisis
   * @param {string} severity - Crisis severity (low, medium, high)
   * @returns {Promise<Object>} Safety instructions
   */
  getSafetyInstructions: async (crisisType, severity = 'medium') => {
    try {
      const response = await axios.get(`${API_URL}/crisis/safety-instructions`, {
        params: {
          crisis_type: crisisType,
          severity
        }
      });
      
      return response.data;
    } catch (error) {
      // Return hardcoded basic safety instructions if API fails
      return {
        instructions: [
          "Follow instructions from local emergency officials",
          "Have emergency supplies ready",
          "Keep communication devices charged",
          "Stay informed through official channels",
          "Check on vulnerable neighbors if safe to do so"
        ]
      };
    }
  },

  /**
   * Get evacuation routes for a location and crisis type
   * 
   * @param {string} location - Location name
   * @param {string} crisisType - Type of crisis
   * @returns {Promise<Object>} Evacuation routes
   */
  getEvacuationRoutes: async (location, crisisType) => {
    try {
      const response = await axios.get(`${API_URL}/crisis/evacuation-routes`, {
        params: {
          location,
          crisis_type: crisisType
        }
      });
      
      return response.data;
    } catch (error) {
      // Return simplified response if API fails
      return {
        primary_route: "Contact local emergency services for evacuation instructions",
        secondary_route: "Follow official emergency broadcast instructions",
        special_needs_transportation: "Call Emergency Services for assisted evacuation"
      };
    }
  },

  /**
   * Get emergency contacts for a location
   * 
   * @param {string} location - Location name
   * @returns {Promise<Object>} Emergency contacts
   */
  getEmergencyContacts: async (location) => {
    try {
      const response = await axios.get(`${API_URL}/crisis/emergency-contacts`, {
        params: { location }
      });
      
      return response.data;
    } catch (error) {
      // Return basic emergency contacts if API fails
      return {
        emergency_services: "911",
        disaster_relief: "1-800-RED-CROSS",
        poison_control: "1-800-222-1222"
      };
    }
  }
};

export default crisisService;