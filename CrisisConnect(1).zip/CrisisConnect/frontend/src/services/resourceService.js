import axios from 'axios';

// API base URLs
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';
const AI_API_URL = process.env.REACT_APP_FASTAPI_URL || 'http://localhost:8000';

/**
 * Resource service for handling all emergency resource-related API calls
 */
const resourceService = {
  /**
   * Find emergency resources using AI-powered matching
   * 
   * @param {Object} criteria - Resource search criteria
   * @param {string} criteria.location - Location name or coordinates
   * @param {string} criteria.crisis_type - Type of crisis
   * @param {Array<string>} [criteria.user_needs] - Specific user needs
   * @param {string} [criteria.severity] - Crisis severity (low, medium, high)
   * @param {boolean} [criteria.special_needs] - Whether user has special needs
   * @param {boolean} [criteria.has_children] - Whether user has children
   * @param {boolean} [criteria.has_pets] - Whether user has pets
   * @param {boolean} [criteria.transportation] - Whether user has transportation
   * @param {string} [criteria.language] - Preferred language for resources
   * @returns {Promise<Object>} Matched resources and related information
   */
  findResources: async (criteria) => {
    try {
      const response = await axios.post(`${AI_API_URL}/ai/match_resources`, criteria);
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to find resources');
      } else if (error.request) {
        throw new Error('No response from server. Please try again later.');
      } else {
        throw new Error('Failed to find resources. Please try again.');
      }
    }
  },

  /**
   * Get detailed information about a specific resource
   * 
   * @param {string} resourceId - ID of the resource to retrieve
   * @returns {Promise<Object>} Resource details
   */
  getResourceDetails: async (resourceId) => {
    try {
      const response = await axios.get(`${API_URL}/resources/${resourceId}`);
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to fetch resource details');
      } else {
        throw new Error('Failed to fetch resource details. Please try again.');
      }
    }
  },

  /**
   * Get resources by category
   * 
   * @param {string} category - Resource category
   * @param {Object} params - Additional query parameters
   * @param {number} [params.latitude] - Latitude coordinate
   * @param {number} [params.longitude] - Longitude coordinate
   * @param {number} [params.radius] - Search radius in miles
   * @returns {Promise<Object>} Resources in the specified category
   */
  getResourcesByCategory: async (category, params = {}) => {
    try {
      const response = await axios.get(`${API_URL}/resources/category/${category}`, {
        params
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || `Failed to fetch ${category} resources`);
      } else {
        throw new Error(`Failed to fetch ${category} resources. Please try again.`);
      }
    }
  },

  /**
   * Get external data from government and NGO APIs
   * 
   * @param {Array<string>} sources - Data sources to fetch (fema, redcross, who)
   * @param {Object} params - Additional query parameters
   * @param {string} [params.location] - Location to filter results
   * @param {string} [params.disaster_type] - Disaster type to filter results
   * @returns {Promise<Object>} Data from external APIs
   */
  getExternalData: async (sources = ['fema', 'redcross', 'who'], params = {}) => {
    try {
      const response = await axios.get(`${API_URL}/resources/external`, {
        params: {
          ...params,
          sources: sources.join(',')
        }
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to fetch external data');
      } else {
        throw new Error('Failed to fetch external data. Please try again.');
      }
    }
  },

  /**
   * Get weather and environmental data for a location
   * 
   * @param {Object} params - Query parameters
   * @param {string} [params.location] - Location name
   * @param {number} [params.latitude] - Latitude coordinate
   * @param {number} [params.longitude] - Longitude coordinate
   * @returns {Promise<Object>} Weather and environmental data
   */
  getWeatherData: async (params = {}) => {
    try {
      const response = await axios.get(`${API_URL}/resources/weather`, {
        params
      });
      return response.data;
    } catch (error) {
      // Return mock data if API fails
      return {
        current_conditions: "Partially cloudy",
        temperature: 78,
        wind_speed: 15,
        wind_direction: "NE",
        precipitation_chance: 30,
        alerts: ["Weather data temporarily unavailable"]
      };
    }
  },

  /**
   * Get evacuation routes for a location and crisis type
   * 
   * @param {Object} params - Query parameters
   * @param {string} params.location - Location name
   * @param {string} params.crisis_type - Type of crisis
   * @returns {Promise<Object>} Evacuation routes
   */
  getEvacuationRoutes: async (params) => {
    try {
      const response = await axios.get(`${API_URL}/resources/evacuation-routes`, {
        params
      });
      return response.data;
    } catch (error) {
      // Return basic routes if API fails
      return {
        primary_route: "Contact local emergency services for evacuation instructions",
        secondary_route: "Follow official emergency broadcast instructions",
        special_needs_transportation: "Call Emergency Services for assisted evacuation"
      };
    }
  },

  /**
   * Get emergency contacts for a location
   * 
   * @param {string} location - Location name
   * @returns {Promise<Object>} Emergency contacts
   */
  getEmergencyContacts: async (location) => {
    try {
      const response = await axios.get(`${API_URL}/resources/emergency-contacts`, {
        params: { location }
      });
      return response.data;
    } catch (error) {
      // Return basic emergency contacts if API fails
      return {
        emergency_services: "911",
        local_emergency_management: "555-1234",
        disaster_relief: "1-800-RED-CROSS",
        poison_control: "1-800-222-1222"
      };
    }
  },

  /**
   * Get safety instructions for a specific crisis type
   * 
   * @param {string} crisisType - Type of crisis
   * @param {string} [severity='medium'] - Crisis severity (low, medium, high)
   * @returns {Promise<Object>} Safety instructions
   */
  getSafetyInstructions: async (crisisType, severity = 'medium') => {
    try {
      const response = await axios.get(`${API_URL}/resources/safety-instructions`, {
        params: {
          crisis_type: crisisType,
          severity
        }
      });
      return response.data;
    } catch (error) {
      // Return basic instructions if API fails
      return {
        instructions: [
          "Follow instructions from local emergency officials",
          "Have emergency supplies ready",
          "Keep communication devices charged",
          "Stay informed through official channels",
          "Check on vulnerable neighbors if safe to do so"
        ]
      };
    }
  },

  /**
   * Get crisis prediction data (AI-generated forecast)
   * 
   * @param {Object} params - Query parameters
   * @param {string} params.crisis_type - Type of crisis
   * @param {string} params.location - Location name
   * @param {string} [params.severity] - Current crisis severity
   * @returns {Promise<Object>} Crisis prediction data
   */
  getCrisisPrediction: async (params) => {
    try {
      const response = await axios.get(`${API_URL}/resources/crisis-prediction`, {
        params
      });
      return response.data;
    } catch (error) {
      // Return basic prediction if API fails
      return {
        expected_duration: "Unknown",
        trend: "Unknown",
        confidence: 0,
        next_48_hours: "Prediction data unavailable. Please rely on official sources."
      };
    }
  },

  /**
   * Rate a resource (user feedback)
   * 
   * @param {string} resourceId - ID of the resource
   * @param {Object} data - Rating data
   * @param {number} data.rating - Rating (1-5)
   * @param {string} [data.comment] - Optional comment
   * @returns {Promise<Object>} Rating response
   */
  rateResource: async (resourceId, data) => {
    try {
      const response = await axios.post(`${API_URL}/resources/${resourceId}/rate`, data, {
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to submit rating');
      } else {
        throw new Error('Failed to submit rating. Please try again.');
      }
    }
  },

  /**
   * Report a resource issue (incorrect information, closed location, etc.)
   * 
   * @param {string} resourceId - ID of the resource
   * @param {Object} data - Issue report data
   * @param {string} data.issue_type - Type of issue
   * @param {string} data.description - Issue description
   * @returns {Promise<Object>} Report response
   */
  reportResourceIssue: async (resourceId, data) => {
    try {
      const response = await axios.post(`${API_URL}/resources/${resourceId}/report-issue`, data, {
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to report issue');
      } else {
        throw new Error('Failed to report issue. Please try again.');
      }
    }
  },

  /**
   * Search for resources by keyword
   * 
   * @param {string} query - Search query
   * @param {Object} params - Additional query parameters
   * @param {string} [params.location] - Location name
   * @param {number} [params.latitude] - Latitude coordinate
   * @param {number} [params.longitude] - Longitude coordinate
   * @param {number} [params.radius] - Search radius in miles
   * @returns {Promise<Object>} Search results
   */
  searchResources: async (query, params = {}) => {
    try {
      const response = await axios.get(`${API_URL}/resources/search`, {
        params: {
          q: query,
          ...params
        }
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to search resources');
      } else {
        throw new Error('Failed to search resources. Please try again.');
      }
    }
  },

  /**
   * Get multilingual translation for resource information
   * 
   * @param {Array<string>} textList - List of text items to translate
   * @param {string} targetLanguage - Target language code (e.g., 'es', 'fr')
   * @returns {Promise<Array<string>>} Translated text items
   */
  translateResourceInfo: async (textList, targetLanguage) => {
    if (targetLanguage === 'en') {
      return textList; // No translation needed
    }
    
    try {
      const response = await axios.post(`${API_URL}/resources/translate`, {
        text_list: textList,
        target_language: targetLanguage
      });
      
      return response.data.translations || textList;
    } catch (error) {
      console.error('Translation error:', error);
      return textList; // Return original text if translation fails
    }
  }
};

export default resourceService;