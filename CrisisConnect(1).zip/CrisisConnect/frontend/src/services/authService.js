import axios from 'axios';

// API base URL
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

/**
 * Authentication service for handling all auth-related API calls
 */
const authService = {
  /**
   * Register a new user
   * 
   * @param {Object} userData - User registration data
   * @param {string} userData.firstName - User's first name
   * @param {string} userData.lastName - User's last name
   * @param {string} userData.email - User's email address
   * @param {string} userData.password - User's password
   * @returns {Promise<Object>} Registration response
   */
  register: async (userData) => {
    try {
      const response = await axios.post(`${API_URL}/register`, userData);
      return response.data;
    } catch (error) {
      if (error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        throw new Error(error.response.data.message || 'Registration failed');
      } else if (error.request) {
        // The request was made but no response was received
        throw new Error('No response from server. Please try again later.');
      } else {
        // Something happened in setting up the request that triggered an Error
        throw new Error('Registration failed. Please try again.');
      }
    }
  },

  /**
   * Log in a user
   * 
   * @param {Object} credentials - User login credentials
   * @param {string} credentials.email - User's email address
   * @param {string} credentials.password - User's password
   * @returns {Promise<Object>} Login response with user data and token
   */
  login: async (credentials) => {
    try {
      const response = await axios.post(`${API_URL}/login`, credentials, {
        withCredentials: true // Important for session cookies
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Invalid credentials');
      } else if (error.request) {
        throw new Error('No response from server. Please try again later.');
      } else {
        throw new Error('Login failed. Please try again.');
      }
    }
  },

  /**
   * Log out the current user
   * 
   * @returns {Promise<Object>} Logout response
   */
  logout: async () => {
    try {
      const response = await axios.get(`${API_URL}/logout`, {
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      console.error('Logout error:', error);
      // Even if logout fails on the server, we clear local state
      throw new Error('Logout failed. Please try again.');
    }
  },

  /**
   * Get the current user's profile
   * 
   * @returns {Promise<Object>} User profile data
   */
  getCurrentUser: async () => {
    try {
      const response = await axios.get(`${API_URL}/dashboard`, {
        withCredentials: true
      });
      return response.data.user;
    } catch (error) {
      if (error.response && error.response.status === 401) {
        // User is not authenticated
        return null;
      }
      throw new Error('Failed to get user profile');
    }
  },

  /**
   * Update user profile
   * 
   * @param {Object} userData - Updated user profile data
   * @returns {Promise<Object>} Updated user profile
   */
  updateProfile: async (userData) => {
    try {
      const response = await axios.put(`${API_URL}/profile`, userData, {
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to update profile');
      } else if (error.request) {
        throw new Error('No response from server. Please try again later.');
      } else {
        throw new Error('Profile update failed. Please try again.');
      }
    }
  },

  /**
   * Change user password
   * 
   * @param {Object} passwordData - Password change data
   * @param {string} passwordData.currentPassword - Current password
   * @param {string} passwordData.newPassword - New password
   * @param {string} passwordData.confirmPassword - Confirm new password
   * @returns {Promise<Object>} Password change response
   */
  changePassword: async (passwordData) => {
    try {
      const response = await axios.post(`${API_URL}/change-password`, passwordData, {
        withCredentials: true
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to change password');
      } else if (error.request) {
        throw new Error('No response from server. Please try again later.');
      } else {
        throw new Error('Password change failed. Please try again.');
      }
    }
  },

  /**
   * Request password reset
   * 
   * @param {Object} data - Password reset request data
   * @param {string} data.email - User's email address
   * @returns {Promise<Object>} Password reset request response
   */
  requestPasswordReset: async (data) => {
    try {
      const response = await axios.post(`${API_URL}/reset-password`, data);
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to request password reset');
      } else {
        throw new Error('Password reset request failed. Please try again.');
      }
    }
  },

  /**
   * Reset password with token
   * 
   * @param {Object} data - Password reset data
   * @param {string} data.token - Password reset token
   * @param {string} data.newPassword - New password
   * @param {string} data.confirmPassword - Confirm new password
   * @returns {Promise<Object>} Password reset response
   */
  resetPassword: async (data) => {
    try {
      const response = await axios.post(`${API_URL}/reset-password/${data.token}`, {
        newPassword: data.newPassword,
        confirmPassword: data.confirmPassword
      });
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to reset password');
      } else {
        throw new Error('Password reset failed. Please try again.');
      }
    }
  },

  /**
   * Verify email with token
   * 
   * @param {string} token - Email verification token
   * @returns {Promise<Object>} Email verification response
   */
  verifyEmail: async (token) => {
    try {
      const response = await axios.get(`${API_URL}/verify-email/${token}`);
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new Error(error.response.data.message || 'Failed to verify email');
      } else {
        throw new Error('Email verification failed. Please try again.');
      }
    }
  },

  /**
   * Check if user is authenticated
   * 
   * @returns {Promise<boolean>} Authentication status
   */
  isAuthenticated: async () => {
    try {
      const user = await authService.getCurrentUser();
      return !!user;
    } catch (error) {
      return false;
    }
  }
};

export default authService;