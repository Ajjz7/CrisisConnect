import React, { createContext, useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

// Create crisis context
const CrisisContext = createContext();

// Custom hook for using crisis context
export const useCrisis = () => useContext(CrisisContext);

// API base URL
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

export const CrisisProvider = ({ children }) => {
  const { currentUser, isAuthenticated } = useAuth();
  const [crisisReports, setCrisisReports] = useState([]);
  const [userReports, setUserReports] = useState([]);
  const [nearbyResources, setNearbyResources] = useState([]);
  const [userLocation, setUserLocation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // Get user's current location
  useEffect(() => {
    const getUserLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            setUserLocation({ latitude, longitude });
          },
          (error) => {
            console.error('Error getting location:', error);
            setError('Unable to get your location. Some features may be limited.');
            // Set default location (e.g., San Francisco)
            setUserLocation({ latitude: 37.7749, longitude: -122.4194 });
          }
        );
      } else {
        setError('Geolocation is not supported by your browser. Some features may be limited.');
        // Set default location
        setUserLocation({ latitude: 37.7749, longitude: -122.4194 });
      }
    };

    getUserLocation();
  }, []);

  // Fetch crisis reports when user location changes
  useEffect(() => {
    if (userLocation) {
      fetchCrisisReports();
    }
  }, [userLocation]);

  // Fetch user's reports when authenticated
  useEffect(() => {
    if (isAuthenticated && currentUser) {
      fetchUserReports();
    }
  }, [isAuthenticated, currentUser]);

  // Fetch crisis reports based on user location
  const fetchCrisisReports = async () => {
    if (!userLocation) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.get(`${API_URL}/crisis/reports`, {
        params: {
          latitude: userLocation.latitude,
          longitude: userLocation.longitude,
          radius: 25 // miles
        },
        withCredentials: true
      });
      
      setCrisisReports(response.data.reports || []);
    } catch (err) {
      console.error('Error fetching crisis reports:', err);
      setError('Failed to load crisis reports. Please try again.');
      
      // Set mock data for development
      setCrisisReports([
        {
          id: 1,
          crisis_type: 'earthquake',
          description: 'Felt strong shaking in downtown area, some buildings damaged',
          location: 'San Francisco, CA',
          created_at: '2025-03-14T14:30:00',
          upvotes: 24,
          downvotes: 2,
          trust_score: 92,
          user: { firstName: 'John', lastName: 'D.' }
        },
        {
          id: 2,
          crisis_type: 'power_outage',
          description: 'No electricity in Mission District, traffic lights out',
          location: 'San Francisco, CA',
          created_at: '2025-03-14T15:15:00',
          upvotes: 18,
          downvotes: 0,
          trust_score: 95,
          user: { firstName: 'Sarah', lastName: 'M.' }
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Fetch reports created by the current user
  const fetchUserReports = async () => {
    if (!isAuthenticated) return;
    
    setLoading(true);
    
    try {
      const response = await axios.get(`${API_URL}/crisis/user-reports`, {
        withCredentials: true
      });
      
      setUserReports(response.data.reports || []);
    } catch (err) {
      console.error('Error fetching user reports:', err);
      
      // Set mock data for development
      setUserReports([
        {
          id: 3,
          crisis_type: 'wildfire',
          description: 'Smoke visible from hills to the north',
          location: 'Marin County, CA',
          created_at: '2025-03-13T10:20:00',
          upvotes: 15,
          downvotes: 1,
          trust_score: 87
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  // Create a new crisis report
  const createCrisisReport = async (reportData) => {
    setLoading(true);
    setError(null);
    
    try {
      // Add user location if available
      if (userLocation) {
        reportData.latitude = userLocation.latitude;
        reportData.longitude = userLocation.longitude;
      }
      
      const response = await axios.post(`${API_URL}/crisis/report`, reportData, {
        withCredentials: true
      });
      
      // Update reports lists
      const newReport = response.data.report;
      setUserReports(prev => [newReport, ...prev]);
      setCrisisReports(prev => [newReport, ...prev]);
      
      return response.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create crisis report');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Vote on a crisis report
  const voteOnReport = async (reportId, voteType) => {
    try {
      const response = await axios.post(`${API_URL}/crisis/vote/${reportId}`, {
        vote: voteType
      }, { withCredentials: true });
      
      // Update reports in state
      const updateReports = (reports) => {
        return reports.map(report => {
          if (report.id === reportId) {
            const newReport = { ...report };
            if (voteType === 'up') {
              newReport.upvotes = report.upvotes + 1;
            } else {
              newReport.downvotes = report.downvotes + 1;
            }
            newReport.trust_score = response.data.new_trust_score;
            return newReport;
          }
          return report;
        });
      };
      
      setCrisisReports(updateReports(crisisReports));
      setUserReports(updateReports(userReports));
      
      return response.data;
    } catch (err) {
      console.error('Error voting on report:', err);
      throw err;
    }
  };

  // Find emergency resources based on user needs and location
  const findEmergencyResources = async (criteria) => {
    setLoading(true);
    setError(null);
    
    try {
      // Add user location if available
      if (userLocation && !criteria.location) {
        criteria.latitude = userLocation.latitude;
        criteria.longitude = userLocation.longitude;
      }
      
      const response = await axios.post(`${API_URL}/ai/match_resources`, criteria);
      setNearbyResources(response.data.matched_resources || []);
      
      return response.data;
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to find emergency resources');
      
      // Set mock data for development
      setNearbyResources([
        'Emergency Shelters',
        'Medical Aid Stations',
        'Water Distribution Centers',
        'Charging Stations',
        'Emergency Food Services'
      ]);
      
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Refresh all data
  const refreshData = async () => {
    await Promise.all([
      fetchCrisisReports(),
      isAuthenticated ? fetchUserReports() : Promise.resolve()
    ]);
  };

  // Convert coordinates to human-readable address
  const getAddressFromCoordinates = async (latitude, longitude) => {
    try {
      const response = await axios.get(`https://maps.googleapis.com/maps/api/geocode/json`, {
        params: {
          latlng: `${latitude},${longitude}`,
          key: process.env.REACT_APP_GOOGLE_MAPS_API_KEY
        }
      });
      
      if (response.data.results && response.data.results.length > 0) {
        return response.data.results[0].formatted_address;
      }
      
      return `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
    } catch (err) {
      console.error('Error getting address:', err);
      return `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
    }
  };

  // Value object to be provided to consumers
  const value = {
    crisisReports,
    userReports,
    nearbyResources,
    userLocation,
    loading,
    error,
    createCrisisReport,
    voteOnReport,
    findEmergencyResources,
    refreshData,
    getAddressFromCoordinates
  };

  return (
    <CrisisContext.Provider value={value}>
      {children}
    </CrisisContext.Provider>
  );
};

export default CrisisContext;

