import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Send, ChevronDown, ChevronUp, AlertTriangle, MapPin, Shield, MessageCircle, User, Bot, X, Loader, Paperclip, Maximize, Minimize } from 'lucide-react';

const Chatbot = () => {
  const navigate = useNavigate();
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  
  // State for chat functionality
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: "Hello, I'm your Crisis Connect assistant. How can I help you today?",
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [showSuggestions, setShowSuggestions] = useState(true);
  
  // User and location state
  const [user, setUser] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  
  // Suggestions for quick responses
  const commonQuestions = [
    "What should I do during a flood?",
    "How do I prepare for an earthquake?",
    "Where is the nearest shelter?",
    "I need medical assistance",
    "How to create an emergency kit?"
  ];

  // Check authentication status on component mount
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await fetch('/dashboard', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        }
      } catch (error) {
        console.error('Error checking authentication status:', error);
      }
    };

    checkAuthStatus();
    
    // Try to get user location if available
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, []);

  // Scroll to bottom of chat when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle message input change
  const handleInputChange = (e) => {
    setInputMessage(e.target.value);
  };

  // Handle file selection
  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  // Clear selected file
  const clearSelectedFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Handle message submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if ((!inputMessage || inputMessage.trim() === '') && !selectedFile) {
      return;
    }
    
    const newUserMessage = {
      id: messages.length + 1,
      type: 'user',
      content: inputMessage,
      timestamp: new Date(),
      file: selectedFile ? {
        name: selectedFile.name,
        type: selectedFile.type
      } : null
    };
    
    setMessages(prev => [...prev, newUserMessage]);
    setInputMessage('');
    setIsTyping(true);
    
    // Upload file if selected
    let fileUrl = null;
    if (selectedFile) {
      try {
        const formData = new FormData();
        formData.append('file', selectedFile);
        
        const uploadResponse = await fetch('/upload/file', {
          method: 'POST',
          body: formData,
          credentials: 'include'
        });
        
        if (uploadResponse.ok) {
          const fileData = await uploadResponse.json();
          fileUrl = fileData.url;
        }
      } catch (error) {
        console.error('Error uploading file:', error);
      }
      
      clearSelectedFile();
    }
    
    try {
      // Send message to AI chatbot backend
      const response = await fetch('/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: inputMessage,
          user_id: user?.id,
          location: userLocation,
          file_url: fileUrl
        }),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Add bot response to chat
        const newBotMessage = {
          id: messages.length + 2,
          type: 'bot',
          content: data.response,
          timestamp: new Date(),
          resources: data.resources || [],
          actions: data.actions || []
        };
        
        // Simulate typing delay for more natural feel
        setTimeout(() => {
          setMessages(prev => [...prev, newBotMessage]);
          setIsTyping(false);
        }, 1000);
      } else {
        throw new Error('Failed to get chatbot response');
      }
    } catch (error) {
      console.error('Error getting AI response:', error);
      
      // Add error message
      const errorMessage = {
        id: messages.length + 2,
        type: 'bot',
        content: "I'm sorry, I'm having trouble connecting right now. Please try again or contact emergency services if you're in immediate danger.",
        timestamp: new Date(),
        isError: true
      };
      
      setTimeout(() => {
        setMessages(prev => [...prev, errorMessage]);
        setIsTyping(false);
      }, 1000);
    }
  };

  // Handle quick suggestion click
  const handleSuggestionClick = (suggestion) => {
    setInputMessage(suggestion);
    
    // Submit the suggestion automatically
    const fakeEvent = { preventDefault: () => {} };
    setTimeout(() => handleSubmit(fakeEvent), 100);
  };

  // Handle action button click (e.g., navigate to crisis report)
  const handleActionClick = (action) => {
    if (action.type === 'navigate') {
      navigate(action.path);
    } else if (action.type === 'link') {
      window.open(action.url, '_blank');
    } else if (action.type === 'phone') {
      window.location.href = `tel:${action.number}`;
    }
  };
  
  // Format timestamp
  const formatTime = (date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Toggle chatbot expansion
  const toggleExpansion = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className={`bg-white rounded-lg shadow-lg flex flex-col ${isExpanded ? 'fixed inset-4 z-50' : 'h-[600px]'}`}>
      {/* Chat Header */}
      <div className="bg-blue-700 text-white px-4 py-3 flex justify-between items-center rounded-t-lg">
        <div className="flex items-center">
          <Bot className="h-6 w-6 mr-2" />
          <h2 className="text-lg font-semibold">Crisis Connect Assistant</h2>
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={toggleExpansion} 
            className="text-white hover:bg-blue-800 p-1 rounded-full"
          >
            {isExpanded ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
          </button>
        </div>
      </div>
      
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
        {messages.map((message) => (
          <div 
            key={message.id} 
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`
              max-w-[80%] rounded-lg p-3 
              ${message.type === 'user' 
                ? 'bg-blue-600 text-white rounded-br-none' 
                : message.isError 
                  ? 'bg-red-100 text-red-800 rounded-bl-none border-l-4 border-red-500' 
                  : 'bg-white text-gray-800 rounded-bl-none shadow'
              }
            `}>
              {message.type === 'bot' && (
                <div className="flex items-center mb-1">
                  <Bot className="h-4 w-4 mr-1 text-blue-500" />
                  <span className="text-xs font-semibold text-blue-500">Crisis Assistant</span>
                  <span className="text-xs text-gray-500 ml-2">{formatTime(message.timestamp)}</span>
                </div>
              )}
              
              {message.type === 'user' && (
                <div className="flex items-center justify-end mb-1">
                  <span className="text-xs text-blue-200 mr-2">{formatTime(message.timestamp)}</span>
                  <span className="text-xs font-semibold text-blue-200">You</span>
                </div>
              )}
              
              <div className="whitespace-pre-wrap">{message.content}</div>
              
              {/* File attachment display */}
              {message.file && (
                <div className="mt-2 text-xs bg-blue-700 rounded p-1 px-2 inline-flex items-center">
                  <Paperclip className="h-3 w-3 mr-1" />
                  {message.file.name}
                </div>
              )}
              
              {/* Resources and Actions */}
              {message.resources && message.resources.length > 0 && (
                <div className="mt-3 pt-2 border-t border-gray-200">
                  <span className="text-xs font-medium text-gray-500">Resources:</span>
                  <ul className="mt-1 space-y-1">
                    {message.resources.map((resource, idx) => (
                      <li key={idx} className="text-sm flex items-start">
                        <Shield className="h-4 w-4 mr-1 text-blue-500 mt-0.5" />
                        <span>{resource}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {message.actions && message.actions.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {message.actions.map((action, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleActionClick(action)}
                      className={`
                        text-sm px-3 py-1.5 rounded-full flex items-center
                        ${action.priority === 'high' 
                          ? 'bg-red-600 text-white hover:bg-red-700' 
                          : 'bg-blue-100 text-blue-800 hover:bg-blue-200'
                        }
                      `}
                    >
                      {action.type === 'navigate' && <MapPin className="h-3 w-3 mr-1" />}
                      {action.type === 'link' && <ExternalLink className="h-3 w-3 mr-1" />}
                      {action.type === 'phone' && <Phone className="h-3 w-3 mr-1" />}
                      {action.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        
        {/* Typing indicator */}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white text-gray-800 rounded-lg rounded-bl-none p-3 max-w-[80%] shadow">
              <div className="flex items-center space-x-1">
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Quick Suggestions */}
      {showSuggestions && commonQuestions.length > 0 && (
        <div className="px-4 py-2 bg-gray-100 border-t border-gray-200">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-medium text-gray-500">Common Questions</span>
            <button 
              onClick={() => setShowSuggestions(false)} 
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="flex overflow-x-auto space-x-2 pb-2">
            {commonQuestions.map((question, idx) => (
              <button
                key={idx}
                onClick={() => handleSuggestionClick(question)}
                className="px-3 py-1 bg-white border border-gray-300 rounded-full text-sm whitespace-nowrap hover:bg-gray-50"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* File preview if selected */}
      {selectedFile && (
        <div className="px-4 py-2 bg-blue-50 border-t border-blue-100 flex justify-between items-center">
          <div className="flex items-center text-sm text-blue-700">
            <Paperclip className="h-4 w-4 mr-1" />
            <span className="truncate max-w-[200px]">{selectedFile.name}</span>
          </div>
          <button 
            onClick={clearSelectedFile}
            className="text-blue-700 hover:text-blue-900"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}
      
      {/* Message Input */}
      <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4">
        <div className="relative flex items-center">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
          />
          <label
            htmlFor="file-upload"
            className="p-2 text-gray-500 hover:text-gray-700 cursor-pointer"
          >
            <Paperclip className="h-5 w-5" />
          </label>
          
          <input
            type="text"
            value={inputMessage}
            onChange={handleInputChange}
            placeholder="Type your message here..."
            className="w-full border-gray-300 rounded-full py-2 pl-4 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isTyping}
          />
          
          <button
            type="submit"
            disabled={isTyping || (!inputMessage && !selectedFile)}
            className={`absolute right-2 p-1.5 rounded-full ${
              isTyping || (!inputMessage && !selectedFile)
                ? 'text-gray-400 cursor-not-allowed'
                : 'text-blue-500 hover:text-white hover:bg-blue-500'
            }`}
          >
            {isTyping ? (
              <Loader className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </button>
        </div>
        
        {!user && (
          <div className="mt-2 text-xs text-gray-500 flex items-center">
            <AlertTriangle className="h-3 w-3 mr-1 text-yellow-500" />
            <span>
              <button 
                onClick={() => navigate('/login')}
                className="text-blue-600 hover:underline"
              >
                Log in
              </button> for personalized assistance and to save your chat history.
            </span>
          </div>
        )}
      </form>
    </div>
  );
};

export default Chatbot;