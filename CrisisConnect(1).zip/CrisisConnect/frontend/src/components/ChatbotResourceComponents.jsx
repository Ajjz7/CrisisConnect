import React from 'react';
import { ExternalLink, Phone, MapPin, AlertCircle, Info, Shield, ArrowRight } from 'lucide-react';

/**
 * Component to display a resource card in the chatbot
 */
export const ResourceCard = ({ resource }) => {
  const { title, description, url, type, priority } = resource;
  
  const getIcon = () => {
    switch (type) {
      case 'shelter':
        return <MapPin className="h-5 w-5 text-blue-500" />;
      case 'medical':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'emergency':
        return <Phone className="h-5 w-5 text-red-500" />;
      case 'info':
        return <Info className="h-5 w-5 text-blue-500" />;
      case 'safety':
        return <Shield className="h-5 w-5 text-green-500" />;
      default:
        return <Info className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const getBgColor = () => {
    switch (priority) {
      case 'high':
        return 'bg-red-50 border-red-200';
      case 'medium':
        return 'bg-yellow-50 border-yellow-200';
      default:
        return 'bg-blue-50 border-blue-200';
    }
  };
  
  return (
    <div className={`p-3 rounded-lg border ${getBgColor()} mb-2`}>
      <div className="flex items-start">
        <div className="mr-3 mt-0.5">
          {getIcon()}
        </div>
        <div>
          <h4 className="font-medium text-gray-900 text-sm">{title}</h4>
          <p className="text-sm text-gray-600 mt-1">{description}</p>
          
          {url && (
            <a 
              href={url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800"
            >
              Learn More <ArrowRight className="ml-1 h-3 w-3" />
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * Component to display a chatbot action button
 */
export const ActionButton = ({ action, onClick }) => {
  const { label, type, priority } = action;
  
  const getIcon = () => {
    switch (type) {
      case 'navigate':
        return <MapPin className="h-4 w-4 mr-1" />;
      case 'link':
        return <ExternalLink className="h-4 w-4 mr-1" />;
      case 'phone':
        return <Phone className="h-4 w-4 mr-1" />;
      default:
        return <ArrowRight className="h-4 w-4 mr-1" />;
    }
  };
  
  const getButtonStyle = () => {
    switch (priority) {
      case 'high':
        return 'bg-red-600 text-white hover:bg-red-700';
      case 'medium':
        return 'bg-yellow-500 text-white hover:bg-yellow-600';
      default:
        return 'bg-blue-100 text-blue-800 hover:bg-blue-200';
    }
  };
  
  return (
    <button
      onClick={() => onClick(action)}
      className={`text-sm px-3 py-1.5 rounded-full flex items-center ${getButtonStyle()}`}
    >
      {getIcon()}
      {label}
    </button>
  );
};

/**
 * Component to display a safety instruction list
 */
export const SafetyInstructions = ({ instructions }) => {
  if (!instructions || instructions.length === 0) return null;
  
  return (
    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-3">
      <h4 className="font-medium text-yellow-800 flex items-center text-sm">
        <AlertCircle className="h-4 w-4 mr-1" />
        Safety Instructions
      </h4>
      <ul className="mt-2 space-y-1">
        {instructions.map((instruction, idx) => (
          <li key={idx} className="flex items-start text-sm">
            <span className="mr-2 text-yellow-700">•</span>
            <span className="text-gray-800">{instruction}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

/**
 * Component for message typing indicator
 */
export const TypingIndicator = () => (
  <div className="flex justify-start">
    <div className="bg-white text-gray-800 rounded-lg rounded-bl-none p-3 max-w-[80%] shadow">
      <div className="flex items-center space-x-1">
        <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
        <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
        <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
      </div>
    </div>
  </div>
);