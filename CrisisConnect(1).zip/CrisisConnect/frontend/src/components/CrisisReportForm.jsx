import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, MapPin, Camera, ArrowRight, AlertCircle, CheckCircle, Loader } from 'lucide-react';

const CrisisReportForm = () => {
  const navigate = useNavigate();
  
  // Form state
  const [formData, setFormData] = useState({
    crisis_type: '',
    description: '',
    location: '',
    severity: 'medium',
    has_injuries: false,
    needs_evacuation: false,
    photo_url: '',
    special_needs: false,
    has_children: false,
    has_pets: false,
    transportation: true
  });
  
  // UI state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [geolocationAvailable, setGeolocationAvailable] = useState(false);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);

  // Crisis types from your backend
  const crisisTypes = [
    // Weather-Related Disasters
    { value: 'hurricane', label: 'Hurricane' },
    { value: 'tornado', label: 'Tornado' },
    { value: 'blizzard', label: 'Blizzard/Winter Storm' },
    { value: 'heatwave', label: 'Heat Wave' },
    { value: 'drought', label: 'Drought' },
    
    // Geological Disasters
    { value: 'earthquake', label: 'Earthquake' },
    { value: 'tsunami', label: 'Tsunami' },
    { value: 'landslide', label: 'Landslide' },
    { value: 'volcanic_eruption', label: 'Volcanic Eruption' },
    
    // Water-Related Disasters
    { value: 'flood', label: 'Flood' },
    { value: 'flash_flood', label: 'Flash Flood' },
    { value: 'dam_failure', label: 'Dam Failure' },
    
    // Fire-Related Disasters
    { value: 'wildfire', label: 'Wildfire' },
    { value: 'urban_fire', label: 'Urban Fire' },
    
    // Biological Disasters
    { value: 'pandemic', label: 'Pandemic/Disease Outbreak' },
    { value: 'epidemic', label: 'Epidemic' },
    { value: 'biological_hazard', label: 'Biological Hazard' },
    
    // Human-Caused Disasters
    { value: 'chemical_spill', label: 'Chemical Spill' },
    { value: 'radiation', label: 'Radiation Leak' },
    { value: 'terrorism', label: 'Terrorism Incident' },
    { value: 'conflict', label: 'Civil Unrest/Conflict' },
    { value: 'infrastructure_failure', label: 'Infrastructure Failure' }
  ];

  // Check if user is authenticated on component mount
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await fetch('/dashboard', {
          credentials: 'include' // Important for cookies/session
        });
        
        setIsAuthenticated(response.ok);
      } catch (error) {
        console.error('Error checking authentication status:', error);
        setIsAuthenticated(false);
      }
    };

    checkAuthStatus();

    // Check if geolocation is available
    if ('geolocation' in navigator) {
      setGeolocationAvailable(true);
    }
  }, []);

  // Handle form input changes
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  // Handle image upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Get current location
  const getCurrentLocation = () => {
    if (geolocationAvailable) {
      setIsLoadingLocation(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          // This is a simple example, in a real app you might use reverse geocoding to get an address
          setFormData({
            ...formData,
            location: `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`
          });
          setIsLoadingLocation(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setError('Could not access your location. Please enter it manually.');
          setIsLoadingLocation(false);
        },
        { enableHighAccuracy: true }
      );
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Reset states
    setError(null);
    setSuccess(null);
    
    // Validation
    if (!formData.crisis_type) {
      setError('Please select a crisis type');
      return;
    }
    
    if (!formData.description) {
      setError('Please provide a description of the crisis');
      return;
    }
    
    if (!formData.location) {
      setError('Please provide a location');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Handle image upload first if there's a photo
      let photoUrl = '';
      if (photoFile) {
        const photoFormData = new FormData();
        photoFormData.append('photo', photoFile);
        
        const photoResponse = await fetch('/upload/photo', {
          method: 'POST',
          body: photoFormData,
          credentials: 'include'
        });
        
        if (photoResponse.ok) {
          const photoData = await photoResponse.json();
          photoUrl = photoData.url;
        } else {
          throw new Error('Failed to upload photo');
        }
      }
      
      // Submit the crisis report
      const reportResponse = await fetch('/crisis/report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          photo_url: photoUrl
        }),
        credentials: 'include'
      });
      
      if (reportResponse.ok) {
        const reportData = await reportResponse.json();
        setSuccess(`Crisis report submitted successfully! ID: ${reportData.report_id}`);
        
        // Clear form after successful submission
        setFormData({
          crisis_type: '',
          description: '',
          location: '',
          severity: 'medium',
          has_injuries: false,
          needs_evacuation: false,
          photo_url: '',
          special_needs: false,
          has_children: false,
          has_pets: false,
          transportation: true
        });
        setPhotoFile(null);
        setPhotoPreview(null);
        
        // Redirect to confirmation page after a short delay
        setTimeout(() => {
          navigate(`/crisis/confirmation/${reportData.report_id}`);
        }, 2000);
      } else {
        const errorData = await reportResponse.json();
        throw new Error(errorData.message || 'Failed to submit crisis report');
      }
    } catch (error) {
      console.error('Error submitting report:', error);
      setError(error.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Redirect to login if not authenticated
  if (isAuthenticated === false) {
    return (
      <div className="max-w-md mx-auto my-10 p-6 bg-white rounded-lg shadow-lg">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto" />
          <h2 className="mt-2 text-xl font-semibold text-gray-800">Authentication Required</h2>
          <p className="mt-2 text-gray-600">
            You need to log in or create an account to submit crisis reports.
          </p>
          <div className="mt-6 flex flex-col space-y-3">
            <button
              onClick={() => navigate('/login?redirect=/crisis/report')}
              className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md"
            >
              Log In
            </button>
            <button
              onClick={() => navigate('/register?redirect=/crisis/report')}
              className="w-full py-2 px-4 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium rounded-md"
            >
              Create Account
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto my-8 p-6 bg-white rounded-lg shadow-lg">
      <div className="flex items-center mb-6">
        <AlertTriangle className="h-8 w-8 text-red-500" />
        <h1 className="text-2xl font-bold ml-2">Report Emergency Situation</h1>
      </div>
      
      {error && (
        <div className="mb-6 p-4 bg-red-100 border-l-4 border-red-500 text-red-700">
          <div className="flex">
            <AlertCircle className="h-5 w-5 mr-2" />
            <span>{error}</span>
          </div>
        </div>
      )}
      
      {success && (
        <div className="mb-6 p-4 bg-green-100 border-l-4 border-green-500 text-green-700">
          <div className="flex">
            <CheckCircle className="h-5 w-5 mr-2" />
            <span>{success}</span>
          </div>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Crisis Type */}
        <div>
          <label htmlFor="crisis_type" className="block text-sm font-medium text-gray-700 mb-1">
            Emergency Type *
          </label>
          <select
            id="crisis_type"
            name="crisis_type"
            value={formData.crisis_type}
            onChange={handleChange}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            required
          >
            <option value="">Select emergency type</option>
            {crisisTypes.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>
        
        {/* Location with geolocation button */}
        <div>
          <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
            Location *
          </label>
          <div className="mt-1 flex rounded-md shadow-sm">
            <input
              type="text"
              name="location"
              id="location"
              value={formData.location}
              onChange={handleChange}
              className="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-l-md border-gray-300 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              placeholder="Address or coordinates"
              required
            />
            {geolocationAvailable && (
              <button
                type="button"
                onClick={getCurrentLocation}
                disabled={isLoadingLocation}
                className="inline-flex items-center px-3 py-2 border border-l-0 border-gray-300 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-r-md"
              >
                {isLoadingLocation ? (
                  <Loader className="h-5 w-5 animate-spin" />
                ) : (
                  <MapPin className="h-5 w-5" />
                )}
              </button>
            )}
          </div>
          <p className="mt-1 text-xs text-gray-500">
            Provide the specific location of the emergency
          </p>
        </div>
        
        {/* Description */}
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
            Description *
          </label>
          <textarea
            id="description"
            name="description"
            rows={4}
            value={formData.description}
            onChange={handleChange}
            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            placeholder="Describe the emergency situation in detail"
            required
          />
        </div>
        
        {/* Severity */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Severity Level</label>
          <div className="flex items-center space-x-4">
            <label className="inline-flex items-center">
              <input
                type="radio"
                name="severity"
                value="low"
                checked={formData.severity === 'low'}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
              />
              <span className="ml-2 text-sm text-gray-700">Low</span>
            </label>
            <label className="inline-flex items-center">
              <input
                type="radio"
                name="severity"
                value="medium"
                checked={formData.severity === 'medium'}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
              />
              <span className="ml-2 text-sm text-gray-700">Medium</span>
            </label>
            <label className="inline-flex items-center">
              <input
                type="radio"
                name="severity"
                value="high"
                checked={formData.severity === 'high'}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
              />
              <span className="ml-2 text-sm text-gray-700">High</span>
            </label>
          </div>
        </div>
        
        {/* Photo Upload */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Upload Photo (Optional)
          </label>
          <div className="mt-1 flex items-center">
            <input
              type="file"
              id="photo"
              name="photo"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
            <label
              htmlFor="photo"
              className="cursor-pointer inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
            >
              <Camera className="h-5 w-5 mr-2" />
              Select Photo
            </label>
            {photoPreview && (
              <div className="ml-4">
                <img
                  src={photoPreview}
                  alt="Preview"
                  className="h-16 w-16 object-cover rounded"
                />
              </div>
            )}
          </div>
          <p className="mt-1 text-xs text-gray-500">
            A photo can help emergency responders assess the situation
          </p>
        </div>
        
        {/* Additional Information Checkboxes */}
        <div className="space-y-3">
          <div className="relative flex items-start">
            <div className="flex items-center h-5">
              <input
                id="has_injuries"
                name="has_injuries"
                type="checkbox"
                checked={formData.has_injuries}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="has_injuries" className="font-medium text-gray-700">
                Injuries Reported
              </label>
            </div>
          </div>
          
          <div className="relative flex items-start">
            <div className="flex items-center h-5">
              <input
                id="needs_evacuation"
                name="needs_evacuation"
                type="checkbox"
                checked={formData.needs_evacuation}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="needs_evacuation" className="font-medium text-gray-700">
                Evacuation Needed
              </label>
            </div>
          </div>
          
          <div className="relative flex items-start">
            <div className="flex items-center h-5">
              <input
                id="special_needs"
                name="special_needs"
                type="checkbox"
                checked={formData.special_needs}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="special_needs" className="font-medium text-gray-700">
                People with Special Needs (Medical, Accessibility)
              </label>
            </div>
          </div>
          
          <div className="relative flex items-start">
            <div className="flex items-center h-5">
              <input
                id="has_children"
                name="has_children"
                type="checkbox"
                checked={formData.has_children}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="has_children" className="font-medium text-gray-700">
                Children Present
              </label>
            </div>
          </div>
          
          <div className="relative flex items-start">
            <div className="flex items-center h-5">
              <input
                id="has_pets"
                name="has_pets"
                type="checkbox"
                checked={formData.has_pets}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="has_pets" className="font-medium text-gray-700">
                Pets/Animals Present
              </label>
            </div>
          </div>
          
          <div className="relative flex items-start">
            <div className="flex items-center h-5">
              <input
                id="transportation"
                name="transportation"
                type="checkbox"
                checked={formData.transportation}
                onChange={handleChange}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3 text-sm">
              <label htmlFor="transportation" className="font-medium text-gray-700">
                Have Access to Transportation
              </label>
            </div>
          </div>
        </div>
        
        {/* Submit Button */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 ${
              isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
            }`}
          >
            {isSubmitting ? (
              <>
                <Loader className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" />
                Submitting...
              </>
            ) : (
              <>
                Submit Emergency Report
                <ArrowRight className="ml-2 h-4 w-4" />
              </>
            )}
          </button>
        </div>
        
        <div className="text-xs text-gray-500 mt-4">
          <p className="font-semibold">Important Note:</p>
          <p>
            This crisis reporting system is not a replacement for emergency services.
            If you or someone else is in immediate danger, please call 911 or your local emergency number first.
          </p>
        </div>
      </form>
    </div>
  );
};

export default CrisisReportForm;