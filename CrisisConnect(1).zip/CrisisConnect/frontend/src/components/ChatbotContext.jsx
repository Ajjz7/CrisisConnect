import React, { createContext, useState, useContext, useEffect } from 'react';
import { MessageSquare, X } from 'lucide-react';
import Chatbot from './Chatbot';

// Create context
const ChatbotContext = createContext();

// Custom hook to use the chatbot context
export const useChatbot = () => useContext(ChatbotContext);

// Chatbot provider component
export const ChatbotProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [chatHistory, setChatHistory] = useState([]);
  
  // Toggle chatbot visibility
  const toggleChatbot = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setUnreadCount(0); // Reset unread count when opening
    }
  };
  
  // Add a new message to chat history
  const addMessage = (message) => {
    setChatHistory(prev => [...prev, message]);
    
    // If chatbot is closed and message is from bot, increment unread count
    if (!isOpen && message.type === 'bot') {
      setUnreadCount(prev => prev + 1);
    }
  };
  
  // Clear chat history
  const clearChat = () => {
    setChatHistory([
      {
        id: 1,
        type: 'bot',
        content: "Hello, I'm your Crisis Connect assistant. How can I help you today?",
        timestamp: new Date()
      }
    ]);
  };
  
  // Context value
  const value = {
    isOpen,
    toggleChatbot,
    chatHistory,
    addMessage,
    clearChat,
    unreadCount
  };
  
  return (
    <ChatbotContext.Provider value={value}>
      {children}
      
      {/* Floating chat button */}
      {!isOpen && (
        <button
          onClick={toggleChatbot}
          className="fixed bottom-6 right-6 z-40 bg-blue-600 text-white rounded-full p-4 shadow-lg hover:bg-blue-700 transition-all"
        >
          <MessageSquare className="h-6 w-6" />
          {unreadCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>
      )}
      
      {/* Chatbot dialog */}
      {isOpen && (
        <div className="fixed bottom-0 right-0 z-50 w-full md:w-96 h-full md:h-[600px] p-4">
          <div className="relative w-full h-full">
            <button
              onClick={toggleChatbot}
              className="absolute -top-3 -right-3 z-50 bg-gray-800 text-white rounded-full p-1 shadow-lg hover:bg-gray-900"
            >
              <X className="h-5 w-5" />
            </button>
            <Chatbot 
              addMessage={addMessage} 
              chatHistory={chatHistory} 
              setChatHistory={setChatHistory}
            />
          </div>
        </div>
      )}
    </ChatbotContext.Provider>
  );
};

// Mini chatbot widget for embedding in other pages
export const ChatbotEmbed = ({ minimal = false }) => {
  const { toggleChatbot, unreadCount } = useChatbot();
  
  return (
    <div className={`${minimal ? 'inline-block' : 'p-4 bg-blue-50 rounded-lg border border-blue-100'}`}>
      {!minimal && (
        <h3 className="font-medium text-lg mb-2">Need assistance?</h3>
      )}
      <button
        onClick={toggleChatbot}
        className={`
          flex items-center justify-center space-x-2 
          ${minimal 
            ? 'text-blue-600 hover:text-blue-800' 
            : 'bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg w-full'
          }
        `}
      >
        <MessageSquare className={`${minimal ? 'h-4 w-4' : 'h-5 w-5'}`} />
        <span>{minimal ? 'Chat' : 'Chat with Crisis Assistant'}</span>
        {unreadCount > 0 && (
          <span className="bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
            {unreadCount}
          </span>
        )}
      </button>
    </div>
  );
};

export default ChatbotContext;