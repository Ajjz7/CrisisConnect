import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { MapPin, AlertTriangle, Clock, UserCheck, UserX, ArrowLeft, ThumbsUp, ThumbsDown, Share, Shield, AlertCircle, CheckCircle, Camera, Users, Info, Loader, ExternalLink, Phone, Mail, Link as LinkIcon } from 'lucide-react';
import { GoogleMap, useLoadScript, Marker, Circle } from '@react-google-maps/api';

// Map container styles for details page
const mapContainerStyle = {
  width: '100%',
  height: '300px',
  borderRadius: '0.5rem',
};

// Default map options
const mapOptions = {
  disableDefaultUI: false,
  zoomControl: true,
  mapTypeControl: false,
  streetViewControl: false,
  fullscreenControl: false,
};

// Crisis type icons and info (matching the MapDisplay component)
const crisisTypeConfig = {
  // Weather-Related Disasters
  hurricane: { icon: '🌀', color: '#3498db', radius: 20000, safety: [
    "Stay indoors and away from windows",
    "Have emergency supplies ready",
    "Follow evacuation orders immediately",
    "Avoid flooded areas - turn around, don't drown"
  ]},
  tornado: { icon: '🌪️', color: '#34495e', radius: 5000, safety: [
    "Seek shelter in basement or interior room without windows",
    "Cover yourself with blankets or mattress if possible",
    "Stay away from windows and exterior doors",
    "After passing, beware of downed power lines and debris"
  ]},
  blizzard: { icon: '❄️', color: '#ecf0f1', radius: 15000, safety: [
    "Stay indoors and keep warm",
    "Conserve heat by closing off unused rooms",
    "Dress in layers if going outside is necessary",
    "Clear snow from exhaust pipes before starting vehicles"
  ]},
  heatwave: { icon: '☀️', color: '#f39c12', radius: 30000, safety: [
    "Stay hydrated and drink plenty of water",
    "Avoid strenuous activities during peak heat hours",
    "Use air conditioning or seek cooling centers",
    "Check on elderly neighbors and those with health conditions"
  ]},
  drought: { icon: '☀️', color: '#f39c12', radius: 50000, safety: [
    "Conserve water whenever possible",
    "Follow local water restriction guidelines",
    "Be alert for wildfire risks due to dry conditions",
    "Check on vulnerable individuals who may need assistance"
  ]},
  
  // Geological Disasters
  earthquake: { icon: '⚡', color: '#e67e22', radius: 25000, safety: [
    "Drop, Cover, and Hold On under sturdy furniture",
    "Stay away from windows and exterior walls",
    "If outdoors, move to open area away from buildings and power lines",
    "Be prepared for aftershocks"
  ]},
  tsunami: { icon: '🌊', color: '#3498db', radius: 15000, safety: [
    "Move immediately to higher ground if warning issued",
    "Stay away from the coast and low-lying areas",
    "Follow evacuation routes - not shortcuts",
    "Wait for official all-clear before returning"
  ]},
  landslide: { icon: '⛰️', color: '#795548', radius: 3000, safety: [
    "Evacuate immediately if signs of land movement",
    "Move uphill away from the slide path",
    "Listen for unusual sounds like trees cracking",
    "Watch for changes in landscape like tilting trees"
  ]},
  volcanic_eruption: { icon: '🌋', color: '#e74c3c', radius: 20000, safety: [
    "Evacuate areas at risk from lava flows and pyroclastic flows",
    "Protect against ash fall with masks and eye protection",
    "Clear roofs of ash to prevent collapse",
    "Follow evacuation orders immediately"
  ]},
  
  // Water-Related Disasters
  flood: { icon: '💧', color: '#3498db', radius: 10000, safety: [
    "Move to higher ground immediately",
    "Do not walk or drive through flood waters",
    "Turn around, don't drown - just 6 inches of water can knock you down",
    "Disconnect utilities if instructed by authorities"
  ]},
  flash_flood: { icon: '⚡💧', color: '#2980b9', radius: 5000, safety: [
    "Seek higher ground immediately",
    "Do not wait for official warnings if you see rising water",
    "Abandon vehicles if surrounded by rising water",
    "Be especially cautious at night when floods are harder to recognize"
  ]},
  dam_failure: { icon: '🏞️', color: '#2c3e50', radius: 15000, safety: [
    "Follow evacuation orders immediately - minutes count",
    "Move to higher ground as quickly as possible",
    "Do not return until officials indicate it is safe",
    "Be alert for road washouts and downed power lines"
  ]},
  
  // Fire-Related Disasters
  wildfire: { icon: '🔥', color: '#e74c3c', radius: 8000, safety: [
    "Follow evacuation orders immediately",
    "Close all windows and doors if indoors",
    "Wear masks or wet cloth over nose/mouth to filter smoke",
    "Stay tuned to emergency broadcasts for updates"
  ]},
  urban_fire: { icon: '🏢🔥', color: '#c0392b', radius: 2000, safety: [
    "Evacuate immediately - do not gather belongings",
    "Stay low to avoid smoke inhalation",
    "Test doors with back of hand before opening",
    "Once out, stay out - never re-enter a burning building"
  ]},
  
  // Biological Disasters
  pandemic: { icon: '🦠', color: '#9b59b6', radius: 100000, safety: [
    "Follow public health guidelines",
    "Practice social distancing and wear recommended PPE",
    "Wash hands frequently and disinfect high-touch surfaces",
    "Seek medical attention if showing symptoms"
  ]},
  epidemic: { icon: '😷', color: '#8e44ad', radius: 50000, safety: [
    "Follow guidelines from health authorities",
    "Maintain proper hygiene and handwashing",
    "Avoid close contact with others if recommended",
    "Seek medical care if experiencing symptoms"
  ]},
  biological_hazard: { icon: '☣️', color: '#2ecc71', radius: 10000, safety: [
    "Follow instructions from emergency responders",
    "Shelter in place if directed",
    "Turn off HVAC systems that could circulate contaminants",
    "Seek medical attention if exposed"
  ]},
  
  // Human-Caused Disasters
  chemical_spill: { icon: '⚗️', color: '#27ae60', radius: 5000, safety: [
    "Stay upwind and uphill from the spill area",
    "Seal windows and doors if sheltering in place",
    "Turn off HVAC systems that could circulate contaminated air",
    "Follow decontamination instructions if exposed"
  ]},
  radiation: { icon: '☢️', color: '#f1c40f', radius: 15000, safety: [
    "Follow evacuation orders immediately",
    "Shelter indoors if directed, closing all windows and vents",
    "Remove outer clothing and shower thoroughly if exposed",
    "Take potassium iodide only if instructed by authorities"
  ]},
  terrorism: { icon: '⚠️', color: '#e74c3c', radius: 3000, safety: [
    "Run - get away from the area if possible",
    "Hide - if you can't escape, find cover and stay quiet",
    "Tell - notify authorities when safe to do so",
    "Follow instructions from emergency personnel"
  ]},
  conflict: { icon: '⚔️', color: '#c0392b', radius: 10000, safety: [
    "Stay away from areas of active conflict",
    "Remain in secure shelter until situation stabilizes",
    "Keep emergency supplies including food, water, and medications",
    "Follow instructions from emergency services"
  ]},
  infrastructure_failure: { icon: '🏗️', color: '#7f8c8d', radius: 2000, safety: [
    "Evacuate affected areas if instructed",
    "Stay clear of damaged structures and utilities",
    "Report gas leaks, downed power lines, or water main breaks",
    "Be prepared for service disruptions"
  ]}
};

// Default crisis config
const defaultCrisisConfig = { 
  icon: '⚠️', 
  color: '#e74c3c',
  radius: 5000,
  safety: [
    "Follow instructions from local emergency officials",
    "Have emergency supplies ready including food, water, and medications",
    "Stay informed through official channels",
    "Check on vulnerable neighbors if safe to do so"
  ]
};

const CrisisReportDetail = () => {
  const { reportId } = useParams();
  const navigate = useNavigate();
  
  // Component state
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userVote, setUserVote] = useState(null);
  const [votingInProgress, setVotingInProgress] = useState(false);
  const [matchedResources, setMatchedResources] = useState([]);
  const [resourcesLoading, setResourcesLoading] = useState(false);
  const [showShareOptions, setShowShareOptions] = useState(false);
  
  // Load Google Maps API
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
  });
  
  // Fetch report data on mount
  useEffect(() => {
    const fetchReportData = async () => {
      setLoading(true);
      try {
        // Fetch report data from API
        const response = await fetch(`/api/crisis-report/${reportId}`, {
          credentials: 'include'
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch crisis report');
        }
        
        const data = await response.json();
        setReport(data);
        
        // Check if user has already voted
        if (data.user_vote) {
          setUserVote(data.user_vote);
        }
        
        // Fetch AI-matched resources
        fetchMatchedResources(data);
      } catch (err) {
        console.error('Error fetching report:', err);
        setError('Failed to load report data. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchReportData();
  }, [reportId]);
  
  // Fetch AI-matched resources
  const fetchMatchedResources = async (reportData) => {
    setResourcesLoading(true);
    try {
      const response = await fetch('/ai/match_resources', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          location: reportData.location,
          crisis_type: reportData.crisis_type,
          severity: reportData.severity,
          special_needs: reportData.special_needs,
          has_children: reportData.has_children,
          has_pets: reportData.has_pets,
          transportation: reportData.transportation
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        setMatchedResources(data.matched_resources || []);
      }
    } catch (error) {
      console.error('Error fetching resources:', error);
    } finally {
      setResourcesLoading(false);
    }
  };
  
  // Handle vote submission
  const handleVote = async (voteType) => {
    // Skip if already voting or already voted the same
    if (votingInProgress || userVote === voteType) return;
    
    setVotingInProgress(true);
    
    try {
      const response = await fetch(`/crisis/vote/${reportId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vote: voteType
        }),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Update report with new trust score
        setReport(prev => ({
          ...prev,
          trust_score: data.new_trust_score,
          upvotes: voteType === 'up' ? prev.upvotes + 1 : prev.upvotes,
          downvotes: voteType === 'down' ? prev.downvotes + 1 : prev.downvotes
        }));
        
        // Update user vote
        setUserVote(voteType);
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to submit vote');
      }
    } catch (error) {
      console.error('Error voting:', error);
    } finally {
      setVotingInProgress(false);
    }
  };
  
  // Share report
  const shareReport = async (platform) => {
    const shareUrl = `${window.location.origin}/crisis/report/${reportId}`;
    const shareText = `Crisis Alert: ${report.crisis_type} reported at ${report.location}. Check for details and safety information.`;
    
    switch (platform) {
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`, '_blank');
        break;
      case 'email':
        window.open(`mailto:?subject=Crisis Alert&body=${encodeURIComponent(shareText + '\n\n' + shareUrl)}`, '_blank');
        break;
      case 'copy':
        navigator.clipboard.writeText(shareUrl);
        alert('Link copied to clipboard!');
        break;
      default:
        break;
    }
    
    setShowShareOptions(false);
  };
  
  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };
  
  // Get configuration for a crisis type (icon, color)
  const getCrisisConfig = (type) => {
    return crisisTypeConfig[type] || defaultCrisisConfig;
  };
  
  // Render loading state
  if (loading) {
    return (
      <div className="max-w-4xl mx-auto my-8 p-6">
        <div className="flex flex-col items-center justify-center py-12">
          <Loader className="h-10 w-10 text-blue-500 animate-spin" />
          <p className="mt-4 text-gray-600">Loading crisis report...</p>
        </div>
      </div>
    );
  }
  
  // Render error state
  if (error || !report) {
    return (
      <div className="max-w-4xl mx-auto my-8 p-6 bg-white rounded-lg shadow-lg">
        <div className="flex flex-col items-center justify-center py-12">
          <AlertCircle className="h-12 w-12 text-red-500" />
          <h2 className="mt-2 text-xl font-semibold">Error Loading Report</h2>
          <p className="mt-2 text-gray-600">{error || 'Report not found'}</p>
          <button
            onClick={() => navigate('/crisis/map')}
            className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Return to Crisis Map
          </button>
        </div>
      </div>
    );
  }
  
  // Extract location coordinates
  const locationCoords = {
    lat: parseFloat(report.location.split(',')[0]),
    lng: parseFloat(report.location.split(',')[1]),
  };
  
  // Get crisis type configuration
  const crisisConfig = getCrisisConfig(report.crisis_type);
  
  return (
    <div className="max-w-4xl mx-auto my-8 p-6 bg-white rounded-lg shadow-lg">
      {/* Back button */}
      <Link to="/crisis/map" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6">
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Crisis Map
      </Link>
      
      {/* Crisis header */}
      <div className="flex items-start border-b border-gray-200 pb-6 mb-6">
        <div className="text-3xl mr-3">{crisisConfig.icon}</div>
        <div className="flex-1">
          <div className="flex items-center flex-wrap gap-2">
            <h1 className="text-2xl font-bold mr-2">
              {report.crisis_type.replace(/_/g, ' ')}
            </h1>
            <span className={`text-sm px-2 py-0.5 rounded-full ${
              report.severity === 'high' ? 'bg-red-100 text-red-800' :
              report.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
              'bg-blue-100 text-blue-800'
            }`}>
              {report.severity} severity
            </span>
            {report.has_injuries && (
              <span className="text-sm bg-red-100 text-red-800 px-2 py-0.5 rounded-full">
                Injuries Reported
              </span>
            )}
            {report.trust_score >= 70 ? (
              <span className="text-sm bg-green-100 text-green-800 px-2 py-0.5 rounded-full flex items-center">
                <UserCheck className="h-3 w-3 mr-1" />
                Verified ({report.trust_score}%)
              </span>
            ) : (
              <span className="text-sm bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded-full flex items-center">
                <UserX className="h-3 w-3 mr-1" />
                Unverified ({report.trust_score}%)
              </span>
            )}
          </div>
          <div className="flex items-center text-gray-500 mt-2">
            <Clock className="h-4 w-4 mr-1" />
            <span className="text-sm">Reported {formatDate(report.created_at)}</span>
          </div>
          <div className="flex items-center text-gray-500 mt-1">
            <MapPin className="h-4 w-4 mr-1" />
            <span className="text-sm">{report.location}</span>
          </div>
          
          {/* Responder notification status */}
          {report.responder_notified ? (
            <div className="mt-3 text-green-700 bg-green-50 px-3 py-1.5 rounded-md inline-flex items-center">
              <CheckCircle className="h-4 w-4 mr-1" />
              Responders have been notified
            </div>
          ) : (
            <div className="mt-3 text-yellow-700 bg-yellow-50 px-3 py-1.5 rounded-md inline-flex items-center">
              <Info className="h-4 w-4 mr-1" />
              Report being assessed by system
            </div>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          {/* Description */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-2">Description</h2>
            <p className="text-gray-800 whitespace-pre-line">{report.description}</p>
          </div>
          
          {/* Map */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-2">Location</h2>
            {isLoaded ? (
              <div className="h-64 relative overflow-hidden rounded-lg">
                <GoogleMap
                  mapContainerStyle={mapContainerStyle}
                  center={locationCoords}
                  zoom={13}
                  options={mapOptions}
                >
                  <Marker
                    position={locationCoords}
                    icon={{
                      path: window.google.maps.SymbolPath.CIRCLE,
                      scale: 10,
                      fillColor: crisisConfig.color,
                      fillOpacity: 0.8,
                      strokeColor: report.trust_score > 70 ? '#2ecc71' : '#f39c12',
                      strokeWeight: 2,
                    }}
                  />
                  
                  <Circle
                    center={locationCoords}
                    options={{
                      fillColor: crisisConfig.color,
                      fillOpacity: 0.1,
                      strokeColor: crisisConfig.color,
                      strokeOpacity: 0.3,
                      strokeWeight: 1,
                      radius: crisisConfig.radius || 5000,
                    }}
                  />
                </GoogleMap>
              </div>
            ) : (
              <div className="h-64 bg-gray-100 flex items-center justify-center rounded-lg">
                <Loader className="h-8 w-8 text-gray-400 animate-spin" />
              </div>
            )}
          </div>
          
          {/* Photo if available */}
          {report.photo_url && (
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-2">Photo</h2>
              <div className="relative">
                <img 
                  src={report.photo_url} 
                  alt="Crisis situation" 
                  className="w-full rounded-lg object-cover max-h-96"
                />
                <div className="absolute top-2 left-2 bg-black bg-opacity-60 text-white p-1 rounded">
                  <Camera className="h-4 w-4" />
                </div>
              </div>
            </div>
          )}
          
          {/* Additional details */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-2">Additional Details</h2>
            <div className="grid grid-cols-2 gap-4 mt-3">
              {report.needs_evacuation && (
                <div className="flex items-center text-sm bg-red-50 p-2 rounded border border-red-100">
                  <AlertTriangle className="h-4 w-4 text-red-500 mr-2" />
                  Evacuation Needed
                </div>
              )}
              {report.special_needs && (
                <div className="flex items-center text-sm bg-purple-50 p-2 rounded border border-purple-100">
                  <Users className="h-4 w-4 text-purple-500 mr-2" />
                  Special Needs Present
                </div>
              )}
              {report.has_children && (
                <div className="flex items-center text-sm bg-blue-50 p-2 rounded border border-blue-100">
                  <Users className="h-4 w-4 text-blue-500 mr-2" />
                  Children Present
                </div>
              )}
              {report.has_pets && (
                <div className="flex items-center text-sm bg-green-50 p-2 rounded border border-green-100">
                  <Users className="h-4 w-4 text-green-500 mr-2" />
                  Pets/Animals Present
                </div>
              )}
              {!report.transportation && (
                <div className="flex items-center text-sm bg-yellow-50 p-2 rounded border border-yellow-100">
                  <AlertCircle className="h-4 w-4 text-yellow-500 mr-2" />
                  Transportation Needed
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div>
          {/* Safety Information */}
          <div className="bg-yellow-50 rounded-lg p-4 mb-6 border border-yellow-100">
            <h2 className="text-lg font-semibold flex items-center mb-3">
              <Shield className="h-5 w-5 text-yellow-700 mr-2" />
              Safety Information
            </h2>
            <ul className="space-y-2">
              {crisisConfig.safety.map((instruction, idx) => (
                <li key={idx} className="flex items-start">
                  <span className="text-yellow-700 mr-2">•</span>
                  <span className="text-gray-800 text-sm">{instruction}</span>
                </li>
              ))}
            </ul>
            <div className="mt-4 pt-3 border-t border-yellow-200">
              <Link 
                to={`/resources/${report.crisis_type}`} 
                className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
              >
                View Complete Safety Guide
                <ArrowLeft className="h-3 w-3 ml-1 transform rotate-180" />
              </Link>
            </div>
          </div>
          
          {/* Resources */}
          <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
            <h2 className="text-lg font-semibold flex items-center mb-3">
              <Shield className="h-5 w-5 text-blue-600 mr-2" />
              Emergency Resources
            </h2>
            
            {resourcesLoading ? (
              <div className="flex items-center justify-center py-4">
                <Loader className="h-5 w-5 text-blue-500 animate-spin mr-2" />
                <span className="text-sm text-gray-600">Loading resources...</span>
              </div>
            ) : matchedResources.length > 0 ? (
              <ul className="space-y-2 max-h-64 overflow-y-auto">
                {matchedResources.slice(0, 8).map((resource, idx) => (
                  <li key={idx} className="text-sm flex items-start">
                    <Shield className="h-4 w-4 text-blue-500 mr-2 mt-0.5" />
                    <span>{resource}</span>
                  </li>
                ))}
                {matchedResources.length > 8 && (
                  <li className="text-xs text-center text-gray-500 pt-1">
                    + {matchedResources.length - 8} more resources available
                  </li>
                )}
              </ul>
            ) : (
              <p className="text-sm text-gray-600">
                No specific resources available for this location.
              </p>
            )}
            
            <div className="mt-4 pt-3 border-t border-gray-100">
              <Link 
                to={`/resources?type=${report.crisis_type}&location=${encodeURIComponent(report.location)}`} 
                className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
              >
                View All Available Resources
                <ArrowLeft className="h-3 w-3 ml-1 transform rotate-180" />
              </Link>
            </div>
          </div>
          
          {/* Actions */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h2 className="text-md font-semibold mb-3">Report Actions</h2>
            
            {/* Voting */}
            <div className="flex mb-4 space-x-2">
              <button
                onClick={() => handleVote('up')}
                disabled={votingInProgress}
                className={`flex-1 py-2 rounded-md flex items-center justify-center ${
                  userVote === 'up'
                    ? 'bg-green-100 text-green-800 border border-green-200'
                    : 'bg-white border text-gray-700 hover:bg-gray-50'
                }`}
              >
                <ThumbsUp className={`h-4 w-4 mr-1 ${userVote === 'up' ? 'text-green-700' : ''}`} />
                Confirm ({report.upvotes || 0})
              </button>
              
              <button
                onClick={() => handleVote('down')}
                disabled={votingInProgress}
                className={`flex-1 py-2 rounded-md flex items-center justify-center ${
                  userVote === 'down'
                    ? 'bg-red-100 text-red-800 border border-red-200'
                    : 'bg-white border text-gray-700 hover:bg-gray-50'
                }`}
              >
                <ThumbsDown className={`h-4 w-4 mr-1 ${userVote === 'down' ? 'text-red-700' : ''}`} />
                Dispute ({report.downvotes || 0})
              </button>
            </div>
            
            {/* Share button */}
            <div className="relative">
              <button
                onClick={() => setShowShareOptions(!showShareOptions)}
                className="w-full py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center justify-center"
              >
                <Share className="h-4 w-4 mr-1" />
                Share This Report
              </button>
              
              {/* Share options */}
              {showShareOptions && (
                <div className="absolute top-full left-0 right-0 mt-2 p-2 bg-white rounded-md shadow-lg z-10 border border-gray-200">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => shareReport('twitter')}
                      className="p-2 text-sm hover:bg-gray-100 rounded flex items-center"
                    >
                      <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M23.44 4.83c-.8.37-1.5.38-2.22.02.93-.56.98-.96 1.32-2.02-.88.52-1.86.9-2.9 1.1-.82-.88-2-1.43-3.3-1.43-2.5 0-4.55 2.04-4.55 4.54 0 .36.03.7.1 1.04-3.77-.2-7.12-2-9.36-4.75-.4.67-.6 1.45-.6 2.3 0 1.56.8 2.95 2 3.77-.74-.03-1.44-.23-2.05-.57v.06c0 2.2 1.56 4.03 3.64 4.44-.67.2-1.37.2-2.06.08.58 1.8 2.26 3.12 4.25 3.16-1.9 1.47-4.3 2.35-6.9 2.35-.45 0-.9-.02-1.3-.08 2.46 1.57 5.36 2.5 8.5 2.5 10.18 0 15.74-8.4 15.74-15.66 0-.23 0-.46-.02-.7.86-.6 1.62-1.36 2.2-2.23z" />
</svg>
                      Twitter
                    </button>
                    <button
                      onClick={() => shareReport('facebook')}
                      className="p-2 text-sm hover:bg-gray-100 rounded flex items-center"
                    >
                      <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M22.5 0c.83 0 1.5.67 1.5 1.5v21c0 .83-.67 1.5-1.5 1.5h-6v-9h3l.75-3.75H16.5v-1.5c0-1.5.75-2.25 2.25-2.25h1.75V3.75h-1.75C15.5 3.75 14 5.25 14 7.5v2.25h-3v3.75h3V24h-8.5c-.83 0-1.5-.67-1.5-1.5v-21C0 .67.67 0 1.5 0h21z" />
                      </svg>
                      Facebook
                    </button>
                    <button
                      onClick={() => shareReport('whatsapp')}
                      className="p-2 text-sm hover:bg-gray-100 rounded flex items-center"
                    >
                      <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.652a11.882 11.882 0 005.71 1.447h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                      </svg>
                      WhatsApp
                    </button>
                    <button
                      onClick={() => shareReport('email')}
                      className="p-2 text-sm hover:bg-gray-100 rounded flex items-center"
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Email
                    </button>
                    <button
                      onClick={() => shareReport('copy')}
                      className="p-2 text-sm hover:bg-gray-100 rounded flex items-center col-span-2"
                    >
                      <LinkIcon className="h-4 w-4 mr-2" />
                      Copy Link
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CrisisReportDetail;

