import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, AlertTriangle, User, LogOut, MapPin, MessageSquare, Shield, Award } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in on component mount
    const checkAuthStatus = async () => {
      try {
        const response = await fetch('/dashboard', {
          credentials: 'include' // Important for cookies/session
        });
        
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        }
      } catch (error) {
        console.error('Error checking authentication status:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  const handleLogout = async () => {
    try {
      await fetch('/logout', {
        method: 'GET',
        credentials: 'include'
      });
      
      setUser(null);
      navigate('/');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="bg-blue-700 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <AlertTriangle className="h-8 w-8 text-yellow-300" />
              <span className="ml-2 text-xl font-bold text-white">Crisis Connect</span>
            </Link>
          </div>
          
          {/* Desktop menu */}
          <div className="hidden md:flex md:items-center md:space-x-4">
            <Link to="/crisis/map" className="text-white hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium flex items-center">
              <MapPin className="mr-1 h-4 w-4" />
              Crisis Map
            </Link>
            <Link to="/crisis/report" className="text-white hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium flex items-center">
              <AlertTriangle className="mr-1 h-4 w-4" />
              Report Crisis
            </Link>
            <Link to="/resources" className="text-white hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium flex items-center">
              <Shield className="mr-1 h-4 w-4" />
              Resources
            </Link>
            <Link to="/ai-chat" className="text-white hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium flex items-center">
              <MessageSquare className="mr-1 h-4 w-4" />
              AI Support
            </Link>
            
            {loading ? (
              <div className="px-3 py-2 text-sm text-gray-200">Loading...</div>
            ) : user ? (
              <>
                <Link to="/dashboard" className="text-white hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium flex items-center">
                  <User className="mr-1 h-4 w-4" />
                  {user.firstName || 'Dashboard'}
                </Link>
                {user.role === 'responder' && (
                  <Link to="/responder" className="bg-green-600 text-white hover:bg-green-700 px-3 py-2 rounded-md text-sm font-medium flex items-center">
                    <Award className="mr-1 h-4 w-4" />
                    Responder Panel
                  </Link>
                )}
                <button
                  onClick={handleLogout}
                  className="text-white hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium flex items-center"
                >
                  <LogOut className="mr-1 h-4 w-4" />
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-white hover:bg-blue-600 px-3 py-2 rounded-md text-sm font-medium">
                  Login
                </Link>
                <Link to="/register" className="bg-yellow-500 text-blue-900 hover:bg-yellow-400 px-3 py-2 rounded-md text-sm font-medium">
                  Register
                </Link>
              </>
            )}
          </div>
          
          {/* Mobile menu button */}
          <div className="flex md:hidden items-center">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-white hover:text-white hover:bg-blue-600 focus:outline-none"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-blue-800">
            <Link 
              to="/crisis/map" 
              className="text-white hover:bg-blue-600 block px-3 py-2 rounded-md text-base font-medium flex items-center"
              onClick={() => setIsOpen(false)}
            >
              <MapPin className="mr-2 h-4 w-4" />
              Crisis Map
            </Link>
            <Link 
              to="/crisis/report" 
              className="text-white hover:bg-blue-600 block px-3 py-2 rounded-md text-base font-medium flex items-center"
              onClick={() => setIsOpen(false)}
            >
              <AlertTriangle className="mr-2 h-4 w-4" />
              Report Crisis
            </Link>
            <Link 
              to="/resources" 
              className="text-white hover:bg-blue-600 block px-3 py-2 rounded-md text-base font-medium flex items-center"
              onClick={() => setIsOpen(false)}
            >
              <Shield className="mr-2 h-4 w-4" />
              Resources
            </Link>
            <Link 
              to="/ai-chat" 
              className="text-white hover:bg-blue-600 block px-3 py-2 rounded-md text-base font-medium flex items-center"
              onClick={() => setIsOpen(false)}
            >
              <MessageSquare className="mr-2 h-4 w-4" />
              AI Support
            </Link>
            
            {loading ? (
              <div className="px-3 py-2 text-sm text-gray-200">Loading...</div>
            ) : user ? (
              <>
                <Link 
                  to="/dashboard" 
                  className="text-white hover:bg-blue-600 block px-3 py-2 rounded-md text-base font-medium flex items-center"
                  onClick={() => setIsOpen(false)}
                >
                  <User className="mr-2 h-4 w-4" />
                  Profile ({user.firstName})
                </Link>
                {user.role === 'responder' && (
                  <Link 
                    to="/responder" 
                    className="bg-green-600 text-white hover:bg-green-700 block px-3 py-2 rounded-md text-base font-medium flex items-center"
                    onClick={() => setIsOpen(false)}
                  >
                    <Award className="mr-2 h-4 w-4" />
                    Responder Panel
                  </Link>
                )}
                <button
                  onClick={() => {
                    handleLogout();
                    setIsOpen(false);
                  }}
                  className="text-white hover:bg-blue-600 w-full text-left block px-3 py-2 rounded-md text-base font-medium flex items-center"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="text-white hover:bg-blue-600 block px-3 py-2 rounded-md text-base font-medium"
                  onClick={() => setIsOpen(false)}
                >
                  Login
                </Link>
                <Link 
                  to="/register" 
                  className="bg-yellow-500 text-blue-900 hover:bg-yellow-400 block px-3 py-2 rounded-md text-base font-medium"
                  onClick={() => setIsOpen(false)}
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;