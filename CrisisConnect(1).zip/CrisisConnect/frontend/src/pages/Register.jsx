import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, User, Mail, Lock, AlertTriangle, CheckCircle, Eye, EyeOff, Loader, ChevronLeft, Info, CheckSquare } from 'lucide-react';

const Register = () => {
  const navigate = useNavigate();
  
  // Form state
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'responder', // Default role: 'responder', 'coordinator', 'admin'
    organization: '',
    phone: '',
    agreeToTerms: false,
    subscribeToUpdates: false
  });
  
  // UI state
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [currentStep, setCurrentStep] = useState(1); // Registration is split into 2 steps
  
  // Handle input changes
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
    
    // Clear field-specific error when user types
    if (formErrors[name]) {
      setFormErrors({
        ...formErrors,
        [name]: null,
      });
    }
  };
  
  // Validate step 1 of the form
  const validateStep1 = () => {
    const errors = {};
    
    // First name validation
    if (!formData.firstName.trim()) {
      errors.firstName = 'First name is required';
    }
    
    // Last name validation
    if (!formData.lastName.trim()) {
      errors.lastName = 'Last name is required';
    }
    
    // Email validation
    if (!formData.email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Email is invalid';
    }
    
    // Password validation
    if (!formData.password) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) {
      errors.password = 'Password must include uppercase, lowercase, and numbers';
    }
    
    // Confirm password validation
    if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Validate step 2 of the form
  const validateStep2 = () => {
    const errors = {};
    
    // Role validation
    if (!formData.role) {
      errors.role = 'Please select a role';
    }
    
    // Organization validation
    if (formData.role !== 'civilian' && !formData.organization.trim()) {
      errors.organization = 'Organization name is required for this role';
    }
    
    // Phone validation (optional but must be valid if provided)
    if (formData.phone && !/^\+?[\d\s-]{10,15}$/.test(formData.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
    
    // Terms agreement validation
    if (!formData.agreeToTerms) {
      errors.agreeToTerms = 'You must agree to the terms and conditions';
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  // Move to next step
  const handleNextStep = (e) => {
    e.preventDefault();
    
    if (validateStep1()) {
      setCurrentStep(2);
      // Clear any previous general errors
      setError(null);
    }
  };
  
  // Go back to previous step
  const handlePreviousStep = () => {
    setCurrentStep(1);
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate step 2
    if (!validateStep2()) {
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // Call registration API
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          first_name: formData.firstName,
          last_name: formData.lastName,
          email: formData.email,
          password: formData.password,
          role: formData.role,
          organization: formData.organization,
          phone: formData.phone,
          subscribe_to_updates: formData.subscribeToUpdates
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Registration failed. Please try again.');
      }
      
      // Registration successful
      setRegistrationSuccess(true);
      
      // Automatically redirect to login after 3 seconds
      setTimeout(() => {
        navigate('/login');
      }, 3000);
      
    } catch (err) {
      console.error('Registration error:', err);
      setError(err.message || 'An unexpected error occurred. Please try again.');
      // If error is email already exists, scroll to email field
      if (err.message.includes('email')) {
        setCurrentStep(1);
        setFormErrors({
          ...formErrors,
          email: 'This email is already registered'
        });
      }
    } finally {
      setLoading(false);
    }
  };
  
  // Get password strength indicator
  const getPasswordStrength = () => {
    const { password } = formData;
    if (!password) return { strength: 0, label: '', color: 'bg-gray-200' };
    
    // Check password strength
    let strength = 0;
    if (password.length >= 8) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/\d/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    // Map strength to label and color
    const strengthMap = [
      { label: 'Very Weak', color: 'bg-red-500' },
      { label: 'Weak', color: 'bg-orange-500' },
      { label: 'Medium', color: 'bg-yellow-500' },
      { label: 'Strong', color: 'bg-green-500' },
      { label: 'Very Strong', color: 'bg-green-600' }
    ];
    
    return {
      strength: Math.min(strength, 5),
      label: strengthMap[Math.min(strength - 1, 4)].label,
      color: strength > 0 ? strengthMap[Math.min(strength - 1, 4)].color : 'bg-gray-200'
    };
  };
  
  // If registration is successful, show success message
  if (registrationSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
            <div className="text-center">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
              <h2 className="mt-4 text-2xl font-bold text-gray-900">Registration Successful!</h2>
              <p className="mt-2 text-gray-600">
                Your account has been created successfully. You will be redirected to the login page shortly.
              </p>
              <div className="mt-6">
                <Link
                  to="/login"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Go to Login
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <Shield className="h-12 w-12 text-red-600" />
        </div>
        <h2 className="mt-3 text-center text-3xl font-bold text-gray-900">
          Create your account
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Join the Crisis Response Platform to report and monitor emergency events
        </p>
      </div>
      
      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          {/* Progress indicator */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-gray-500">
                Step {currentStep} of 2
              </div>
              <div className="w-2/3 bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-blue-600 h-2.5 rounded-full" 
                  style={{ width: currentStep === 1 ? '50%' : '100%' }}
                ></div>
              </div>
            </div>
          </div>
          
          {/* Form error */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
              <div className="flex">
                <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          )}
          
          <form>
            {/* Step 1: Basic Information */}
            {currentStep === 1 && (
              <>
                <div className="space-y-6">
                  {/* Name fields (first and last name in a row) */}
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    {/* First Name */}
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">
                        First Name
                      </label>
                      <div className="mt-1">
                        <input
                          id="firstName"
                          name="firstName"
                          type="text"
                          autoComplete="given-name"
                          value={formData.firstName}
                          onChange={handleChange}
                          className={`block w-full px-3 py-2 border ${
                            formErrors.firstName ? 'border-red-300' : 'border-gray-300'
                          } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                        />
                        {formErrors.firstName && (
                          <p className="mt-1 text-sm text-red-600">{formErrors.firstName}</p>
                        )}
                      </div>
                    </div>
                    
                    {/* Last Name */}
                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">
                        Last Name
                      </label>
                      <div className="mt-1">
                        <input
                          id="lastName"
                          name="lastName"
                          type="text"
                          autoComplete="family-name"
                          value={formData.lastName}
                          onChange={handleChange}
                          className={`block w-full px-3 py-2 border ${
                            formErrors.lastName ? 'border-red-300' : 'border-gray-300'
                          } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                        />
                        {formErrors.lastName && (
                          <p className="mt-1 text-sm text-red-600">{formErrors.lastName}</p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email Address
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        autoComplete="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`block w-full pl-10 px-3 py-2 border ${
                          formErrors.email ? 'border-red-300' : 'border-gray-300'
                        } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                        placeholder="you@example.com"
                      />
                    </div>
                    {formErrors.email && (
                      <p className="mt-1 text-sm text-red-600">{formErrors.email}</p>
                    )}
                  </div>
                  
                  {/* Password */}
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                      Password
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Lock className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="password"
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        value={formData.password}
                        onChange={handleChange}
                        className={`block w-full pl-10 pr-10 px-3 py-2 border ${
                          formErrors.password ? 'border-red-300' : 'border-gray-300'
                        } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                        placeholder="••••••••"
                      />
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="text-gray-400 hover:text-gray-500 focus:outline-none"
                        >
                          {showPassword ? (
                            <EyeOff className="h-5 w-5" />
                          ) : (
                            <Eye className="h-5 w-5" />
                          )}
                        </button>
                      </div>
                    </div>
                    {formErrors.password && (
                      <p className="mt-1 text-sm text-red-600">{formErrors.password}</p>
                    )}
                    
                    {/* Password strength indicator */}
                    {formData.password && (
                      <div className="mt-2">
                        <div className="flex items-center justify-between mb-1">
                          <div className="text-xs text-gray-500">Password strength:</div>
                          <div className="text-xs font-medium" style={{ color: getPasswordStrength().color.replace('bg-', 'text-') }}>
                            {getPasswordStrength().label}
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className={`${getPasswordStrength().color} h-1.5 rounded-full`} 
                            style={{ width: `${(getPasswordStrength().strength / 5) * 100}%` }}
                          ></div>
                        </div>
                        <div className="mt-2 text-xs text-gray-500">
                          <p>Password must:</p>
                          <ul className="mt-1 ml-4 list-disc">
                            <li className={formData.password.length >= 8 ? 'text-green-600' : ''}>
                              Be at least 8 characters long
                            </li>
                            <li className={/[A-Z]/.test(formData.password) ? 'text-green-600' : ''}>
                              Include at least one uppercase letter
                            </li>
                            <li className={/[a-z]/.test(formData.password) ? 'text-green-600' : ''}>
                              Include at least one lowercase letter
                            </li>
                            <li className={/\d/.test(formData.password) ? 'text-green-600' : ''}>
                              Include at least one number
                            </li>
                          </ul>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Confirm Password */}
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                      Confirm Password
                    </label>
                    <div className="mt-1 relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Lock className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        id="confirmPassword"
                        name="confirmPassword"
                        type={showConfirmPassword ? 'text' : 'password'}
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        className={`block w-full pl-10 pr-10 px-3 py-2 border ${
                          formErrors.confirmPassword ? 'border-red-300' : 'border-gray-300'
                        } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                        placeholder="••••••••"
                      />
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="text-gray-400 hover:text-gray-500 focus:outline-none"
                        >
                          {showConfirmPassword ? (
                            <EyeOff className="h-5 w-5" />
                          ) : (
                            <Eye className="h-5 w-5" />
                          )}
                        </button>
                      </div>
                    </div>
                    {formErrors.confirmPassword && (
                      <p className="mt-1 text-sm text-red-600">{formErrors.confirmPassword}</p>
                    )}
                  </div>
                </div>
                
                {/* Step 1 Navigation */}
                <div className="mt-6">
                  <button
                    type="button"
                    onClick={handleNextStep}
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Continue
                  </button>
                </div>
              </>
            )}
            
            {/* Step 2: Additional Information */}
            {currentStep === 2 && (
              <>
                <div className="space-y-6">
                  {/* User Role */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      What best describes your role?
                    </label>
                    <div className="space-y-2">
                      <div className={`relative border rounded-md px-3 py-2 ${formData.role === 'responder' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}>
                        <label className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            name="role"
                            value="responder"
                            checked={formData.role === 'responder'}
                            onChange={handleChange}
                            className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                          />
                          <span className="ml-3 text-sm font-medium text-gray-900">First Responder</span>
                        </label>
                        <p className="mt-1 ml-7 text-xs text-gray-500">Emergency services, firefighters, medical personnel, etc.</p>
                      </div>
                      
                      <div className={`relative border rounded-md px-3 py-2 ${formData.role === 'coordinator' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}>
                        <label className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            name="role"
                            value="coordinator"
                            checked={formData.role === 'coordinator'}
                            onChange={handleChange}
                            className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                          />
                          <span className="ml-3 text-sm font-medium text-gray-900">Emergency Coordinator</span>
                        </label>
                        <p className="mt-1 ml-7 text-xs text-gray-500">Government officials, emergency managers, NGO coordinators</p>
                      </div>
                      
                      <div className={`relative border rounded-md px-3 py-2 ${formData.role === 'civilian' ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}>
                        <label className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            name="role"
                            value="civilian"
                            checked={formData.role === 'civilian'}
                            onChange={handleChange}
                            className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                          />
                          <span className="ml-3 text-sm font-medium text-gray-900">Civilian Reporter</span>
                        </label>
                        <p className="mt-1 ml-7 text-xs text-gray-500">General public, volunteers, community members</p>
                      </div>
                    </div>
                    {formErrors.role && (
                      <p className="mt-1 text-sm text-red-600">{formErrors.role}</p>
                    )}
                  </div>
                  
                  {/* Organization */}
                  <div>
                    <label htmlFor="organization" className="block text-sm font-medium text-gray-700">
                      Organization {formData.role !== 'civilian' && <span className="text-red-500">*</span>}
                    </label>
                    <div className="mt-1">
                      <input
                        id="organization"
                        name="organization"
                        type="text"
                        value={formData.organization}
                        onChange={handleChange}
                        className={`block w-full px-3 py-2 border ${
                          formErrors.organization ? 'border-red-300' : 'border-gray-300'
                        } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                        placeholder={formData.role === 'responder' ? "Fire Department, Police, Hospital, etc." : "Agency, NGO, Company, etc."}
                      />
                      {formErrors.organization && (
                        <p className="mt-1 text-sm text-red-600">{formErrors.organization}</p>
                      )}
                    </div>
                  </div>
                  
                  {/* Phone Number */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                      Phone Number (Optional)
                    </label>
                    <div className="mt-1">
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        autoComplete="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        className={`block w-full px-3 py-2 border ${
                          formErrors.phone ? 'border-red-300' : 'border-gray-300'
                        } rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm`}
                        placeholder="+1 (555) 123-4567"
                      />
                      {formErrors.phone && (
                        <p className="mt-1 text-sm text-red-600">{formErrors.phone}</p>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      For emergency notifications only. We'll never share your number.
                    </p>
                  </div>
                  
                  {/* Terms and Conditions */}
                  <div className="space-y-3">
                    <div className={formErrors.agreeToTerms ? 'border border-red-300 rounded-md p-3' : ''}>
                      <label className="flex items-start">
                        <input
                          id="agreeToTerms"
                          name="agreeToTerms"
                          type="checkbox"
                          checked={formData.agreeToTerms}
                          onChange={handleChange}
                          className="h-4 w-4 mt-1 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">
                          I agree to the{' '}
                          <Link to="/terms" className="font-medium text-blue-600 hover:text-blue-500">
                            Terms of Service
                          </Link>{' '}
                          and{' '}
                          <Link to="/privacy" className="font-medium text-blue-600 hover:text-blue-500">
                            Privacy Policy
                          </Link>
                        </span>
                      </label>
                      {formErrors.agreeToTerms && (
                        <p className="mt-1 ml-6 text-sm text-red-600">{formErrors.agreeToTerms}</p>
                      )}
                    </div>
                    
                    {/* Newsletter/Updates Subscription */}
                    <div>
                      <label className="flex items-start">
                        <input
                          id="subscribeToUpdates"
                          name="subscribeToUpdates"
                          type="checkbox"
                          checked={formData.subscribeToUpdates}
                          onChange={handleChange}
                          className="h-4 w-4 mt-1 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">
                          Send me updates about crisis events in my area and platform improvements
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
                
                {/* Step 2 Navigation */}
                <div className="mt-6 flex flex-col sm:flex-row sm:justify-between space-y-3 sm:space-y-0 sm:space-x-3">
                  <button
                    type="button"
                    onClick={handlePreviousStep}
                    className="flex justify-center items-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                  >
                    <ChevronLeft className="h-4 w-4 mr-1" />
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={loading}
                    className="flex-1 flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-400 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <>
                        <Loader className="h-5 w-5 mr-2 animate-spin" />
                        Creating Account...
                      </>
                    ) : (
                      <>
                        Create Account
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </form>
          
          {/* Login link */}
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  Already have an account?
                </span>
              </div>
            </div>
            
            <div className="mt-6">
              <Link
                to="/login"
                className="w-full flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Sign in instead
              </Link>
            </div>
          </div>
          
          {/* Verification info */}
          <div className="mt-6 p-4 bg-blue-50 rounded-md">
            <div className="flex">
              <Info className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0" />
              <div className="text-sm text-blue-700">
                <p className="font-medium">Email verification required</p>
                <p className="mt-1">After registration, you'll need to verify your email address before you can report or access all features.</p>
              </div>
            </div>
          </div>