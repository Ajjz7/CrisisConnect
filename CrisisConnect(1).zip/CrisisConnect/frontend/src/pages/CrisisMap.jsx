import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { GoogleMap, useLoadScript, Marker, InfoWindow, Circle, StandaloneSearchBox } from '@react-google-maps/api';
import { AlertTriangle, MapPin, Filter, Layers, AlertCircle, RefreshCw, Info, UserCheck, UserX, Shield, Loader, List, MapIcon, Search, ChevronDown, ChevronUp, X, Clock, Menu } from 'lucide-react';

// Map container styles
const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

// Default center (will be overridden by user location if available)
const defaultCenter = {
  lat: 37.7749, // San Francisco as default
  lng: -122.4194,
};

// Default map options
const mapOptions = {
  disableDefaultUI: false,
  zoomControl: true,
  mapTypeControl: true,
  streetViewControl: false,
  fullscreenControl: true,
};

// Libraries for Google Maps
const libraries = ['places'];

// Crisis type icons and colors (matching backend)
const crisisTypeConfig = {
  // Weather-Related Disasters
  hurricane: { icon: '🌀', color: '#3498db', radius: 20000 },
  tornado: { icon: '🌪️', color: '#34495e', radius: 5000 },
  blizzard: { icon: '❄️', color: '#ecf0f1', radius: 15000 },
  heatwave: { icon: '🔥', color: '#e74c3c', radius: 30000 },
  drought: { icon: '☀️', color: '#f39c12', radius: 50000 },
  
  // Geological Disasters
  earthquake: { icon: '⚡', color: '#e67e22', radius: 25000 },
  tsunami: { icon: '🌊', color: '#3498db', radius: 15000 },
  landslide: { icon: '⛰️', color: '#795548', radius: 3000 },
  volcanic_eruption: { icon: '🌋', color: '#e74c3c', radius: 20000 },
  
  // Water-Related Disasters
  flood: { icon: '💧', color: '#3498db', radius: 10000 },
  flash_flood: { icon: '⚡💧', color: '#2980b9', radius: 5000 },
  dam_failure: { icon: '🏞️', color: '#2c3e50', radius: 15000 },
  
  // Fire-Related Disasters
  wildfire: { icon: '🔥', color: '#e74c3c', radius: 8000 },
  urban_fire: { icon: '🏢🔥', color: '#c0392b', radius: 2000 },
  
  // Biological Disasters
  pandemic: { icon: '🦠', color: '#9b59b6', radius: 100000 },
  epidemic: { icon: '😷', color: '#8e44ad', radius: 50000 },
  biological_hazard: { icon: '☣️', color: '#2ecc71', radius: 10000 },
  
  // Human-Caused Disasters
  chemical_spill: { icon: '⚗️', color: '#27ae60', radius: 5000 },
  radiation: { icon: '☢️', color: '#f1c40f', radius: 15000 },
  terrorism: { icon: '⚠️', color: '#e74c3c', radius: 3000 },
  conflict: { icon: '⚔️', color: '#c0392b', radius: 10000 },
  infrastructure_failure: { icon: '🏗️', color: '#7f8c8d', radius: 2000 }
};

// Default crisis type if not found in config
const defaultCrisisConfig = { 
  icon: '⚠️', 
  color: '#e74c3c',
  radius: 5000
};

const CrisisMap = () => {
  const navigate = useNavigate();
  const mapRef = useRef(null);
  const searchBoxRef = useRef(null);
  
  // Component state
  const [crisisReports, setCrisisReports] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    crisisTypes: [],
    showVerifiedOnly: false,
    timeRange: 'all', // 'today', 'week', 'month', 'all'
    severity: 'all', // 'low', 'medium', 'high', 'all'
  });
  const [showFilters, setShowFilters] = useState(false);
  const [showLegend, setShowLegend] = useState(false);
  const [availableCrisisTypes, setAvailableCrisisTypes] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [viewMode, setViewMode] = useState('map'); // 'map' or 'list'
  const [showSidebar, setShowSidebar] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  // Load Google Maps API
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries,
  });
  
  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth < 768) {
        setShowSidebar(false);
      }
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  // Function to fetch crisis reports from API
  const fetchCrisisReports = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch from backend API
      const response = await fetch('/api/crisis-reports', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch crisis reports');
      }
      
      const data = await response.json();
      setCrisisReports(data.reports);
      
      // Extract available crisis types for filters
      const types = [...new Set(data.reports.map(report => report.crisis_type))];
      setAvailableCrisisTypes(types);
      
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      console.error('Error fetching crisis reports:', err);
      setError('Failed to load crisis map data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);
  
  // Initialize Firebase real-time listener for crisis reports
  const initializeRealtimeUpdates = useCallback(() => {
    try {
      // Use Firebase from window object (initialized in your main app)
      const firebase = window.firebase;
      if (!firebase || !firebase.database) {
        console.error('Firebase not available');
        return;
      }
      
      const crisisRef = firebase.database().ref('/crisis_reports');
      
      // Listen for changes
      crisisRef.on('value', (snapshot) => {
        const data = snapshot.val();
        if (data) {
          // Convert Firebase object to array
          const reportsArray = Object.keys(data).map(key => ({
            id: key,
            ...data[key]
          }));
          
          setCrisisReports(reportsArray);
          setLastUpdated(new Date());
        }
      });
      
      // Cleanup function to remove listener
      return () => {
        crisisRef.off();
      };
    } catch (err) {
      console.error('Error setting up real-time updates:', err);
      // Fall back to polling if real-time updates fail
      const intervalId = setInterval(fetchCrisisReports, 30000); // Poll every 30 seconds
      return () => clearInterval(intervalId);
    }
  }, [fetchCrisisReports]);
  
  // Check auth status and get user location on mount
  useEffect(() => {
    // Check authentication status
    const checkAuthStatus = async () => {
      try {
        const response = await fetch('/dashboard', {
          credentials: 'include'
        });
        setIsAuthenticated(response.ok);
      } catch (error) {
        console.error('Error checking authentication:', error);
        setIsAuthenticated(false);
      }
    };
    
    // Get user's location
    const getUserLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setUserLocation({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
          },
          (error) => {
            console.error('Error getting location:', error);
          }
        );
      }
    };
    
    checkAuthStatus();
    getUserLocation();
    
    // Initial data load
    fetchCrisisReports();
    
    // Set up real-time updates
    const cleanup = initializeRealtimeUpdates();
    
    return () => {
      if (cleanup) cleanup();
    };
  }, [fetchCrisisReports, initializeRealtimeUpdates]);
  
  // Handle map load
  const onMapLoad = useCallback((map) => {
    mapRef.current = map;
    setMapLoaded(true);
  }, []);
  
  // Handle search box load
  const onSearchBoxLoad = useCallback((ref) => {
    searchBoxRef.current = ref;
  }, []);
  
  // Handle places changed in search box
  const onPlacesChanged = useCallback(() => {
    if (searchBoxRef.current) {
      const places = searchBoxRef.current.getPlaces();
      if (places && places.length > 0) {
        const place = places[0];
        if (place.geometry && place.geometry.location) {
          const newLocation = {
            lat: place.geometry.location.lat(),
            lng: place.geometry.location.lng(),
          };
          
          if (mapRef.current) {
            mapRef.current.panTo(newLocation);
            mapRef.current.setZoom(13);
          }
        }
      }
    }
  }, []);
  
  // Filter crisis reports based on current filters
  const filteredReports = crisisReports.filter(report => {
    // Filter by crisis type
    if (filters.crisisTypes.length > 0 && !filters.crisisTypes.includes(report.crisis_type)) {
      return false;
    }
    
    // Filter by verification status
    if (filters.showVerifiedOnly && report.trust_score < 70) {
      return false;
    }
    
    // Filter by time range
    if (filters.timeRange !== 'all') {
      const reportDate = new Date(report.created_at);
      const now = new Date();
      const timeDiff = now - reportDate;
      
      if (filters.timeRange === 'today' && timeDiff > 24 * 60 * 60 * 1000) {
        return false;
      } else if (filters.timeRange === 'week' && timeDiff > 7 * 24 * 60 * 60 * 1000) {
        return false;
      } else if (filters.timeRange === 'month' && timeDiff > 30 * 24 * 60 * 60 * 1000) {
        return false;
      }
    }
    
    // Filter by severity
    if (filters.severity !== 'all' && report.severity !== filters.severity) {
      return false;
    }
    
    return true;
  });
  
  // Handle filter changes
  const handleFilterChange = (type, value) => {
    setFilters(prev => ({
      ...prev,
      [type]: value
    }));
  };
  
  // Toggle crisis type filter
  const toggleCrisisTypeFilter = (type) => {
    setFilters(prev => {
      const updatedTypes = prev.crisisTypes.includes(type)
        ? prev.crisisTypes.filter(t => t !== type)
        : [...prev.crisisTypes, type];
        
      return {
        ...prev,
        crisisTypes: updatedTypes
      };
    });
  };
  
  // Reset all filters
  const resetFilters = () => {
    setFilters({
      crisisTypes: [],
      showVerifiedOnly: false,
      timeRange: 'all',
      severity: 'all',
    });
  };
  
  // Navigate to crisis report detail
  const viewReportDetail = (reportId) => {
    navigate(`/crisis/report/${reportId}`);
  };
  
  // Navigate to create new report
  const createNewReport = () => {
    navigate('/crisis/report');
  };
  
  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };
  
  // Format relative time
  const formatRelativeTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    // Convert to minutes, hours, days
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (minutes < 60) {
      return `${minutes} min${minutes === 1 ? '' : 's'} ago`;
    } else if (hours < 24) {
      return `${hours} hour${hours === 1 ? '' : 's'} ago`;
    } else if (days < 30) {
      return `${days} day${days === 1 ? '' : 's'} ago`;
    } else {
      return date.toLocaleDateString();
    }
  };
  
  // Get configuration for a crisis type (icon, color)
  const getCrisisConfig = (type) => {
    return crisisTypeConfig[type] || defaultCrisisConfig;
  };
  
  // Toggle map/list view
  const toggleViewMode = () => {
    setViewMode(viewMode === 'map' ? 'list' : 'map');
  };
  
  // Toggle sidebar
  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };
  
  // Render loading state
  if (loadError) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-100">
        <div className="text-center px-4">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto" />
          <h2 className="mt-2 text-xl font-semibold">Map Error</h2>
          <p className="mt-2 text-gray-600">Failed to load Google Maps. Please check your internet connection.</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Refresh Page
          </button>
        </div>
      </div>
    );
  }
  
  if (!isLoaded) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <Loader className="h-12 w-12 text-blue-500 mx-auto animate-spin" />
          <h2 className="mt-2 text-xl">Loading Crisis Map</h2>
        </div>
      </div>
    );
  }
  
  return (
    <div className="h-screen flex flex-col">
      {/* Header with controls */}
      <div className="bg-white p-3 shadow-md z-10 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <button 
              onClick={toggleSidebar}
              className="p-2 rounded-md hover:bg-gray-100 mr-2"
            >
              <Menu className="h-5 w-5 text-gray-600" />
            </button>
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
              <h1 className="text-lg font-semibold hidden md:block">Crisis Map</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="relative w-full md:w-64">
              <StandaloneSearchBox
                onLoad={onSearchBoxLoad}
                onPlacesChanged={onPlacesChanged}
              >
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search location..."
                    className="w-full px-3 py-2 pl-9 border border-gray-300 rounded-md text-sm"
                  />
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                </div>
              </StandaloneSearchBox>
            </div>
            
            <button
              onClick={toggleViewMode}
              className="p-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 hidden md:flex items-center"
              title={viewMode === 'map' ? 'Switch to List View' : 'Switch to Map View'}
            >
              {viewMode === 'map' ? (
                <>
                  <List className="h-4 w-4 mr-1" />
                  <span className="text-sm">List</span>
                </>
              ) : (
                <>
                  <MapIcon className="h-4 w-4 mr-1" />
                  <span className="text-sm">Map</span>
                </>
              )}
            </button>
            
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="p-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 hidden md:flex items-center"
            >
              <Filter className="h-4 w-4 mr-1" />
              <span className="text-sm">Filters</span>
            </button>
            
            <button
              onClick={createNewReport}
              className="p-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex items-center"
            >
              <AlertTriangle className="h-4 w-4 mr-1" />
              <span className="text-sm">Report</span>
            </button>
          </div>
        </div>
        
        {/* Mobile view toggles */}
        <div className="flex justify-between mt-2 md:hidden">
          <button
            onClick={toggleViewMode}
            className="flex-1 p-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 mr-2 flex items-center justify-center"
          >
            {viewMode === 'map' ? (
              <>
                <List className="h-4 w-4 mr-1" />
                <span className="text-sm">List</span>
              </>
            ) : (
              <>
                <MapIcon className="h-4 w-4 mr-1" />
                <span className="text-sm">Map</span>
              </>
            )}
          </button>
          
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex-1 p-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 flex items-center justify-center"
          >
            <Filter className="h-4 w-4 mr-1" />
            <span className="text-sm">Filters</span>
          </button>
        </div>
      </div>
      
      {/* Filter panel */}
      {showFilters && (
        <div className="bg-gray-50 p-3 border-b border-gray-200 z-10 overflow-x-auto">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium">Filter Crisis Reports</h3>
            <button
              onClick={resetFilters}
              className="text-sm text-blue-600 hover:text-blue-800"
            >
              Reset All
            </button>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-2">
            {/* Crisis Type Filter Pills */}
            {availableCrisisTypes.map(type => (
              <button
                key={type}
                onClick={() => toggleCrisisTypeFilter(type)}
                className={`px-2 py-1 text-xs rounded-full flex items-center ${
                  filters.crisisTypes.includes(type) 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-800'
                }`}
              >
                <span className="mr-1">{getCrisisConfig(type).icon}</span>
                {type.replace(/_/g, ' ')}
                {filters.crisisTypes.includes(type) && (
                  <X className="h-3 w-3 ml-1" />
                )}
              </button>
            ))}
          </div>
          
          <div className="grid grid-cols-3 gap-2">
            {/* Time Range Filter */}
            <div>
              <label className="block text-xs text-gray-600 mb-1">Time Period</label>
              <select
                value={filters.timeRange}
                onChange={(e) => handleFilterChange('timeRange', e.target.value)}
                className="w-full p-1.5 text-sm border border-gray-300 rounded"
              >
                <option value="all">All Time</option>
                <option value="today">Last 24 Hours</option>
                <option value="week">Last 7 Days</option>
                <option value="month">Last 30 Days</option>
              </select>
            </div>
            
            {/* Severity Filter */}
            <div>
              <label className="block text-xs text-gray-600 mb-1">Severity</label>
              <select
                value={filters.severity}
                onChange={(e) => handleFilterChange('severity', e.target.value)}
                className="w-full p-1.5 text-sm border border-gray-300 rounded"
              >
                <option value="all">All Severities</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
            
            {/* Verification Filter */}
            <div className="flex items-end">
              <label className="flex items-center text-sm">
                <input
                  type="checkbox"
                  checked={filters.showVerifiedOnly}
                  onChange={(e) => handleFilterChange('showVerifiedOnly', e.target.checked)}
                  className="h-4 w-4 text-blue-600 rounded border-gray-300 mr-2"
                />
                Verified Only
              </label>
            </div>
          </div>
          
          {/* Filter summary */}
          <div className="mt-2 pt-2 border-t border-gray-200 text-xs text-gray-500 flex justify-between items-center">
            <div>
              Showing {filteredReports.length} of {crisisReports.length} reports
            </div>
            {lastUpdated && (
              <div className="flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                Last updated: {formatRelativeTime(lastUpdated)}
                <button
                  onClick={fetchCrisisReports}
                  className="ml-2 p-1 hover:bg-gray-200 rounded-full"
                  title="Refresh data"
                >
                  <RefreshCw className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Main content area with map and optional sidebar */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar with list view (conditionally shown) */}
        {showSidebar && (
          <div className="w-full md:w-80 bg-white border-r border-gray-200 flex flex-col z-10">
            {/* List header */}
            <div className="p-3 border-b border-gray-200 flex justify-between items-center">
              <h3 className="font-medium">Crisis Reports</h3>
              <div className="text-xs text-gray-500">
                {filteredReports.length} {filteredReports.length === 1 ? 'report' : 'reports'}
              </div>
            </div>
            
            {/* List of reports */}
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="flex items-center justify-center h-32">
                  <Loader className="h-5 w-5 text-blue-500 animate-spin" />
                </div>
              ) : filteredReports.length > 0 ? (
                <div className="divide-y divide-gray-200">
                  {filteredReports.map(report => (
                    <div 
                      key={report.id}
                      className={`p-3 hover:bg-gray-50 cursor-pointer ${
                        selectedReport?.id === report.id ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => {
                        setSelectedReport(report);
                        if (viewMode === 'map' && mapRef.current) {
                          const location = {
                            lat: parseFloat(report.location.split(',')[0]),
                            lng: parseFloat(report.location.split(',')[1])
                          };
                          mapRef.current.panTo(location);
                          mapRef.current.setZoom(13);
                        }
                      }}
                    >
                      <div className="flex items-start">
                        <div className="mr-3 text-xl">{getCrisisConfig(report.crisis_type).icon}</div>
                        <div className="flex-1">
                          <div className="flex items-center">
                            <h4 className="font-medium text-gray-900 mr-2">
                              {report.crisis_type.replace(/_/g, ' ')}
                            </h4>
                            <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                              report.severity === 'high' ? 'bg-red-100 text-red-800' :
                              report.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-blue-100 text-blue-800'
                            }`}>
                              {report.severity}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600 mt-1 line-clamp-2">{report.description}</p>
                          <div className="mt-1.5 flex items-center justify-between">
                            <div className="text-xs text-gray-500">
                              {formatRelativeTime(report.created_at)}
                            </div>
                            {report.trust_score >= 70 ? (
                              <div className="text-xs text-green-600 flex items-center">
                                <UserCheck className="h-3 w-3 mr-0.5" />
                                Verified
                              </div>
                            ) : (
                              <div className="text-xs text-amber-600 flex items-center">
                                <UserX className="h-3 w-3 mr-0.5" />
                                Unverified
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 text-center text-gray-500">
                  <AlertCircle className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                  <p>No crisis reports match your filters.</p>
                  <button
                    onClick={resetFilters}
                    className="mt-2 text-sm text-blue-600 hover:underline"
                  >
                    Reset Filters
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Map view */}
        {(viewMode === 'map' || !isMobile) && (
          <div className="relative flex-1">
            {/* Map container */}
            <GoogleMap
              mapContainerStyle={mapContainerStyle}
              center={userLocation || defaultCenter}
              zoom={10}
              options={mapOptions}
              onLoad={onMapLoad}
            >
              {/* User location marker */}
              {userLocation && (
                <Marker
                  position={userLocation}
                  icon={{
                    url: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                    scaledSize: new window.google.maps.Size(40, 40),
                  }}
                  title="Your Location"
                />
              )}
              
              {/* Crisis report markers */}
              {!loading && mapLoaded && filteredReports.map((report) => {
                const config = getCrisisConfig(report.crisis_type);
                const location = {
                  lat: parseFloat(report.location.split(',')[0]),
                  lng: parseFloat(report.location.split(',')[1]),
                };
                
                return (
                  <React.Fragment key={report.id}>
                    <Marker
                      position={location}
                      onClick={() => setSelectedReport(report)}
                      icon={{
                        path: window.google.maps.SymbolPath.CIRCLE,
                        scale: 10,
                        fillColor: config.color,
                        fillOpacity: 0.8,
                        strokeColor: report.trust_score > 70 ? '#2ecc71' : '#f39c12',
                        strokeWeight: 2,
                      }}
                      title={report.description.substring(0, 50) + '...'}
                    />
                    
                    {/* Crisis affected area circle */}
                    <Circle
                      center={location}
                      options={{
                        fillColor: config.color,
                        fillOpacity: 0.1,
                        strokeColor: config.color,
                        strokeOpacity: 0.3,
                        strokeWeight: 1,
radius: config.radius || 5000,
                      }}
                    />
                  </React.Fragment>
                );
              })}
              
              {/* Info window for selected report */}
              {selectedReport && (
                <InfoWindow
                  position={{
                    lat: parseFloat(selectedReport.location.split(',')[0]),
                    lng: parseFloat(selectedReport.location.split(',')[1]),
                  }}
                  onCloseClick={() => setSelectedReport(null)}
                >
                  <div className="p-1">
                    <div className="flex items-center mb-1">
                      <span className="text-xl mr-2">{getCrisisConfig(selectedReport.crisis_type).icon}</span>
                      <h3 className="font-medium text-lg">{selectedReport.crisis_type.replace(/_/g, ' ')}</h3>
                    </div>
                    
                    <div className="mb-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        selectedReport.severity === 'high' ? 'bg-red-100 text-red-800' :
                        selectedReport.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {selectedReport.severity} severity
                      </span>
                      
                      {selectedReport.trust_score >= 70 ? (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-800 ml-1">
                          Verified
                        </span>
                      ) : (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 ml-1">
                          Unverified
                        </span>
                      )}
                    </div>
                    
                    <p className="text-sm mb-2">{selectedReport.description}</p>
                    
                    <div className="text-xs text-gray-500 mb-2">
                      Reported: {formatDate(selectedReport.created_at)}
                    </div>
                    
                    <button
                      onClick={() => viewReportDetail(selectedReport.id)}
                      className="w-full text-center text-sm bg-blue-600 text-white py-1 px-3 rounded hover:bg-blue-700"
                    >
                      View Details
                    </button>
                  </div>
                </InfoWindow>
              )}
            </GoogleMap>
            
            {/* Map overlay controls */}
            <div className="absolute bottom-4 right-4 flex flex-col space-y-2">
              {/* Legend toggle */}
              <button
                onClick={() => setShowLegend(!showLegend)}
                className="bg-white p-2 rounded-full shadow hover:bg-gray-100"
                title="Show legend"
              >
                <Layers className="h-5 w-5 text-gray-700" />
              </button>
              
              {/* Refresh button */}
              <button
                onClick={fetchCrisisReports}
                className="bg-white p-2 rounded-full shadow hover:bg-gray-100"
                title="Refresh data"
              >
                <RefreshCw className={`h-5 w-5 text-gray-700 ${loading ? 'animate-spin' : ''}`} />
              </button>
              
              {/* Recenter on user */}
              {userLocation && (
                <button
                  onClick={() => {
                    if (mapRef.current) {
                      mapRef.current.panTo(userLocation);
                      mapRef.current.setZoom(13);
                    }
                  }}
                  className="bg-white p-2 rounded-full shadow hover:bg-gray-100"
                  title="Center on your location"
                >
                  <MapPin className="h-5 w-5 text-blue-600" />
                </button>
              )}
            </div>
            
            {/* Map legend */}
            {showLegend && (
              <div className="absolute left-4 bottom-4 bg-white p-3 rounded-lg shadow-lg max-w-xs max-h-64 overflow-y-auto text-sm">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">Crisis Types</h4>
                  <button
                    onClick={() => setShowLegend(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
                
                <div className="space-y-1.5">
                  {Object.entries(crisisTypeConfig).map(([type, config]) => (
                    <div key={type} className="flex items-center">
                      <div 
                        className="h-3 w-3 rounded-full mr-2" 
                        style={{ backgroundColor: config.color }}
                      />
                      <span className="mr-1">{config.icon}</span>
                      <span>{type.replace(/_/g, ' ')}</span>
                    </div>
                  ))}
                </div>
                
                <div className="border-t border-gray-200 mt-2 pt-2">
                  <div className="flex items-center mb-1">
                    <Shield className="h-3 w-3 text-green-600 mr-1" />
                    <span>Verified reports have green outline</span>
                  </div>
                  <div className="flex items-center">
                    <Shield className="h-3 w-3 text-amber-600 mr-1" />
                    <span>Unverified reports have amber outline</span>
                  </div>
                </div>
              </div>
            )}
            
            {/* Map error state overlay */}
            {error && (
              <div className="absolute inset-0 bg-white bg-opacity-80 flex items-center justify-center">
                <div className="bg-white p-4 rounded-lg shadow-lg text-center max-w-md">
                  <AlertCircle className="h-10 w-10 text-red-500 mx-auto mb-2" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">Error Loading Map Data</h3>
                  <p className="text-gray-600 mb-3">{error}</p>
                  <button
                    onClick={fetchCrisisReports}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Try Again
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
        
        {/* List view for mobile */}
        {viewMode === 'list' && isMobile && (
          <div className="flex-1 overflow-y-auto bg-white">
            {loading ? (
              <div className="flex items-center justify-center h-32">
                <Loader className="h-6 w-6 text-blue-500 animate-spin" />
              </div>
            ) : filteredReports.length > 0 ? (
              <div className="divide-y divide-gray-200">
                {filteredReports.map(report => (
                  <div 
                    key={report.id}
                    className="p-4 hover:bg-gray-50"
                    onClick={() => viewReportDetail(report.id)}
                  >
                    <div className="flex items-start">
                      <div className="mr-3 text-xl">{getCrisisConfig(report.crisis_type).icon}</div>
                      <div className="flex-1">
                        <div className="flex items-center">
                          <h4 className="font-medium text-gray-900 mr-2">
                            {report.crisis_type.replace(/_/g, ' ')}
                          </h4>
                          <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                            report.severity === 'high' ? 'bg-red-100 text-red-800' :
                            report.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {report.severity}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{report.description}</p>
                        <div className="mt-2 flex items-center justify-between">
                          <div className="text-xs text-gray-500">
                            {formatRelativeTime(report.created_at)}
                          </div>
                          {report.trust_score >= 70 ? (
                            <div className="text-xs text-green-600 flex items-center">
                              <UserCheck className="h-3 w-3 mr-0.5" />
                              Verified
                            </div>
                          ) : (
                            <div className="text-xs text-amber-600 flex items-center">
                              <UserX className="h-3 w-3 mr-0.5" />
                              Unverified
                            </div>
                          )}
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-gray-400 ml-2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-gray-500">
                <AlertCircle className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                <p className="text-lg font-medium mb-1">No Crisis Reports Found</p>
                <p className="mb-3">No reports match your current filters.</p>
                <button
                  onClick={resetFilters}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Reset Filters
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default CrisisMap;