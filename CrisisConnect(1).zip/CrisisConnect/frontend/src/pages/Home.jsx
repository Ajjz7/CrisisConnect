import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AlertTriangle, MapPin, Shield, MessageSquare, User, ArrowRight, AlertCircle, Clock, Info, Users, ThumbsUp, ChevronRight } from 'lucide-react';

// Import components (assuming these are created as per previous requests)
import { ChatbotEmbed } from './ChatbotContext';

const Home = () => {
  const navigate = useNavigate();
  
  // State for recent crisis reports and loading states
  const [recentReports, setRecentReports] = useState([]);
  const [reportsLoading, setReportsLoading] = useState(true);
  const [userLocation, setUserLocation] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [locationLoading, setLocationLoading] = useState(true);
  const [emergencyResources, setEmergencyResources] = useState([]);
  const [resourcesLoading, setResourcesLoading] = useState(true);
  
  // Check authentication status
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await fetch('/dashboard', {
          credentials: 'include'
        });
        
        setIsAuthenticated(response.ok);
      } catch (error) {
        console.error('Error checking authentication status:', error);
        setIsAuthenticated(false);
      } finally {
        setAuthLoading(false);
      }
    };
    
    checkAuthStatus();
  }, []);
  
  // Get user location
  useEffect(() => {
    if (!navigator.geolocation) {
      setLocationLoading(false);
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
        setLocationLoading(false);
      },
      (error) => {
        console.error('Error getting location:', error);
        setLocationLoading(false);
      }
    );
  }, []);
  
  // Fetch recent crisis reports
  useEffect(() => {
    const fetchRecentReports = async () => {
      try {
        const response = await fetch('/api/crisis-reports/recent', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const data = await response.json();
          setRecentReports(data.reports.slice(0, 4)); // Take only 4 most recent
        }
      } catch (error) {
        console.error('Error fetching recent reports:', error);
      } finally {
        setReportsLoading(false);
      }
    };
    
    fetchRecentReports();
  }, []);
  
  // Fetch emergency resources
  useEffect(() => {
    const fetchEmergencyResources = async () => {
      if (!userLocation) {
        if (!locationLoading) setResourcesLoading(false);
        return;
      }
      
      try {
        const response = await fetch('/api/resources/featured', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            location: `${userLocation.lat},${userLocation.lng}`,
          }),
          credentials: 'include'
        });
        
        if (response.ok) {
          const data = await response.json();
          setEmergencyResources(data.resources.slice(0, 3)); // Take only 3 featured resources
        }
      } catch (error) {
        console.error('Error fetching emergency resources:', error);
      } finally {
        setResourcesLoading(false);
      }
    };
    
    fetchEmergencyResources();
  }, [userLocation, locationLoading]);
  
  // Crisis types for quick access
  const commonCrisisTypes = [
    { type: 'flood', label: 'Flood', icon: '💧', color: 'bg-blue-100 text-blue-800' },
    { type: 'wildfire', label: 'Wildfire', icon: '🔥', color: 'bg-red-100 text-red-800' },
    { type: 'earthquake', label: 'Earthquake', icon: '⚡', color: 'bg-amber-100 text-amber-800' },
    { type: 'hurricane', label: 'Hurricane', icon: '🌀', color: 'bg-sky-100 text-sky-800' },
    { type: 'pandemic', label: 'Pandemic', icon: '🦠', color: 'bg-purple-100 text-purple-800' },
    { type: 'chemical_spill', label: 'Chemical Spill', icon: '⚗️', color: 'bg-green-100 text-green-800' },
  ];
  
  // Format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };
  
  // Navigate to resource
  const navigateToResource = (resource) => {
    if (resource.url) {
      window.open(resource.url, '_blank');
    } else if (resource.type) {
      navigate(`/resources/${resource.type}`);
    }
  };
  
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="md:flex md:items-center md:justify-between">
            <div className="md:w-1/2">
              <h1 className="text-4xl font-bold tracking-tight mb-4">
                Crisis Connect Platform
              </h1>
              <p className="text-xl text-blue-100 mb-8 max-w-2xl">
                Real-time emergency reporting, resource matching, and crisis management. 
                Connecting those affected by crises with responders and resources.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link
                  to="/crisis/map"
                  className="px-5 py-3 bg-white text-blue-700 rounded-md font-medium hover:bg-blue-50 shadow-md flex items-center"
                >
                  <MapPin className="mr-2 h-5 w-5" />
                  View Crisis Map
                </Link>
                <Link
                  to="/crisis/report"
                  className="px-5 py-3 bg-red-600 text-white rounded-md font-medium hover:bg-red-700 shadow-md flex items-center"
                >
                  <AlertTriangle className="mr-2 h-5 w-5" />
                  Report Emergency
                </Link>
              </div>
            </div>
            <div className="mt-8 md:mt-0 md:w-1/2 flex justify-center">
              <img
                src="/images/crisis-map-preview.png"
                alt="Crisis Map Preview"
                className="rounded-lg shadow-lg max-h-80 object-cover"
                onError={(e) => {
                  e.target.src = "https://via.placeholder.com/600x400?text=Crisis+Connect";
                }}
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Quick Access Crisis Types */}
      <div className="py-8 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            Quick Access Crisis Resources
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {commonCrisisTypes.map((crisis) => (
              <Link
                key={crisis.type}
                to={`/resources/${crisis.type}`}
                className={`${crisis.color} p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex flex-col items-center text-center`}
              >
                <span className="text-3xl mb-2">{crisis.icon}</span>
                <span className="font-medium">{crisis.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
      
      {/* Main Sections */}
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Recent Crisis Reports */}
            <div className="col-span-2">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-bold text-gray-800 flex items-center">
                    <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
                    Recent Crisis Reports
                  </h2>
                  <Link
                    to="/crisis/map"
                    className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
                  >
                    View All
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
                
                {reportsLoading ? (
                  <div className="py-10 text-center text-gray-500">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="mt-2">Loading recent reports...</p>
                  </div>
                ) : recentReports.length > 0 ? (
                  <div className="divide-y divide-gray-200">
                    {recentReports.map((report) => (
                      <div key={report.id} className="py-4 first:pt-0 last:pb-0">
                        <div className="flex items-start">
                          <div className="mr-3 bg-gray-100 rounded-full p-2 text-xl">
                            {/* Use emoji based on crisis type */}
                            {report.crisis_type === 'flood' && '💧'}
                            {report.crisis_type === 'wildfire' && '🔥'}
                            {report.crisis_type === 'earthquake' && '⚡'}
                            {report.crisis_type === 'hurricane' && '🌀'}
                            {report.crisis_type === 'tornado' && '🌪️'}
                            {report.crisis_type === 'blizzard' && '❄️'}
                            {/* Default icon if type not matched */}
                            {!['flood', 'wildfire', 'earthquake', 'hurricane', 'tornado', 'blizzard'].includes(report.crisis_type) && '⚠️'}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-medium text-gray-900">
                              {report.crisis_type.replace(/_/g, ' ')}
                              <span className={`ml-2 text-xs px-2 py-0.5 rounded-full inline-flex items-center ${
                                report.severity === 'high' ? 'bg-red-100 text-red-800' :
                                report.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-blue-100 text-blue-800'
                              }`}>
                                {report.severity}
                              </span>
                              {report.trust_score >= 70 && (
                                <span className="ml-2 text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full inline-flex items-center">
                                  <ThumbsUp className="h-3 w-3 mr-1" />
                                  Verified
                                </span>
                              )}
                            </h3>
                            <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                              {report.description}
                            </p>
                            <div className="flex mt-2 text-xs text-gray-500">
                              <div className="flex items-center mr-4">
                                <MapPin className="h-3 w-3 mr-1" />
                                {report.location}
                              </div>
                              <div className="flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {formatDate(report.created_at)}
                              </div>
                            </div>
                            <div className="mt-2">
                              <Link
                                to={`/crisis/report/${report.id}`}
                                className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center"
                              >
                                View Details
                                <ArrowRight className="h-3 w-3 ml-1" />
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-gray-500">
                    <AlertCircle className="h-10 w-10 mx-auto text-gray-400 mb-2" />
                    <p>No recent crisis reports available.</p>
                    <Link
                      to="/crisis/report"
                      className="mt-3 inline-block px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
                    >
                      Report a Crisis
                    </Link>
                  </div>
                )}
              </div>
              
              {/* Features Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
                <div className="bg-blue-50 p-5 rounded-lg border border-blue-100">
                  <MapPin className="h-8 w-8 text-blue-600 mb-2" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">
                    Real-time Crisis Map
                  </h3>
                  <p className="text-sm text-gray-600">
                    View current crisis situations on an interactive map with live updates.
                  </p>
                </div>
                
                <div className="bg-red-50 p-5 rounded-lg border border-red-100">
                  <AlertTriangle className="h-8 w-8 text-red-600 mb-2" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">
                    Emergency Reporting
                  </h3>
                  <p className="text-sm text-gray-600">
                    Quick and easy crisis reporting system with photo upload and location detection.
                  </p>
                </div>
                
                <div className="bg-green-50 p-5 rounded-lg border border-green-100">
                  <Shield className="h-8 w-8 text-green-600 mb-2" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">
                    AI Resource Matching
                  </h3>
                  <p className="text-sm text-gray-600">
                    Intelligent matching of resources to your specific emergency needs.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Right Sidebar */}
            <div>
              {/* Login/Register Card (if not authenticated) */}
              {authLoading ? (
                <div className="bg-white p-6 rounded-lg shadow-md mb-6 flex justify-center items-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : !isAuthenticated ? (
                <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                    <User className="h-5 w-5 mr-2 text-blue-600" />
                    Account Access
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Log in or create an account to report crises, save resources, and receive personalized alerts.
                  </p>
                  <div className="space-y-3">
                    <Link
                      to="/login"
                      className="block w-full py-2 px-4 text-center bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                    >
                      Log In
                    </Link>
                    <Link
                      to="/register"
                      className="block w-full py-2 px-4 text-center bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 transition-colors"
                    >
                      Create Account
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="bg-blue-50 p-6 rounded-lg shadow-md mb-6 border border-blue-100">
                  <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                    <User className="h-5 w-5 mr-2 text-blue-600" />
                    Quick Actions
                  </h3>
                  <div className="space-y-3">
                    <Link
                      to="/dashboard"
                      className="block w-full py-2 px-4 text-center bg-white text-blue-600 border border-blue-200 rounded-md hover:bg-blue-50 transition-colors"
                    >
                      Your Dashboard
                    </Link>
                    <Link
                      to="/crisis/report"
                      className="block w-full py-2 px-4 text-center bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                    >
                      Report Emergency
                    </Link>
                  </div>
                </div>
              )}
              
              {/* AI Chatbot Widget */}
              <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2 text-blue-600" />
                  AI Emergency Assistant
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  Get immediate help and guidance from our AI-powered chatbot for any crisis situation.
                </p>
                <ChatbotEmbed />
              </div>
              
              {/* Emergency Resources */}
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <Shield className="h-5 w-5 mr-2 text-green-600" />
                    Emergency Resources
                  </h3>
                  <Link
                    to="/resources"
                    className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
                  >
                    View All
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
                
                {resourcesLoading ? (
                  <div className="py-8 text-center text-gray-500">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto"></div>
                    <p className="mt-2 text-sm">Loading resources...</p>
                  </div>
                ) : emergencyResources.length > 0 ? (
                  <div className="space-y-3">
                    {emergencyResources.map((resource, index) => (
                      <button
                        key={index}
                        onClick={() => navigateToResource(resource)}
                        className="w-full text-left p-3 rounded-md border border-gray-200 hover:bg-gray-50 transition-colors"
                      >
                        <h4 className="font-medium text-gray-900">{resource.title}</h4>
                        <p className="text-sm text-gray-600 mt-1">{resource.description}</p>
                        {resource.distance && (
                          <div className="mt-2 text-xs text-gray-500 flex items-center">
                            <MapPin className="h-3 w-3 mr-1" />
                            {resource.distance} miles away
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="py-4 text-center text-gray-500">
                    <Info className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                    <p className="text-sm">Enable location to see nearby resources.</p>
                  </div>
                )}
                
                <div className="mt-4">
                  <Link
                    to="/resources"
                    className="block w-full py-2 px-4 text-center bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                  >
                    Find Emergency Resources
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Emergency Numbers Banner */}
      <div className="bg-red-600 text-white py-4 px-4 sm:px-6 lg:px-8 mt-8">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center">
          <div className="flex items-center">
            <AlertCircle className="h-6 w-6 mr-2" />
            <span className="font-medium">Emergency Contacts:</span>
          </div>
          <div className="flex flex-wrap gap-4 mt-3 sm:mt-0">
            <div className="flex items-center">
              <span className="font-bold mr-1">911</span>
              <span className="text-sm">Emergency</span>
            </div>
            <div className="flex items-center">
              <span className="font-bold mr-1">211</span>
              <span className="text-sm">Community Resources</span>
            </div>
            <div className="flex items-center">
              <span className="font-bold mr-1">1-800-222-1222</span>
              <span className="text-sm">Poison Control</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;