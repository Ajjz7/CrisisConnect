import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Shield, MapPin, MessageSquare, Users, Globe, Server, Database, Heart, ExternalLink, Mail, Github, Linkedin } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-blue-700 text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">About Crisis Connect</h1>
          <p className="text-xl text-blue-100 mb-6">
            Connecting communities, responders, and resources during times of crisis
          </p>
          <div className="max-w-3xl mx-auto">
            <p className="text-blue-100">
              Crisis Connect is a comprehensive platform designed to bridge the gap between those affected by emergencies 
              and the resources they need most. Our mission is to provide real-time crisis information, 
              facilitate rapid response coordination, and help communities become more resilient in the face of disasters.
            </p>
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We believe that technology can transform crisis response and save lives by connecting people 
              with critical information and resources when they need it most.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center p-3 bg-blue-100 text-blue-600 rounded-full mb-4">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Rapid Response</h3>
              <p className="text-gray-600">
                Enable faster emergency response through real-time reporting and resource coordination
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center p-3 bg-green-100 text-green-600 rounded-full mb-4">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Community Resilience</h3>
              <p className="text-gray-600">
                Build stronger, more prepared communities through information sharing and emergency education
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="inline-flex items-center justify-center p-3 bg-purple-100 text-purple-600 rounded-full mb-4">
                <Globe className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Global Impact</h3>
              <p className="text-gray-600">
                Create an accessible platform that can help communities worldwide respond to diverse crisis situations
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Key Features Section */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Key Features</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our platform offers comprehensive tools for crisis reporting, resource matching, and emergency management.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 mt-8">
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="h-12 w-12 flex items-center justify-center rounded-md bg-red-100 text-red-600">
                  <AlertTriangle className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Real-time Crisis Reporting</h3>
                <p className="text-gray-600 mb-2">
                  Report emergency situations with detailed information, photo evidence, and precise location data
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Comprehensive reporting forms for all crisis types
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Geolocation integration for accurate positioning
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Community verification system to confirm report accuracy
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="h-12 w-12 flex items-center justify-center rounded-md bg-blue-100 text-blue-600">
                  <MapPin className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Interactive Crisis Map</h3>
                <p className="text-gray-600 mb-2">
                  Visualize active crisis situations with an interactive map showing affected areas
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Real-time updates through Firebase integration
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Filtering by crisis type, severity, and time range
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Detailed crisis information and affected area visualization
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="h-12 w-12 flex items-center justify-center rounded-md bg-green-100 text-green-600">
                  <Shield className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">AI Resource Matching</h3>
                <p className="text-gray-600 mb-2">
                  Intelligently match crisis situations with the most relevant emergency resources
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Advanced algorithms tailored to specific crisis types
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Personalized recommendations based on needs (pets, children, etc.)
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Integration with government and NGO emergency resources
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className="h-12 w-12 flex items-center justify-center rounded-md bg-purple-100 text-purple-600">
                  <MessageSquare className="h-6 w-6" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">AI Emergency Assistant</h3>
                <p className="text-gray-600 mb-2">
                  Get immediate guidance and support through our AI-powered chatbot
                </p>
                <ul className="text-sm text-gray-500 space-y-1">
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    24/7 crisis guidance and emergency instructions
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Multilingual support for diverse communities
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    Context-aware responses based on location and crisis type
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <Link 
              to="/features"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              Explore All Features
              <ExternalLink className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
      
      {/* Technology Stack */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Technology</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Crisis Connect leverages cutting-edge technologies to provide a reliable and scalable platform.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <Server className="h-8 w-8 mx-auto" />
              </div>
              <h3 className="font-medium">Flask & FastAPI</h3>
              <p className="text-xs text-gray-500 mt-1">Backend Services</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <div className="mx-auto h-8 w-8 flex items-center justify-center">
                  <span className="text-xl font-bold">R</span>
                </div>
              </div>
              <h3 className="font-medium">React</h3>
              <p className="text-xs text-gray-500 mt-1">Frontend Framework</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <Database className="h-8 w-8 mx-auto" />
              </div>
              <h3 className="font-medium">PostgreSQL</h3>
              <p className="text-xs text-gray-500 mt-1">Primary Database</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <div className="mx-auto h-8 w-8 flex items-center justify-center">
                  <span className="text-xl font-bold">FB</span>
                </div>
              </div>
              <h3 className="font-medium">Firebase</h3>
              <p className="text-xs text-gray-500 mt-1">Real-time Updates</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <div className="mx-auto h-8 w-8 flex items-center justify-center">
                  <span className="text-xl font-bold">AI</span>
                </div>
              </div>
              <h3 className="font-medium">OpenAI</h3>
              <p className="text-xs text-gray-500 mt-1">AI Chatbot</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <div className="mx-auto h-8 w-8 flex items-center justify-center">
                  <span className="text-xl font-bold">GM</span>
                </div>
              </div>
              <h3 className="font-medium">Google Maps</h3>
              <p className="text-xs text-gray-500 mt-1">Mapping Services</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <div className="mx-auto h-8 w-8 flex items-center justify-center">
                  <span className="text-xl font-bold">TW</span>
                </div>
              </div>
              <h3 className="font-medium">Tailwind CSS</h3>
              <p className="text-xs text-gray-500 mt-1">Styling Framework</p>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm text-center">
              <div className="text-blue-600 mb-2">
                <div className="mx-auto h-8 w-8 flex items-center justify-center">
                  <span className="text-xl font-bold">API</span>
                </div>
              </div>
              <h3 className="font-medium">External APIs</h3>
              <p className="text-xs text-gray-500 mt-1">FEMA, Red Cross, WHO</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Team Section */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Team</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Crisis Connect was built by a passionate team dedicated to using technology for social good.
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Team Member 1 */}
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <div className="w-24 h-24 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                <img 
                  src="/images/team/alex-johnson.jpg" 
                  alt="Alex Johnson"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.src = `https://ui-avatars.com/api/?name=Alex+Johnson&background=0D8ABC&color=fff`;
                  }}
                />
              </div>
              <h3 className="text-xl font-medium text-gray-900">Alex Johnson</h3>
              <p className="text-blue-600 mt-1">Project Lead & Backend Developer</p>
              <p className="text-sm text-gray-600 mt-3">
                10+ years experience in disaster response technology and API development.
              </p>
              <div className="flex justify-center mt-4 space-x-3">
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Linkedin className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Github className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
            
            {/* Team Member 2 */}
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <div className="w-24 h-24 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                <img 
                  src="/images/team/maya-patel.jpg" 
                  alt="Maya Patel"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.src = `https://ui-avatars.com/api/?name=Maya+Patel&background=0D8ABC&color=fff`;
                  }}
                />
              </div>
              <h3 className="text-xl font-medium text-gray-900">Maya Patel</h3>
              <p className="text-blue-600 mt-1">Frontend Developer & UX Designer</p>
              <p className="text-sm text-gray-600 mt-3">
                Specialized in creating intuitive interfaces for emergency response applications.
              </p>
              <div className="flex justify-center mt-4 space-x-3">
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Linkedin className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Github className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
            
            {/* Team Member 3 */}
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <div className="w-24 h-24 rounded-full bg-gray-200 mx-auto mb-4 overflow-hidden">
                <img 
                  src="/images/team/marcus-chen.jpg" 
                  alt="Marcus Chen"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.src = `https://ui-avatars.com/api/?name=Marcus+Chen&background=0D8ABC&color=fff`;
                  }}
                />
              </div>
              <h3 className="text-xl font-medium text-gray-900">Marcus Chen</h3>
              <p className="text-blue-600 mt-1">AI & Data Science Lead</p>
              <p className="text-sm text-gray-600 mt-3">
                Expert in machine learning applications for disaster management and resource allocation.
              </p>
              <div className="flex justify-center mt-4 space-x-3">
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Linkedin className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Github className="h-5 w-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-600">
                  <Mail className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-gray-600">We're always looking for talented individuals passionate about crisis response.</p>
            <Link 
              to="/careers" 
              className="mt-4 inline-flex items-center px-4 py-2 border border-blue-600 text-base font-medium rounded-md text-blue-600 bg-white hover:bg-blue-50"
            >
              Join Our Team
              <Users className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
      
      {/* Community Impact */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-blue-700">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center justify-center p-3 bg-white text-blue-600 rounded-full mb-6">
            <Heart className="h-8 w-8" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-6">Making a Difference</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Since our launch, Crisis Connect has helped communities respond to over 1,200 emergency 
            situations across 28 countries, connecting people with life-saving resources.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-12">
            <div className="text-center">
              <div className="text-4xl font-bold text-white">1,200+</div>
              <div className="text-blue-200 mt-2">Crisis Situations</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white">28</div>
              <div className="text-blue-200 mt-2">Countries Served</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white">50K+</div>
              <div className="text-blue-200 mt-2">Users Helped</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white">15</div>
              <div className="text-blue-200 mt-2">Partner Organizations</div>
            </div>
          </div>
          
          <div className="mt-12">
            <Link 
              to="/impact" 
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-blue-50"
            >
              Read Impact Stories
              <ExternalLink className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
      
      {/* Contact & Support */}
      <div className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Connect With Us</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-3xl mx-auto">
            Have questions or suggestions? We'd love to hear from you. Our team is dedicated to 
            improving Crisis Connect and expanding its impact.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Link 
              to="/contact" 
              className="px-6 py-3 bg-blue-600 text-white rounded-md font-medium hover:bg-blue-700 shadow-md"
            >
              Contact Us
            </Link>
            <Link 
              to="/support" 
              className="px-6 py-3 bg-white text-blue-600 border border-blue-200 rounded-md font-medium hover:bg-blue-50 shadow-md"
            >
              Support Center
            </Link>
            <a 
              href="https://github.com/crisis-connect" 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-6 py-3 bg-gray-800 text-white rounded-md font-medium hover:bg-gray-900 shadow-md flex items-center"
            >
              <Github className="mr-2 h-5 w-5" />
              GitHub
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;