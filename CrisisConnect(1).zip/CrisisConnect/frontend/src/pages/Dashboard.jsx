import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  AlertTriangle, 
  MapPin, 
  Bell, 
  User, 
  Settings, 
  LogOut, 
  ChevronDown, 
  ChevronRight,
  Clock, 
  Users, 
  Shield, 
  CheckCircle, 
  XCircle,
  Info,
  Eye,
  Calendar,
  BarChart2,
  Loader,
  AlertCircle,
  Menu,
  X,
  Map,
  FileText,
  Home,
  MessageSquare,
  HelpCircle,
  Zap
} from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  
  // User state
  const [userData, setUserData] = useState(null);
  const [userReports, setUserReports] = useState([]);
  const [userStats, setUserStats] = useState({
    totalReports: 0,
    verifiedReports: 0,
    pendingReports: 0,
    trustScore: 0
  });
  
  // UI state
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [activeCrises, setActiveCrises] = useState([]);
  const [nearbyEvents, setNearbyEvents] = useState([]);
  
  // Fetch user data on component mount
  useEffect(() => {
    const fetchUserData = async () => {
      setLoading(true);
      try {
        // Call API to get user profile
        const userResponse = await fetch('/api/user/profile', {
          credentials: 'include',
        });
        
        if (!userResponse.ok) {
          if (userResponse.status === 401) {
            // Not authenticated, redirect to login
            navigate('/login');
            return;
          }
          throw new Error('Failed to fetch user data');
        }
        
        const userData = await userResponse.json();
        setUserData(userData);
        
        // Fetch user's reports
        const reportsResponse = await fetch('/api/user/reports', {
          credentials: 'include',
        });
        
        if (!reportsResponse.ok) {
          throw new Error('Failed to fetch user reports');
        }
        
        const reportsData = await reportsResponse.json();
        setUserReports(reportsData.reports);
        setUserStats({
          totalReports: reportsData.stats.total,
          verifiedReports: reportsData.stats.verified,
          pendingReports: reportsData.stats.pending,
          trustScore: reportsData.stats.trustScore
        });
        
        // Fetch notifications
        const notificationsResponse = await fetch('/api/user/notifications', {
          credentials: 'include',
        });
        
        if (notificationsResponse.ok) {
          const notificationsData = await notificationsResponse.json();
          setNotifications(notificationsData.notifications);
          setUnreadNotifications(notificationsData.unread);
        }
        
        // Fetch active crises
        const activeCrisesResponse = await fetch('/api/crisis/active', {
          credentials: 'include',
        });
        
        if (activeCrisesResponse.ok) {
          const activeCrisesData = await activeCrisesResponse.json();
          setActiveCrises(activeCrisesData.crises);
        }
        
        // Fetch nearby events if we have user location
        if (userData.location) {
          const nearbyResponse = await fetch(`/api/crisis/nearby?location=${userData.location}`, {
            credentials: 'include',
          });
          
          if (nearbyResponse.ok) {
            const nearbyData = await nearbyResponse.json();
            setNearbyEvents(nearbyData.events);
          }
        }
        
        setError(null);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please refresh the page.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchUserData();
  }, [navigate]);
  
  // Handle notification click
  const handleNotificationClick = async (notificationId) => {
    try {
      // Mark notification as read
      await fetch(`/api/user/notifications/${notificationId}/read`, {
        method: 'POST',
        credentials: 'include',
      });
      
      // Update notifications state
      setNotifications(prevNotifications => 
        prevNotifications.map(notification => 
          notification.id === notificationId 
            ? { ...notification, read: true } 
            : notification
        )
      );
      
      setUnreadNotifications(prev => Math.max(0, prev - 1));
      
      // Find the notification
      const notification = notifications.find(n => n.id === notificationId);
      
      // Navigate based on notification type
      if (notification && notification.link) {
        navigate(notification.link);
      }
    } catch (err) {
      console.error('Error handling notification:', err);
    }
  };
  
  // Handle mark all notifications as read
  const markAllNotificationsAsRead = async () => {
    try {
      await fetch('/api/user/notifications/read-all', {
        method: 'POST',
        credentials: 'include',
      });
      
      // Update notifications state
      setNotifications(prevNotifications => 
        prevNotifications.map(notification => ({ ...notification, read: true }))
      );
      
      setUnreadNotifications(0);
    } catch (err) {
      console.error('Error marking all notifications as read:', err);
    }
  };
  
  // Handle logout
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      });
      
      // Clear any local storage auth tokens
      localStorage.removeItem('authToken');
      
      // Redirect to login page
      navigate('/login');
    } catch (err) {
      console.error('Error logging out:', err);
    }
  };
  
  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  // Format time for display
  const formatTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };
  
  // Format relative time
  const formatRelativeTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    // Convert to minutes, hours, days
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (minutes < 60) {
      return `${minutes} min${minutes === 1 ? '' : 's'} ago`;
    } else if (hours < 24) {
      return `${hours} hour${hours === 1 ? '' : 's'} ago`;
    } else if (days < 30) {
      return `${days} day${days === 1 ? '' : 's'} ago`;
    } else {
      return formatDate(dateString);
    }
  };
  
  // Get status color based on crisis severity
  const getSeverityColor = (severity) => {
    switch (severity.toLowerCase()) {
      case 'high':
        return 'text-red-600 bg-red-100';
      case 'medium':
        return 'text-orange-600 bg-orange-100';
      case 'low':
        return 'text-yellow-600 bg-yellow-100';
      default:
        return 'text-blue-600 bg-blue-100';
    }
  };
  
  // Get verification status badge
  const getVerificationBadge = (status) => {
    if (status === 'verified') {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
          <CheckCircle className="w-3 h-3 mr-1" />
          Verified
        </span>
      );
    } else if (status === 'pending') {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
          <Clock className="w-3 h-3 mr-1" />
          Pending
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
          <XCircle className="w-3 h-3 mr-1" />
          Rejected
        </span>
      );
    }
  };
  
  // Get trust score color
  const getTrustScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center">
        <Loader className="h-12 w-12 text-blue-500 animate-spin" />
        <h2 className="mt-4 text-xl font-medium text-gray-700">Loading dashboard...</h2>
      </div>
    );
  }
  
  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center px-4">
        <AlertCircle className="h-16 w-16 text-red-500" />
        <h2 className="mt-4 text-xl font-medium text-gray-900">Error Loading Dashboard</h2>
        <p className="mt-2 text-gray-600 text-center">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Refresh Page
        </button>
      </div>
    );
  }
  
  // No user data state (shouldn't happen, but just in case)
  if (!userData) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center px-4">
        <AlertCircle className="h-16 w-16 text-yellow-500" />
        <h2 className="mt-4 text-xl font-medium text-gray-900">Session Expired</h2>
        <p className="mt-2 text-gray-600 text-center">
          Your session may have expired. Please log in again to access your dashboard.
        </p>
        <button
          onClick={() => navigate('/login')}
          className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Go to Login
        </button>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header/Navigation */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              {/* Mobile menu button */}
              <button
                className="md:hidden p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none"
                onClick={() => setShowMobileMenu(!showMobileMenu)}
              >
                {showMobileMenu ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
              
              {/* Logo */}
              <div className="flex-shrink-0 flex items-center">
                <Shield className="h-8 w-8 text-red-600" />
                <span className="ml-2 text-xl font-bold text-gray-900 hidden md:block">
                  Crisis Response
                </span>
              </div>
              
              {/* Desktop navigation */}
              <nav className="hidden md:ml-6 md:flex md:space-x-8">
                <Link
                  to="/dashboard"
                  className="border-blue-500 text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  <Home className="h-4 w-4 mr-1" />
                  Dashboard
                </Link>
                <Link
                  to="/crisis-map"
                  className="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  <Map className="h-4 w-4 mr-1" />
                  Crisis Map
                </Link>
                <Link
                  to="/reports"
                  className="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  <FileText className="h-4 w-4 mr-1" />
                  Reports
                </Link>
                <Link
                  to="/messages"
                  className="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                >
                  <MessageSquare className="h-4 w-4 mr-1" />
                  Messages
                </Link>
              </nav>
            </div>
            
            {/* Right side navigation items */}
            <div className="flex items-center">
              {/* Report crisis button */}
              <Link
                to="/crisis/report"
                className="mr-4 bg-red-600 p-1 rounded-full text-white hover:bg-red-700 focus:outline-none"
              >
                <span className="sr-only">Report Crisis</span>
                <AlertTriangle className="h-6 w-6" />
              </Link>
              
              {/* Notifications */}
              <div className="relative">
                <button
                  className="p-1 rounded-full text-gray-600 hover:text-gray-900 focus:outline-none"
                  onClick={() => setShowNotifications(!showNotifications)}
                >
                  <span className="sr-only">View notifications</span>
                  <Bell className="h-6 w-6" />
                  {unreadNotifications > 0 && (
                    <span className="absolute top-0 right-0 block h-4 w-4 rounded-full bg-red-600 text-white text-xs flex items-center justify-center">
                      {unreadNotifications}
                    </span>
                  )}
                </button>
                
                {/* Notifications dropdown */}
                {showNotifications && (
                  <div className="origin-top-right absolute right-0 mt-2 w-96 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
                    <div className="py-1">
                      <div className="px-4 py-2 border-b border-gray-200 flex justify-between items-center">
                        <h3 className="text-sm font-medium text-gray-900">Notifications</h3>
                        {unreadNotifications > 0 && (
                          <button
                            onClick={markAllNotificationsAsRead}
                            className="text-xs text-blue-600 hover:text-blue-800"
                          >
                            Mark all as read
                          </button>
                        )}
                      </div>
                      
                      <div className="max-h-96 overflow-y-auto">
                        {notifications.length === 0 ? (
                          <div className="px-4 py-6 text-center">
                            <Bell className="mx-auto h-8 w-8 text-gray-400" />
                            <p className="mt-2 text-sm text-gray-500">You have no notifications</p>
                          </div>
                        ) : (
                          <div>
                            {notifications.map((notification) => (
                              <button
                                key={notification.id}
                                className={`block w-full text-left px-4 py-3 hover:bg-gray-50 border-b border-gray-100 transition-colors ${notification.read ? '' : 'bg-blue-50'}`}
                                onClick={() => handleNotificationClick(notification.id)}
                              >
                                <div className="flex items-start">
                                  <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                                    notification.type === 'alert' ? 'bg-red-100' :
                                    notification.type === 'update' ? 'bg-blue-100' :
                                    notification.type === 'info' ? 'bg-gray-100' : 'bg-green-100'
                                  }`}>
                                    {notification.type === 'alert' && <AlertTriangle className="h-4 w-4 text-red-600" />}
                                    {notification.type === 'update' && <Info className="h-4 w-4 text-blue-600" />}
                                    {notification.type === 'info' && <Info className="h-4 w-4 text-gray-600" />}
                                    {notification.type === 'success' && <CheckCircle className="h-4 w-4 text-green-600" />}
                                  </div>
                                  <div className="ml-3 flex-1">
                                    <p className="text-sm font-medium text-gray-900">{notification.title}</p>
                                    <p className="text-xs text-gray-500 mt-1">{notification.message}</p>
                                    <p className="text-xs text-gray-400 mt-1">{formatRelativeTime(notification.createdAt)}</p>
                                  </div>
                                  {!notification.read && (
                                    <div className="ml-2 flex-shrink-0">
                                      <span className="inline-block h-2 w-2 rounded-full bg-blue-600"></span>
                                    </div>
                                  )}
                                </div>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                      
                      {notifications.length > 0 && (
                        <div className="border-t border-gray-200 px-4 py-2">
                          <Link
                            to="/notifications"
                            className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                          >
                            View all notifications
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              {/* Profile dropdown */}
              <div className="ml-3 relative">
                <div>
                  <button
                    className="bg-white rounded-full flex items-center text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    onClick={() => navigate('/profile')}
                  >
                    <span className="sr-only">Open user menu</span>
                    {userData.avatar ? (
                      <img
                        className="h-8 w-8 rounded-full object-cover"
                        src={userData.avatar}
                        alt={`${userData.firstName} ${userData.lastName}`}
                      />
                    ) : (
                      <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
                        {userData.firstName.charAt(0)}{userData.lastName.charAt(0)}
                      </div>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Mobile menu */}
      {showMobileMenu && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/dashboard"
              className="bg-blue-50 border-blue-500 text-blue-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            >
              <div className="flex items-center">
                <Home className="h-5 w-5 mr-2" />
                Dashboard
              </div>
            </Link>
            <Link
              to="/crisis-map"
              className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            >
              <div className="flex items-center">
                <Map className="h-5 w-5 mr-2" />
                Crisis Map
              </div>
            </Link>
            <Link
              to="/reports"
              className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            >
              <div className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Reports
              </div>
            </Link>
            <Link
              to="/messages"
              className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            >
              <div className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                Messages
              </div>
            </Link>
          </div>
          
          <div className="pt-4 pb-3 border-t border-gray-200">
            <div className="flex items-center px-4">
              {userData.avatar ? (
                <img
                  className="h-10 w-10 rounded-full object-cover"
                  src={userData.avatar}
                  alt={`${userData.firstName} ${userData.lastName}`}
                />
              ) : (
                <div className="h-10 w-10 rounded-full bg-blue-600 flex items-center justify-center text-white">
                  {userData.firstName.charAt(0)}{userData.lastName.charAt(0)}
                </div>
              )}
              <div className="ml-3">
                <div className="text-base font-medium text-gray-800">
                  {userData.firstName} {userData.lastName}
                </div>
                <div className="text-sm font-medium text-gray-500">
                  {userData.email}
                </div>
              </div>
            </div>
            <div className="mt-3 space-y-1">
              <Link
                to="/profile"
                className="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                <div className="flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  Your Profile
                </div>
              </Link>
              <Link
                to="/settings"
                className="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                <div className="flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Settings
                </div>
              </Link>
              <Link
                to="/help"
                className="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                <div className="flex items-center">
                  <HelpCircle className="h-5 w-5 mr-2" />
                  Help & Resources
                </div>
              </Link>
              <button
                onClick={handleLogout}
                className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                <div className="flex items-center">
                  <LogOut className="h-5 w-5 mr-2" />
                  Sign out
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Main content */}
      <main className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Welcome banner with user role badge */}
          <div className="bg-white overflow-hidden shadow rounded-lg mb-6">
            <div className="px-4 py-5 sm:px-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">
                    Welcome, {userData.firstName}!
                  </h1>
                  <p className="mt-1 text-sm text-gray-500 flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {new Date().toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
                <div>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    userData.role === 'responder' ? 'bg-blue-100 text-blue-800' :
                    userData.role === 'coordinator' ? 'bg-purple-100 text-purple-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {userData.role === 'responder' && <Shield className="h-4 w-4 mr-1" />}
                    {userData.role === 'coordinator' && <Users className="h-4 w-4 mr-1" />}
                    {userData.role === 'civilian' && <User className="h-4 w-4 mr-1" />}
                    {userData.role.charAt(0).toUpperCase() + userData.role.slice(1)}
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Dashboard grid */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {/* Left column */}
            <div className="lg:col-span-2 space-y-6">
              {/* Active crises nearby */}
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                      <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
                      Active Crises
                    </h2>
                    <Link
                      to="/crisis-map"
                      className="text-sm font-medium text-blue-600 hover:text-blue-500 flex items-center"
                    >
                      View Map
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Link>
                  </div>
                </div>
                <ul className="divide-y divide-gray-200">
                  {activeCrises.length > 0 ? (
                    activeCrises.map((crisis) => (
                      <li key={crisis.id}>
                        <Link
                          to={`/crisis/details/${crisis.id}`}
                          className="block hover:bg-gray-50"
                        >
                          <div className="px-4 py-4 sm:px-6">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <div className="text-xl mr-3">
                                  {crisis.icon || '⚠️'}
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-gray-900">
                                    {crisis.title}
                                  </p>
                                  <p className="text-sm text-gray-500 mt-1 flex items-center">
                                    <MapPin className="h-4 w-4 mr-1" />
                                    {crisis.location}
                                  </p>
                                </div>
                              </div>
                              <div>
                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getSeverityColor(crisis.severity)}`}>
                                  {crisis.severity}
                                </span>
                              </div>
                            </div>
                            <div className="mt-2 text-sm text-gray-600 line-clamp-2">
                              {crisis.description}
                            </div>
                            <div className="mt-2 flex justify-between">
                              <span className="text-xs text-gray-500 flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {formatRelativeTime(crisis.updatedAt)}
                              </span>
                              {getVerificationBadge(crisis.verificationStatus)}
                            </div>
                          </div>
                        </Link>
                      </li>
                    ))
                  ) : (
                    <li className="px-4 py-6 text-center">
                      <CheckCircle className="mx-auto h-8 w-8 text-green-400" />
                      <p className="mt-2 text-sm text-gray-500">
                        No active crises in your area
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        Check back regularly for updates
                      </p>
                    </li>
                  )}
                </ul>
              </div>
              
              {/* Your recent reports */}
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                      <FileText className="h-5 w-5 text-gray-600 mr-2" />
                      Your Recent Reports
                    </h2>
                    <Link
                      to="/reports"
                      className="text-sm font-medium text-blue-600 hover:text-blue-500 flex items-center"
                    >
                      View All Reports
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Link>
                  </div>
                </div>
                <div className="overflow-hidden">
                  {userReports.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Crisis Type
                            </th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Date Reported
                            </th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Location
                            </th>
                            <th scope="col" className="relative px-4 py-3">
                              <span className="sr-only">View</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {userReports.slice(0, 5).map((report) => (
                            <tr key={report.id} className="hover:bg-gray-50">
                              <td className="px-4 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <span className="text-lg mr-2">{report.icon || '⚠️'}</span>
                                  <div className="text-sm font-medium text-gray-900">
                                    {report.crisisType}
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">{formatDate(report.createdAt)}</div>
                                <div className="text-xs text-gray-500">{formatTime(report.createdAt)}</div>
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap">
                                {getVerificationBadge(report.status)}
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900 truncate max-w-xs">
                                  {report.location}
                                </div>
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <Link 
                                  to={`/reports/${report.id}`} 
                                  className="text-blue-600 hover:text-blue-900"
                                >
                                  View
                                </Link>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="px-4 py-6 text-center">
                      <FileText className="mx-auto h-8 w-8 text-gray-400" />
                      <p className="mt-2 text-sm text-gray-500">You haven't submitted any reports yet</p>
                      <Link
                        to="/crisis/report"
                        className="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm leading-5 font-medium rounded-md text-white bg-blue-600 hover:bg-blue-500 focus:outline-none focus:border-blue-700 focus:shadow-outline-blue active:bg-blue-700 transition ease-in-out duration-150"
                      >
                        <AlertTriangle className="h-4 w-4 mr-1" />
                        Report a Crisis
                      </Link>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Nearby events */}
              {nearbyEvents.length > 0 && (
                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                    <h2 className="text-lg font-medium text-gray-900 flex items-center">
                      <MapPin className="h-5 w-5 text-blue-600 mr-2" />
                      Events Near You
                    </h2>
                  </div>
                  <ul className="divide-y divide-gray-200">
                    {nearbyEvents.map((event) => (
                      <li key={event.id} className="px-4 py-4 hover:bg-gray-50">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="text-xl mr-3">
                              {event.icon || '📍'}
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-900">
                                {event.title}
                              </p>
                              <p className="text-sm text-gray-500 mt-1 flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                {formatDate(event.date)} at {formatTime(event.date)}
                              </p>
                            </div>
                          </div>
                          <div className="ml-2">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              {event.distance} miles away
                            </span>
                          </div>
                        </div>
                        <p className="mt-2 text-sm text-gray-600">
                          {event.description}
                        </p>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            {/* Right column */}
            <div className="space-y-6">
              {/* User profile card */}
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                  <h2 className="text-lg font-medium text-gray-900 flex items-center">
                    <User className="h-5 w-5 text-gray-500 mr-2" />
                    Your Profile
                  </h2>
                </div>
                
                <div className="px-4 py-5 sm:p-6 text-center">
                  {userData.avatar ? (
                    <img
                      className="mx-auto h-24 w-24 rounded-full object-cover border-2 border-white shadow"
                      src={userData.avatar}
                      alt={`${userData.firstName} ${userData.lastName}`}
                    />
                  ) : (
                    <div className="mx-auto h-24 w-24 rounded-full bg-blue-600 flex items-center justify-center text-white text-xl font-semibold shadow">
                      {userData.firstName.charAt(0)}{userData.lastName.charAt(0)}
                    </div>
                  )}
                  
                  <h3 className="mt-4 text-lg font-medium text-gray-900">
                    {userData.firstName} {userData.lastName}
                  </h3>
                  
                  <p className="text-sm text-gray-500">
                    {userData.email}
                  </p>
                  
                  {userData.organization && (
                    <p className="mt-1 text-sm text-gray-500">
                      {userData.organization}
                    </p>
                  )}
                  
                  <div className="mt-4 flex justify-center">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                      userData.verificationStatus === 'verified' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {userData.verificationStatus === 'verified' ? (
                        <>
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Verified Account
                        </>
                      ) : (
                        <>
                          <Clock className="h-4 w-4 mr-1" />
                          Verification Pending
                        </>
                      )}
                    </span>
                  </div>
                  
                  <div className="mt-6">
                    <Link
                      to="/profile"
                      className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200"
                    >
                      View Full Profile
                    </Link>
                  </div>
                </div>
              </div>
              
              {/* User stats */}
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                  <h2 className="text-lg font-medium text-gray-900 flex items-center">
                    <BarChart2 className="h-5 w-5 text-gray-500 mr-2" />
                    Your Activity
                  </h2>
                </div>
                <div className="px-4 py-5 sm:p-6">
                  <dl className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div className="bg-gray-50 overflow-hidden rounded-lg p-4">
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Total Reports
                      </dt>
                      <dd className="mt-1 text-3xl font-semibold text-gray-900">
                        {userStats.totalReports}
                      </dd>
                    </div>
                    <div className="bg-gray-50 overflow-hidden rounded-lg p-4">
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Verified Reports
                      </dt>
                      <dd className="mt-1 text-3xl font-semibold text-green-600">
                        {userStats.verifiedReports}
                      </dd>
                    </div>
                    <div className="bg-gray-50 overflow-hidden rounded-lg p-4">
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Pending Reports
                      </dt>
                      <dd className="mt-1 text-3xl font-semibold text-yellow-600">
                        {userStats.pendingReports}
                      </dd>
                    </div>
                    <div className="bg-gray-50 overflow-hidden rounded-lg p-4">
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Trust Score
                      </dt>
                      <dd className={`mt-1 text-3xl font-semibold ${getTrustScoreColor(userStats.trustScore)}`}>
                        {userStats.trustScore}
                      </dd>
                    </div>
                  </dl>
                </div>
              </div>
              
              {/* Quick actions */}
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                  <h2 className="text-lg font-medium text-gray-900 flex items-center">
                    <Zap className="h-5 w-5 text-yellow-500 mr-2" />
                    Quick Actions
                  </h2>
                </div>
                <div className="px-4 py-5 sm:p-6">
                  <div className="space-y-3">
                    <Link
                      to="/crisis/report"
                      className="w-full block px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 flex items-center justify-center"
                    >
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Report Crisis
                    </Link>
                    <Link
                      to="/crisis-map"
                      className="w-full block px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 flex items-center justify-center"
                    >
                      <Map className="h-4 w-4 mr-2" />
                      View Crisis Map
                    </Link>
                    <Link
                      to="/training"
                      className="w-full block px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 flex items-center justify-center"
                    >
                      <Shield className="h-4 w-4 mr-2" />
                      Crisis Training
                    </Link>
                    <Link
                      to="/help"
                      className="w-full block px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 flex items-center justify-center"
                    >
                      <HelpCircle className="h-4 w-4 mr-2" />
                      Help & Resources
                    </Link>
                  </div>
                </div>
              </div>
              
              {/* System status */}
              <div className="bg-white overflow-hidden shadow rounded-lg">
                <div className="px-4 py-5 sm:px-6 flex items-center justify-between">
                  <h2 className="text-sm font-medium text-gray-500">System Status</h2>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <span className="h-2 w-2 mr-1 rounded-full bg-green-400"></span>
                    All Systems Operational
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex justify-center md:justify-start space-x-6">
              <Link to="/about" className="text-sm text-gray-500 hover:text-gray-900">
                About
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-gray-900">
                Privacy
              </Link>
              <Link to="/terms" className="text-sm text-gray-500 hover:text-gray-900">
                Terms
              </Link>
              <Link to="/help" className="text-sm text-gray-500 hover:text-gray-900">
                Help
              </Link>
              <Link to="/contact" className="text-sm text-gray-500 hover:text-gray-900">
                Contact
              </Link>
            </div>
            <p className="mt-4 text-xs text-gray-400 text-center md:mt-0 md:text-right">
              &copy; {new Date().getFullYear()} Crisis Response Platform. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;