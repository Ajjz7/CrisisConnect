import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Phone, 
  AlertTriangle, 
  Shield, 
  Bookmark, 
  FileText, 
  Download, 
  ExternalLink, 
  Map, 
  Filter, 
  ChevronDown, 
  ChevronUp, 
  Clock, 
  Heart, 
  AlertCircle, 
  User, 
  Droplet, 
  Wind, 
  Thermometer, 
  Umbrella, 
  Zap, 
  HelpCircle, 
  Smartphone,
  Info,
  Loader,
  MapPin
} from 'lucide-react';

const Resources = () => {
  // State for search and filtering
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(true);
  const [resources, setResources] = useState([]);
  const [userLocation, setUserLocation] = useState(null);
  const [showEmergencyContacts, setShowEmergencyContacts] = useState(true);
  const [resourceCategories, setResourceCategories] = useState([]);
  const [expandedSections, setExpandedSections] = useState({
    emergency: true,
    general: true,
    disaster: true,
    preparations: true,
    guides: true,
    local: false
  });
  
  // Fetch resources and location on component mount
  useEffect(() => {
    const fetchResources = async () => {
      setLoading(true);
      try {
        // In a real app, this would be an API call
        // Simulating API call with timeout
        setTimeout(() => {
          const mockResources = generateMockResources();
          setResources(mockResources);
          
          // Extract unique categories
          const categories = [...new Set(mockResources.map(resource => resource.category))];
          setResourceCategories(categories);
          
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching resources:', error);
        setLoading(false);
      }
    };
    
    const getUserLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setUserLocation({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
          },
          (error) => {
            console.error('Error getting location:', error);
          }
        );
      }
    };
    
    fetchResources();
    getUserLocation();
  }, []);
  
  // Mock data generator function (in real app this would be API data)
  const generateMockResources = () => {
    return [
      {
        id: 1,
        title: "Emergency Services",
        description: "Contact information for police, fire, and medical emergency services.",
        type: "contact",
        category: "emergency",
        phone: "911",
        website: "https://www.911.gov/",
        icon: <AlertTriangle className="h-6 w-6 text-red-600" />,
        priority: 1
      },
      {
        id: 2,
        title: "FEMA Emergency App",
        description: "Official FEMA app for emergency alerts, safety tips, and shelter information.",
        type: "app",
        category: "emergency",
        icon: <Smartphone className="h-6 w-6 text-blue-600" />,
        downloadLinks: {
          android: "https://play.google.com/store/apps/details?id=gov.fema.mobile.android",
          ios: "https://apps.apple.com/us/app/fema/id474807486"
        },
        priority: 2
      },
      {
        id: 3,
        title: "Red Cross Emergency App",
        description: "Provides access to emergency preparedness information, first aid instructions, and shelter locations.",
        type: "app",
        category: "emergency",
        icon: <Heart className="h-6 w-6 text-red-600" />,
        downloadLinks: {
          android: "https://play.google.com/store/apps/details?id=com.cube.arc.blood",
          ios: "https://apps.apple.com/us/app/emergency-by-american-red-cross/id954783878"
        },
        priority: 3
      },
      {
        id: 4,
        title: "Poison Control Hotline",
        description: "24/7 assistance for poison emergencies and information.",
        type: "contact",
        category: "emergency",
        phone: "1-800-222-1222",
        website: "https://www.poison.org/",
        icon: <AlertCircle className="h-6 w-6 text-green-600" />,
        priority: 4
      },
      {
        id: 5,
        title: "Crisis Counseling & Support",
        description: "24/7 mental health crisis support and suicide prevention.",
        type: "contact",
        category: "emergency",
        phone: "988",
        textline: "741741",
        website: "https://988lifeline.org/",
        icon: <User className="h-6 w-6 text-purple-600" />,
        priority: 5
      },
      {
        id: 6,
        title: "Hurricane Preparedness Guide",
        description: "Comprehensive guide for preparing for and staying safe during hurricanes.",
        type: "document",
        category: "disaster",
        fileType: "pdf",
        fileSize: "2.3 MB",
        downloadUrl: "/resources/hurricane-guide.pdf",
        icon: <Wind className="h-6 w-6 text-blue-600" />,
        tags: ["hurricane", "storm", "weather"]
      },
      {
        id: 7,
        title: "Flood Safety",
        description: "Information on flood warnings, preparation, and evacuation.",
        type: "document",
        category: "disaster",
        fileType: "pdf",
        fileSize: "1.8 MB",
        downloadUrl: "/resources/flood-safety.pdf",
        icon: <Droplet className="h-6 w-6 text-blue-600" />,
        tags: ["flood", "water", "weather"]
      },
      {
        id: 8,
        title: "Earthquake Response",
        description: "What to do before, during, and after an earthquake.",
        type: "document",
        category: "disaster",
        fileType: "pdf",
        fileSize: "3.1 MB",
        downloadUrl: "/resources/earthquake-response.pdf",
        icon: <Zap className="h-6 w-6 text-yellow-600" />,
        tags: ["earthquake", "seismic", "geological"]
      },
      {
        id: 9,
        title: "Wildfire Safety",
        description: "Prevention tips and evacuation guidelines for wildfires.",
        type: "document",
        category: "disaster",
        fileType: "pdf",
        fileSize: "2.7 MB",
        downloadUrl: "/resources/wildfire-safety.pdf",
        icon: <AlertTriangle className="h-6 w-6 text-orange-600" />,
        tags: ["fire", "wildfire", "evacuation"]
      },
      {
        id: 10,
        title: "Extreme Weather Guide",
        description: "Safety information for extreme heat, cold, and severe weather events.",
        type: "document",
        category: "disaster",
        fileType: "pdf",
        fileSize: "4.2 MB",
        downloadUrl: "/resources/extreme-weather.pdf",
        icon: <Thermometer className="h-6 w-6 text-red-600" />,
        tags: ["weather", "heat", "cold", "storm"]
      },
      {
        id: 11,
        title: "Emergency Kit Checklist",
        description: "Essential items to include in your emergency preparedness kit.",
        type: "checklist",
        category: "preparations",
        fileType: "pdf",
        fileSize: "1.2 MB",
        downloadUrl: "/resources/emergency-kit.pdf",
        icon: <Bookmark className="h-6 w-6 text-purple-600" />,
        tags: ["kit", "preparedness", "supplies"]
      },
      {
        id: 12,
        title: "Family Emergency Plan Template",
        description: "Create a customized emergency plan for your family.",
        type: "interactive",
        category: "preparations",
        website: "https://www.ready.gov/plan",
        icon: <FileText className="h-6 w-6 text-green-600" />,
        tags: ["family", "plan", "preparedness"]
      },
      {
        id: 13,
        title: "Evacuation Planning Guide",
        description: "How to prepare for and execute an evacuation during emergencies.",
        type: "document",
        category: "preparations",
        fileType: "pdf",
        fileSize: "2.5 MB",
        downloadUrl: "/resources/evacuation-guide.pdf",
        icon: <Map className="h-6 w-6 text-blue-600" />,
        tags: ["evacuation", "planning", "safety"]
      },
      {
        id: 14,
        title: "First Aid Basics",
        description: "Basic first aid procedures for common emergencies.",
        type: "guide",
        category: "guides",
        website: "https://www.redcross.org/get-help/how-to-prepare-for-emergencies/types-of-emergencies.html",
        icon: <Heart className="h-6 w-6 text-red-600" />,
        tags: ["first aid", "medical", "health"]
      },
      {
        id: 15,
        title: "Water Safety & Purification",
        description: "Guidelines for securing and purifying water during emergencies.",
        type: "guide",
        category: "guides",
        fileType: "pdf",
        fileSize: "1.7 MB",
        downloadUrl: "/resources/water-purification.pdf",
        icon: <Droplet className="h-6 w-6 text-blue-600" />,
        tags: ["water", "purification", "safety"]
      },
      {
        id: 16,
        title: "Food Storage Guide",
        description: "Long-term food storage techniques and safety information.",
        type: "guide",
        category: "guides",
        fileType: "pdf",
        fileSize: "2.1 MB",
        downloadUrl: "/resources/food-storage.pdf",
        icon: <FileText className="h-6 w-6 text-yellow-600" />,
        tags: ["food", "storage", "preparedness"]
      },
      {
        id: 17,
        title: "Pet Emergency Preparedness",
        description: "How to keep your pets safe during disasters and emergencies.",
        type: "guide",
        category: "guides",
        fileType: "pdf",
        fileSize: "1.9 MB",
        downloadUrl: "/resources/pet-emergency.pdf",
        icon: <Heart className="h-6 w-6 text-pink-600" />,
        tags: ["pets", "animals", "preparedness"]
      },
      {
        id: 18,
        title: "Disability Inclusive Emergency Planning",
        description: "Emergency preparedness resources for people with disabilities.",
        type: "guide",
        category: "guides",
        website: "https://www.ready.gov/disability",
        icon: <HelpCircle className="h-6 w-6 text-blue-600" />,
        tags: ["disability", "accessibility", "planning"]
      },
      {
        id: 19,
        title: "Weather Radio Information",
        description: "Guide to NOAA Weather Radios and emergency alert systems.",
        type: "guide",
        category: "general",
        fileType: "pdf",
        fileSize: "1.5 MB",
        downloadUrl: "/resources/weather-radio.pdf",
        icon: <Umbrella className="h-6 w-6 text-purple-600" />,
        tags: ["radio", "weather", "alerts"]
      },
      {
        id: 20,
        title: "Shelter Locations",
        description: "Map of emergency shelters and evacuation centers.",
        type: "map",
        category: "local",
        website: "https://www.redcross.org/get-help/disaster-relief-and-recovery-services/find-an-open-shelter.html",
        icon: <MapPin className="h-6 w-6 text-red-600" />,
        tags: ["shelter", "evacuation", "map"]
      }
    ];
  };
  
  // Get emergency contact resources
  const emergencyContacts = resources.filter(resource => 
    resource.type === 'contact' && resource.category === 'emergency'
  ).sort((a, b) => a.priority - b.priority);
  
  // Filter resources based on search and filters
  const filteredResources = resources.filter(resource => {
    // Search term filter
    const matchesSearch = searchTerm === '' || 
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (resource.tags && resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())));
    
    // Category filter
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    
    // Type filter
    const matchesType = selectedType === 'all' || resource.type === selectedType;
    
    return matchesSearch && matchesCategory && matchesType;
  });
  
  // Group resources by category for display
  const resourcesByCategory = {
    emergency: filteredResources.filter(r => r.category === 'emergency'),
    general: filteredResources.filter(r => r.category === 'general'),
    disaster: filteredResources.filter(r => r.category === 'disaster'),
    preparations: filteredResources.filter(r => r.category === 'preparations'),
    guides: filteredResources.filter(r => r.category === 'guides'),
    local: filteredResources.filter(r => r.category === 'local')
  };
  
  // Handle search input change
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };
  
  // Toggle section expansion
  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };
  
  // Render a resource card
  const renderResourceCard = (resource) => {
    return (
      <div key={resource.id} className="bg-white overflow-hidden shadow rounded-lg hover:shadow-md transition-shadow">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-start">
            <div className="flex-shrink-0 mt-1">
              {resource.icon}
            </div>
            <div className="ml-4 flex-1">
              <h3 className="text-lg font-medium text-gray-900">{resource.title}</h3>
              <p className="mt-1 text-sm text-gray-600">{resource.description}</p>
              
              {/* Contact information */}
              {resource.type === 'contact' && resource.phone && (
                <div className="mt-3">
                  <a 
                    href={`tel:${resource.phone}`} 
                    className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                  >
                    <Phone className="h-4 w-4 mr-1" />
                    Call {resource.phone}
                  </a>
                  
                  {resource.textline && (
                    <p className="mt-2 text-sm text-gray-600">
                      Text: <span className="font-medium">{resource.textline}</span>
                    </p>
                  )}
                </div>
              )}
              
              {/* App download links */}
              {resource.type === 'app' && resource.downloadLinks && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {resource.downloadLinks.android && (
                    <a 
                      href={resource.downloadLinks.android} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                    >
                      <Download className="h-4 w-4 mr-1" />
                      Android
                    </a>
                  )}
                  
                  {resource.downloadLinks.ios && (
                    <a 
                      href={resource.downloadLinks.ios} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-gray-800 hover:bg-gray-900"
                    >
                      <Download className="h-4 w-4 mr-1" />
                      iOS
                    </a>
                  )}
                </div>
              )}
              
              {/* Document download */}
              {resource.type === 'document' && resource.downloadUrl && (
                <div className="mt-3">
                  <a 
                    href={resource.downloadUrl} 
                    download
                    className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Download ({resource.fileType}, {resource.fileSize})
                  </a>
                </div>
              )}
              
              {/* Website link */}
              {resource.website && (
                <div className={`${(resource.type === 'document' || resource.type === 'app' || resource.type === 'contact') ? 'mt-2' : 'mt-3'}`}>
                  <a 
                    href={resource.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
                  >
                    Visit Website
                    <ExternalLink className="h-4 w-4 ml-1" />
                  </a>
                </div>
              )}
              
              {/* Tags */}
              {resource.tags && resource.tags.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-1">
                  {resource.tags.map(tag => (
                    <span 
                      key={tag} 
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                      onClick={() => setSearchTerm(tag)}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Shield className="h-8 w-8 text-red-600 mr-3" />
              Emergency Resources
            </h1>
            <p className="mt-1 text-sm text-gray-600">
              Access critical emergency information, contacts, and preparedness materials
            </p>
          </div>
        </div>
      </header>
      
      {/* Emergency Contacts Banner (Always Visible) */}
      {showEmergencyContacts && emergencyContacts.length > 0 && (
        <div className="bg-red-50 border-t border-b border-red-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium text-red-800 flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                Emergency Contacts
              </h2>
              <button 
                onClick={() => setShowEmergencyContacts(false)}
                className="text-red-600 hover:text-red-800 text-sm font-medium"
              >
                Hide
              </button>
            </div>
            
            <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {emergencyContacts.map(contact => (
                <div key={contact.id} className="bg-white rounded-md shadow-sm p-3 flex items-center">
                  <div className="flex-shrink-0">
                    {contact.icon}
                  </div>
                  <div className="ml-3 flex-1">
                    <h3 className="text-sm font-medium text-gray-900">{contact.title}</h3>
                    <a 
                      href={`tel:${contact.phone}`} 
                      className="text-lg font-bold text-red-600 hover:text-red-800"
                    >
                      {contact.phone}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      
      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Search and filters */}
        <div className="bg-white shadow rounded-lg mb-6">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex flex-col sm:flex-row">
              {/* Search bar */}
              <div className="flex-1 mb-4 sm:mb-0 sm:mr-4">
                <div className="relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={handleSearchChange}
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 pr-12 py-2 sm:text-sm border-gray-300 rounded-md"
                    placeholder="Search resources..."
                  />
                  {searchTerm && (
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                      <button
                        onClick={() => setSearchTerm('')}
                        className="text-gray-400 hover:text-gray-500 focus:outline-none"
                      >
                        <span className="sr-only">Clear search</span>
                        <X className="h-5 w-5" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Filter toggle button */}
              <div>
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="w-full inline-flex items-center justify-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                >
                  <Filter className="h-5 w-5 mr-2 text-gray-400" />
                  Filters
                  {showFilters ? (
                    <ChevronUp className="ml-2 h-5 w-5 text-gray-400" />
                  ) : (
                    <ChevronDown className="ml-2 h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
            </div>
            
            {/* Expanded filters */}
            {showFilters && (
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                {/* Category filter */}
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                    Resource Category
                  </label>
                  <select
                    id="category"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option value="all">All Categories</option>
                    <option value="emergency">Emergency</option>
                    <option value="disaster">Disaster Specific</option>
                    <option value="preparations">Preparedness</option>
                    <option value="guides">Guides & Instructions</option>
                    <option value="general">General Information</option>
                    <option value="local">Local Resources</option>
                  </select>
                </div>
                
                {/* Resource type filter */}
                <div>
                  <label htmlFor="resourceType" className="block text-sm font-medium text-gray-700">
                    Resource Type
                  </label>
                  <select
                    id="resourceType"
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                  >
                    <option value="all">All Types</option>
                    <option value="contact">Contact Information</option>
                    <option value="document">Documents</option>
                    <option value="guide">Guides</option>
                    <option value="app">Apps</option>
                    <option value="map">Maps</option>
                    <option value="checklist">Checklists</option>
                    <option value="interactive">Interactive Tools</option>
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Loading state */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader className="h-12 w-12 text-blue-500 animate-spin" />
            <h2 className="mt-4 text-lg font-medium text-gray-700">Loading resources...</h2>
          </div>
        ) : (
          <>
            {/* Results summary */}
            {searchTerm || selectedCategory !== 'all' || selectedType !== 'all' ? (
              <div className="mb-6">
                <p className="text-sm text-gray-600">
                  Showing {filteredResources.length} {filteredResources.length === 1 ? 'resource' : 'resources'}
                  {searchTerm && <span> for "<strong>{searchTerm}</strong>"</span>}
                  {selectedCategory !== 'all' && <span> in <strong>{selectedCategory}</strong> category</span>}
                  {selectedType !== 'all' && <span> of type <strong>{selectedType}</strong></span>}
                </p>
                {filteredResources.length === 0 && (
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setSelectedCategory('all');
                      setSelectedType('all');
                    }}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                  >
                    Clear all filters
                  </button>
                )}
              </div>
            ) : (
              <div className="mb-6 bg-blue-50 border border-blue-200 rounded-md p-4">
                <div className="flex">
                  <Info className="h-5 w-5 text-blue-400 mr-2" />
                  <div>
                    <h3 className="text-sm font-medium text-blue-800">Resource Information</h3>
                    <div className="mt-2 text-sm text-blue-700">
                      <p>These resources are designed to help you before, during, and after emergencies. Save important contacts to your phone and download critical documents for offline access.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {filteredResources.length === 0 ? (
              <div className="bg-white shadow overflow-hidden rounded-lg">
                <div className="px-4 py-12 text-center">
                  <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-lg font-medium text-gray-900">No resources found</h3>
                  <p className="mt-1 text-sm text-gray-500">Try adjusting your search or filters to find what you're looking for.</p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Emergency Resources Section */}
                {resourcesByCategory.emergency.length > 0 && (
                  <div className="bg-white shadow overflow-hidden rounded-lg">
                    <div 
                      className="px-4 py-5 sm:px-6 border-b border-gray-200 cursor-pointer"
                      onClick={() => toggleSection('emergency')}
                    >
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-medium text-gray-900 flex items-center">
                          <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
                          Emergency Resources
                        </h2>
                        {expandedSections.emergency ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    {expandedSections.emergency && (
                      <div className="divide-y divide-gray-200">
                        {resourcesByCategory.emergency.map(resource => renderResourceCard(resource))}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Disaster Specific Resources Section */}
                {resourcesByCategory.disaster.length > 0 && (
                  <div className="bg-white shadow overflow-hidden rounded-lg">
                    <div 
                      className="px-4 py-5 sm:px-6 border-b border-gray-200 cursor-pointer"
                      onClick={() => toggleSection('disaster')}
                    >
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-medium text-gray-900 flex items-center">
                          <Umbrella className="h-5 w-5 text-blue-600 mr-2" />
                          Disaster-Specific Resources
                        </h2>
                        {expandedSections.disaster ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    {expandedSections.disaster && (
                      <div className="divide-y divide-gray-200">
                        {resourcesByCategory.disaster.map(resource => renderResourceCard(resource))}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Preparedness Resources Section */}
                {resourcesByCategory.preparations.length > 0 && (
                  <div className="bg-white shadow overflow-hidden rounded-lg">
                    <div 
                      className="px-4 py-5 sm:px-6 border-b border-gray-200 cursor-pointer"
                      onClick={() => toggleSection('preparations')}
                    >
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-medium text-gray-900 flex items-center">
                          <Shield className="h-5 w-5 text-purple-600 mr-2" />
                          Preparedness Resources
                        </h2>
                        {expandedSections.preparations ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    {expandedSections.preparations && (
                      <div className="divide-y divide-gray-200">
                        {resourcesByCategory.preparations.map(resource => renderResourceCard(resource))}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Guides & Instructions Section */}
                {resourcesByCategory.guides.length > 0 && (
                  <div className="bg-white shadow overflow-hidden rounded-lg">
                    <div 
                      className="px-4 py-5 sm:px-6 border-b border-gray-200 cursor-pointer"
                      onClick={() => toggleSection('guides')}
                    >
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-medium text-gray-900 flex items-center">
                          <FileText className="h-5 w-5 text-green-600 mr-2" />
                          Guides & Instructions
                        </h2>
                        {expandedSections.guides ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    {expandedSections.guides && (
                      <div className="divide-y divide-gray-200">
                        {resourcesByCategory.guides.map(resource => renderResourceCard(resource))}
                      </div>
                    )}
                  </div>
                )}
                
                {/* General Information Section */}
                {resourcesByCategory.general.length > 0 && (
                  <div className="bg-white shadow overflow-hidden rounded-lg">
                    <div 
                      className="px-4 py-5 sm:px-6 border-b border-gray-200 cursor-pointer"
                      onClick={() => toggleSection('general')}
                    >
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-medium text-gray-900 flex items-center">
                          <Info className="h-5 w-5 text-blue-600 mr-2" />
                          General Information
                        </h2>
                        {expandedSections.general ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    {expandedSections.general && (
                      <div className="divide-y divide-gray-200">
                        {resourcesByCategory.general.map(resource => renderResourceCard(resource))}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Local Resources Section */}
                {resourcesByCategory.local.length > 0 && (
                  <div className="bg-white shadow overflow-hidden rounded-lg">
                    <div 
                      className="px-4 py-5 sm:px-6 border-b border-gray-200 cursor-pointer"
                      onClick={() => toggleSection('local')}
                    >
                      <div className="flex items-center justify-between">
                        <h2 className="text-lg font-medium text-gray-900 flex items-center">
                          <MapPin className="h-5 w-5 text-red-600 mr-2" />
                          Local Resources
                          {userLocation && <span className="ml-2 text-sm font-normal text-gray-500">(Based on your location)</span>}
                        </h2>
                        {expandedSections.local ? (
                          <ChevronUp className="h-5 w-5 text-gray-500" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-gray-500" />
                        )}
                      </div>
                    </div>
                    
                    {expandedSections.local && (
                      <div>
                        {!userLocation ? (
                          <div className="px-4 py-5 sm:p-6 text-center">
                            <MapPin className="mx-auto h-8 w-8 text-gray-400" />
                            <h3 className="mt-2 text-sm font-medium text-gray-900">Location access needed</h3>
                            <p className="mt-1 text-sm text-gray-500">Allow location access to see resources in your area.</p>
                            <button
                              onClick={() => {
                                if (navigator.geolocation) {
                                  navigator.geolocation.getCurrentPosition(
                                    (position) => {
                                      setUserLocation({
                                        lat: position.coords.latitude,
                                        lng: position.coords.longitude,
                                      });
                                    },
                                    (error) => {
                                      console.error('Error getting location:', error);
                                    }
                                  );
                                }
                              }}
                              className="mt-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
                            >
                              Enable Location
                            </button>
                          </div>
                        ) : (
                          <div className="divide-y divide-gray-200">
                            {resourcesByCategory.local.map(resource => renderResourceCard(resource))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>
      
      {/* Location-based alert */}
      {userLocation && !showEmergencyContacts && (
        <div className="fixed bottom-0 right-0 m-6">
          <button
            onClick={() => setShowEmergencyContacts(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700"
          >
            <Phone className="h-4 w-4 mr-2" />
            Show Emergency Contacts
          </button>
        </div>
      )}
      
      {/* Footer */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex justify-center md:justify-start space-x-6">
              <Link to="/about" className="text-sm text-gray-500 hover:text-gray-900">
                About
              </Link>
              <Link to="/privacy" className="text-sm text-gray-500 hover:text-gray-900">
                Privacy
              </Link>
              <Link to="/terms" className="text-sm text-gray-500 hover:text-gray-900">
                Terms
              </Link>
              <Link to="/help" className="text-sm text-gray-500 hover:text-gray-900">
                Help Center
              </Link>
              <Link to="/contact" className="text-sm text-gray-500 hover:text-gray-900">
                Contact
              </Link>
            </div>
            <div className="mt-8 md:mt-0 flex items-center">
              <Clock className="h-4 w-4 text-gray-400 mr-1" />
              <p className="text-xs text-gray-500">
                Resources last updated: {new Date().toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="mt-4 border-t border-gray-200 pt-4">
            <p className="text-sm text-gray-500 text-center">
              In case of emergency, always dial 911 (US) or your local emergency number immediately.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Resources;