#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
chatbot_api.py
------------
API endpoints for the CrisisConnect AI chatbot.
This module provides the Flask API routes for interacting with the AI chatbot model.
"""

import os
import json
import logging
import pickle
import nltk
import random
from datetime import datetime
from flask import Flask, request, jsonify, Blueprint
from flask_cors import CORS
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("chatbot_api.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Download NLTK resources
nltk.download('punkt')
nltk.download('wordnet')

# Initialize Blueprint
chatbot_api = Blueprint('chatbot_api', __name__)

# Global variables to store model and related objects
model = None
tokenizer = None
intents = None
words = None
classes = None
lemmatizer = nltk.stem.WordNetLemmatizer()
model_type = None
max_sequence_length = 20

def load_model_artifacts(config_path='config/chatbot_config.json'):
    """
    Load chatbot model and related artifacts.
    
    Args:
        config_path (str): Path to configuration file
    """
    global model, tokenizer, intents, words, classes, model_type, max_sequence_length
    
    try:
        # Load configuration
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        model_dir = config.get('model_dir', 'models')
        intents_file = config.get('intents_file', 'data/intents.json')
        model_path = config.get('model_path', '')
        model_type = config.get('model_type', 'lstm')
        max_sequence_length = config.get('max_sequence_length', 20)
        
        # If no specific model path provided, find the latest model
        if not model_path:
            # List all model files in the model directory
            model_files = [f for f in os.listdir(model_dir) if f.endswith('.h5')]
            if not model_files:
                raise FileNotFoundError("No model files found in model directory")
            
            # Sort by modification time (newest first)
            model_files.sort(key=lambda x: os.path.getmtime(os.path.join(model_dir, x)), reverse=True)
            model_path = os.path.join(model_dir, model_files[0])
            
            # Get model name without extension for loading other artifacts
            model_name = os.path.splitext(model_files[0])[0]
        else:
            model_path = os.path.join(model_dir, model_path)
            model_name = os.path.splitext(os.path.basename(model_path))[0]
        
        # Load model
        model = load_model(model_path)
        logger.info(f"Loaded model from {model_path}")
        
        # Load words
        with open(os.path.join(model_dir, f"{model_name}_words.pkl"), 'rb') as f:
            words = pickle.load(f)
        
        # Load classes
        with open(os.path.join(model_dir, f"{model_name}_classes.pkl"), 'rb') as f:
            classes = pickle.load(f)
        
        # Load tokenizer for LSTM model
        if model_type == 'lstm':
            with open(os.path.join(model_dir, f"{model_name}_tokenizer.pkl"), 'rb') as f:
                tokenizer = pickle.load(f)
        
        # Load intents
        with open(intents_file, 'r') as f:
            intents = json.load(f)
        
        logger.info(f"Successfully loaded model artifacts. Model type: {model_type}")
        
    except Exception as e:
        logger.error(f"Error loading model artifacts: {e}")
        raise

def preprocess_input(text):
    """
    Preprocess input text for prediction.
    
    Args:
        text (str): Input text
        
    Returns:
        numpy.ndarray: Preprocessed input ready for model prediction
    """
    if model_type == 'bow':
        # Clean up the input
        sentence_words = nltk.word_tokenize(text.lower())
        sentence_words = [lemmatizer.lemmatize(word) for word in sentence_words]
        
        # Bag of words
        bag = [0] * len(words)
        for w in sentence_words:
            for i, word in enumerate(words):
                if word == w:
                    bag[i] = 1
        
        return np.array([bag])
    
    elif model_type == 'lstm':
        # Convert to sequence
        sequence = tokenizer.texts_to_sequences([text.lower()])
        padded_sequence = pad_sequences(sequence, maxlen=max_sequence_length, padding='post')
        
        return padded_sequence

def get_response(intents_list, intent_json):
    """
    Get a random response for the predicted intent.
    
    Args:
        intents_list (list): List of predicted intents with probabilities
        intent_json (dict): JSON object containing intents and responses
        
    Returns:
        tuple: (response, metadata)
    """
    tag = intents_list[0]['intent']
    intents_list = intent_json['intents']
    
    for i in intents_list:
        if i['tag'] == tag:
            result = random.choice(i['responses'])
            metadata = i.get('metadata', {})
            return result, metadata
    
    return "I'm not sure how to respond to that. Can you rephrase?", {}

@chatbot_api.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint.
    """
    if model is None:
        return jsonify({
            'status': 'error',
            'message': 'Model not loaded'
        }), 503
    
    return jsonify({
        'status': 'ok',
        'message': 'Chatbot API is running',
        'model_type': model_type,
        'timestamp': datetime.now().isoformat()
    })

@chatbot_api.route('/predict', methods=['POST'])
def predict():
    """
    API endpoint for chatbot predictions.
    
    Expected JSON payload:
    {
        "message": "user message text",
        "session_id": "unique_session_id",
        "context": {} (optional context information)
    }
    """
    try:
        # Parse request
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({
                'status': 'error',
                'message': 'Missing required field: message'
            }), 400
        
        # Get user message
        user_message = data['message']
        session_id = data.get('session_id', 'unknown')
        context = data.get('context', {})
        
        # Preprocess input
        input_data = preprocess_input(user_message)
        
        # Make prediction
        if model_type == 'bow':
            prediction = model.predict(input_data)[0]
        else:
            prediction = model.predict(input_data)[0]
        
        # Get top intents
        ERROR_THRESHOLD = 0.25
        results = []
        for i, prob in enumerate(prediction):
            if prob > ERROR_THRESHOLD:
                results.append({'intent': classes[i], 'probability': float(prob)})
        
        # Sort by probability
        results.sort(key=lambda x: x['probability'], reverse=True)
        
        # Log the request and prediction
        logger.info(f"Session: {session_id}, Message: {user_message}, Predicted intent: {results[0]['intent'] if results else 'None'}")
        
        # If no intent matched the threshold
        if not results:
            return jsonify({
                'status': 'success',
                'message': "I'm not sure I understand. Could you rephrase that?",
                'intents': [],
                'metadata': {}
            })
        
        # Get response
        response_text, metadata = get_response(results, intents)
        
        # Prepare response
        response = {
            'status': 'success',
            'message': response_text,
            'intents': results,
            'metadata': metadata,
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Internal server error'
        }), 500

@chatbot_api.route('/debug', methods=['GET'])
def debug():
    """
    Debug endpoint for chatbot API.
    Returns information about the loaded model and intents.
    Only available in debug mode.
    """
    # Check if debug mode is enabled
    if not os.environ.get('FLASK_DEBUG', '').lower() == 'true':
        return jsonify({
            'status': 'error',
            'message': 'Debug endpoint only available in debug mode'
        }), 403
    
    intent_info = []
    if intents:
        for intent in intents['intents']:
            intent_info.append({
                'tag': intent['tag'],
                'patterns': len(intent['patterns']),
                'responses': len(intent['responses'])
            })
    
    debug_info = {
        'model_type': model_type,
        'model_loaded': model is not None,
        'num_classes': len(classes) if classes else 0,
        'num_words': len(words) if words else 0,
        'intent_info': intent_info
    }
    
    return jsonify(debug_info)

def create_app(config_path='config/chatbot_config.json'):
    """
    Create and configure the Flask application.
    
    Args:
        config_path (str): Path to configuration file
        
    Returns:
        Flask: Configured Flask application
    """
    app = Flask(__name__)
    CORS(app)
    
    # Load model artifacts
    load_model_artifacts(config_path)
    
    # Register blueprint
    app.register_blueprint(chatbot_api, url_prefix='/api/chatbot')
    
    return app

if __name__ == '__main__':
    # This allows the module to be run directly
    app = create_app()
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', '').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)