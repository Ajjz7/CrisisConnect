#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
prediction_api.py
---------------
API endpoints for crisis resource prediction in the CrisisConnect application.
This module provides the Flask API routes for analyzing crisis reports
and predicting required resources.
"""

import os
import json
import logging
import pickle
import nltk
from datetime import datetime
from flask import Flask, request, jsonify, Blueprint
from flask_cors import CORS
import numpy as np
import pandas as pd
import re
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("prediction_api.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Initialize Blueprint
prediction_api = Blueprint('prediction_api', __name__)

# Global variables to store model and related objects
model = None
label_encoder = None
multilabel = True
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def load_model_artifacts(config_path='config/resource_model_config.json'):
    """
    Load resource prediction model and related artifacts.
    
    Args:
        config_path (str): Path to configuration file
    """
    global model, label_encoder, multilabel
    
    try:
        # Load configuration
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        model_dir = config.get('model_dir', 'models')
        model_path = config.get('model_path', '')
        
        # If no specific model path provided, find the latest model
        if not model_path:
            # List all model files in the model directory
            model_files = [f for f in os.listdir(model_dir) if f.endswith('.pkl')]
            if not model_files:
                raise FileNotFoundError("No model files found in model directory")
            
            # Sort by modification time (newest first)
            model_files.sort(key=lambda x: os.path.getmtime(os.path.join(model_dir, x)), reverse=True)
            model_path = os.path.join(model_dir, model_files[0])
        else:
            model_path = os.path.join(model_dir, model_path)
        
        # Load model
        with open(model_path, 'rb') as f:
            model_data = pickle.load(f)
        
        model = model_data['model']
        label_encoder = model_data['label_encoder']
        multilabel = model_data.get('multilabel', True)
        
        logger.info(f"Loaded model from {model_path}")
        logger.info(f"Model type: {'multi-label' if multilabel else 'single-label'}")
        logger.info(f"Number of resource categories: {len(label_encoder)}")
        
    except Exception as e:
        logger.error(f"Error loading model artifacts: {e}")
        raise

def preprocess_text(text):
    """
    Preprocess text data for model prediction.
    
    Args:
        text (str): Text to preprocess
        
    Returns:
        str: Preprocessed text
    """
    if not isinstance(text, str):
        return ""
    
    # Convert to lowercase
    text = text.lower()
    
    # Remove special characters and numbers
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    
    # Tokenize
    tokens = nltk.word_tokenize(text)
    
    # Remove stopwords
    tokens = [word for word in tokens if word not in stop_words]
    
    # Lemmatize
    tokens = [lemmatizer.lemmatize(word) for word in tokens]
    
    # Rejoin tokens
    return ' '.join(tokens)

def predict_resources(text):
    """
    Predict required resources from crisis report text.
    
    Args:
        text (str): Crisis report text
        
    Returns:
        dict: Prediction results
    """
    # Preprocess the input text
    processed_text = preprocess_text(text)
    
    # Make prediction
    prediction = model.predict([processed_text])[0]
    
    # Process results based on model type
    results = []
    if multilabel:
        # Multi-label prediction
        for i, label in enumerate(label_encoder):
            if prediction[i] == 1:
                results.append({
                    'resource': label,
                    'required': True,
                    'confidence': 1.0  # For multi-label binary classification, we don't have confidence scores
                })
    else:
        # Single-label prediction
        if hasattr(model, 'predict_proba'):
            # Get probability scores
            proba = model.predict_proba([processed_text])[0]
            for i, prob in enumerate(proba):
                if prob > 0.1:  # Include resources with at least 10% confidence
                    results.append({
                        'resource': label_encoder[i],
                        'required': i == np.argmax(proba),
                        'confidence': float(prob)
                    })
        else:
            # No probability scores available
            predicted_label = label_encoder[prediction]
            results.append({
                'resource': predicted_label,
                'required': True,
                'confidence': 1.0
            })
    
    # Sort by confidence
    results.sort(key=lambda x: x['confidence'], reverse=True)
    
    return results

def extract_entities(text):
    """
    Extract important entities from crisis report text.
    This is a simplified version and should be enhanced with NER.
    
    Args:
        text (str): Crisis report text
        
    Returns:
        dict: Extracted entities
    """
    entities = {
        'locations': [],
        'quantities': [],
        'timestamps': [],
        'severity': 'medium'  # Default severity
    }
    
    # Example simple extraction logic (replace with proper NER in production)
    
    # Look for numbers followed by units (quantities)
    quantity_pattern = r'\b(\d+)\s*(people|person|individuals|victims|survivors|patients|homes|buildings|houses|gallons|liters|kg|tons)\b'
    quantities = re.findall(quantity_pattern, text, re.IGNORECASE)
    if quantities:
        entities['quantities'] = [f"{q[0]} {q[1]}" for q in quantities]
    
    # Simple severity assessment based on keywords
    severity_terms = {
        'high': ['catastrophic', 'devastating', 'severe', 'extreme', 'critical', 'emergency', 'urgent', 'disaster'],
        'medium': ['moderate', 'affected', 'damaged', 'impacted'],
        'low': ['minor', 'small', 'limited', 'contained', 'controlled']
    }
    
    # Check for severity keywords
    for severity, terms in severity_terms.items():
        if any(term in text.lower() for term in terms):
            entities['severity'] = severity
            break
    
    return entities

@prediction_api.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint.
    """
    if model is None:
        return jsonify({
            'status': 'error',
            'message': 'Model not loaded'
        }), 503
    
    return jsonify({
        'status': 'ok',
        'message': 'Prediction API is running',
        'model_type': 'multi-label' if multilabel else 'single-label',
        'num_resource_categories': len(label_encoder),
        'timestamp': datetime.now().isoformat()
    })

@prediction_api.route('/predict', methods=['POST'])
def predict():
    """
    API endpoint for crisis resource prediction.
    
    Expected JSON payload:
    {
        "report": "crisis report text",
        "report_id": "unique_report_id" (optional),
        "metadata": {} (optional context information)
    }
    """
    try:
        # Parse request
        data = request.get_json()
        
        if not data or 'report' not in data:
            return jsonify({
                'status': 'error',
                'message': 'Missing required field: report'
            }), 400
        
        # Get report text
        report_text = data['report']
        report_id = data.get('report_id', str(datetime.now().timestamp()))
        metadata = data.get('metadata', {})
        
        # Check if report text is empty
        if not report_text.strip():
            return jsonify({
                'status': 'error',
                'message': 'Report text cannot be empty'
            }), 400
        
        # Make prediction
        resources = predict_resources(report_text)
        
        # Extract additional entities
        entities = extract_entities(report_text)
        
        # Calculate summary statistics
        num_resources = len([r for r in resources if r.get('required', False)])
        priority_level = "HIGH" if entities['severity'] == 'high' or num_resources >= 3 else \
                         "MEDIUM" if entities['severity'] == 'medium' or num_resources >= 1 else "LOW"
        
        # Log the request and prediction
        logger.info(f"Report ID: {report_id}, Resources: {', '.join([r['resource'] for r in resources if r.get('required', False)])}")
        
        # Prepare response
        response = {
            'status': 'success',
            'report_id': report_id,
            'resources': resources,
            'entities': entities,
            'summary': {
                'num_resources_needed': num_resources,
                'priority_level': priority_level,
                'severity': entities['severity']
            },
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error processing request: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Internal server error'
        }), 500

@prediction_api.route('/batch_predict', methods=['POST'])
def batch_predict():
    """
    API endpoint for batch processing of multiple crisis reports.
    
    Expected JSON payload:
    {
        "reports": [
            {"report_id": "id1", "report": "crisis report text 1"},
            {"report_id": "id2", "report": "crisis report text 2"},
            ...
        ]
    }
    """
    try:
        # Parse request
        data = request.get_json()
        
        if not data or 'reports' not in data or not isinstance(data['reports'], list):
            return jsonify({
                'status': 'error',
                'message': 'Missing or invalid required field: reports'
            }), 400
        
        reports = data['reports']
        
        # Check if reports list is empty
        if not reports:
            return jsonify({
                'status': 'error',
                'message': 'Reports list cannot be empty'
            }), 400
        
        # Process each report
        results = []
        for report_data in reports:
            # Check required fields
            if 'report' not in report_data:
                continue
            
            report_text = report_data['report']
            report_id = report_data.get('report_id', str(datetime.now().timestamp()))
            
            # Make prediction
            resources = predict_resources(report_text)
            
            # Extract additional entities
            entities = extract_entities(report_text)
            
            # Calculate summary statistics
            num_resources = len([r for r in resources if r.get('required', False)])
            priority_level = "HIGH" if entities['severity'] == 'high' or num_resources >= 3 else \
                             "MEDIUM" if entities['severity'] == 'medium' or num_resources >= 1 else "LOW"
            
            # Add to results
            results.append({
                'report_id': report_id,
                'resources': resources,
                'entities': entities,
                'summary': {
                    'num_resources_needed': num_resources,
                    'priority_level': priority_level,
                    'severity': entities['severity']
                }
            })
        
        # Log batch processing
        logger.info(f"Batch processed {len(results)} reports")
        
        # Prepare response
        response = {
            'status': 'success',
            'results': results,
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error processing batch request: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Internal server error'
        }), 500

@prediction_api.route('/resources', methods=['GET'])
def get_resources():
    """
    API endpoint for retrieving available resource categories.
    """
    if label_encoder is None:
        return jsonify({
            'status': 'error',
            'message': 'Model not loaded'
        }), 503
    
    resources = [{'id': i, 'name': resource} for i, resource in enumerate(label_encoder)]
    
    return jsonify({
        'status': 'success',
        'resources': resources,
        'count': len(resources)
    })

@prediction_api.route('/debug', methods=['GET'])
def debug():
    """
    Debug endpoint for prediction API.
    Returns information about the loaded model.
    Only available in debug mode.
    """
    # Check if debug mode is enabled
    if not os.environ.get('FLASK_DEBUG', '').lower() == 'true':
        return jsonify({
            'status': 'error',
            'message': 'Debug endpoint only available in debug mode'
        }), 403
    
    debug_info = {
        'model_type': 'multi-label' if multilabel else 'single-label',
        'model_loaded': model is not None,
        'num_resource_categories': len(label_encoder) if label_encoder else 0,
        'resource_categories': label_encoder if label_encoder else []
    }
    
    return jsonify(debug_info)

def create_app(config_path='config/resource_model_config.json'):
    """
    Create and configure the Flask application.
    
    Args:
        config_path (str): Path to configuration file
        
    Returns:
        Flask: Configured Flask application
    """
    app = Flask(__name__)
    CORS(app)
    
    # Load model artifacts
    load_model_artifacts(config_path)
    
    # Register blueprint
    app.register_blueprint(prediction_api, url_prefix='/api/prediction')
    
    return app

if __name__ == '__main__':
    # This allows the module to be run directly
    app = create_app()
    port = int(os.environ.get('PORT', 5001))
    debug = os.environ.get('FLASK_DEBUG', '').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)