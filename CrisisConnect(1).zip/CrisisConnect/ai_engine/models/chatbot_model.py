"""
CrisisConnect Chatbot Model Creator

This script trains and saves the AI-driven chatbot model for crisis response.
The model is based on transformers and fine-tuned for crisis management conversations.
"""

import os
import pickle
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

# Ensure the output directory exists
os.makedirs('models', exist_ok=True)

# Define the path for the model
MODEL_PATH = 'models/chatbot_model.pkl'

# Sample crisis response intents and phrases (would be expanded in a real system)
crisis_data = [
    {"intent": "greeting", "text": "Hello", "response": "Hello, I'm the CrisisConnect assistant. How can I help you with emergency resources?"},
    {"intent": "greeting", "text": "Hi there", "response": "Hi there! I'm here to help you find emergency resources and support."},
    {"intent": "greeting", "text": "Hey", "response": "Hey there! I'm your CrisisConnect assistant. How can I assist you during this crisis?"},
    
    {"intent": "find_shelter", "text": "I need a place to stay", "response": "I'll help you find emergency shelter. What is your current location?"},
    {"intent": "find_shelter", "text": "Where can I find shelter", "response": "I can help locate emergency shelters near you. Could you share your location?"},
    {"intent": "find_shelter", "text": "Need shelter after earthquake", "response": "I understand you need shelter following an earthquake. What city or area are you in?"},
    
    {"intent": "medical_help", "text": "I need medical assistance", "response": "For medical emergencies, please call 911 immediately. Would you like me to locate the nearest hospital or medical center?"},
    {"intent": "medical_help", "text": "Where is the closest hospital", "response": "I can help find the nearest hospital. What is your current location?"},
    {"intent": "medical_help", "text": "Need doctor after flood", "response": "I understand you need medical help after flooding. Are you in a safe location now?"},
    
    {"intent": "food_assistance", "text": "Where can I get food", "response": "I can help you find emergency food resources. What is your current location?"},
    {"intent": "food_assistance", "text": "Need food after hurricane", "response": "I understand you need food assistance after a hurricane. What city or area are you in?"},
    {"intent": "food_assistance", "text": "Food banks near me", "response": "I'll help you locate food banks. Could you share your current location?"},
    
    {"intent": "evacuation", "text": "How do I evacuate", "response": "I can help with evacuation information. What type of crisis are you experiencing and what is your location?"},
    {"intent": "evacuation", "text": "Evacuation routes from wildfire", "response": "For wildfire evacuation routes, I need your specific location. Can you share your city or neighborhood?"},
    {"intent": "evacuation", "text": "Need to evacuate flood zone", "response": "I'll help you find evacuation routes from flood zones. What is your current location?"},
    
    {"intent": "safety_instructions", "text": "What should I do during earthquake", "response": "During an earthquake: Drop, Cover, and Hold On. Get under sturdy furniture, stay away from windows, and hold on until shaking stops."},
    {"intent": "safety_instructions", "text": "Hurricane safety tips", "response": "For hurricane safety: Stay indoors away from windows, listen to emergency broadcasts, and follow evacuation orders immediately if issued."},
    {"intent": "safety_instructions", "text": "How to stay safe in flood", "response": "During flooding: Move to higher ground, avoid walking or driving through flood waters, and stay away from downed power lines."},
    
    {"intent": "emergency_contacts", "text": "Who should I call for help", "response": "For immediate emergencies, call 911. Would you like other emergency contact information for your area?"},
    {"intent": "emergency_contacts", "text": "Emergency numbers", "response": "The main emergency number is 911. Would you like specific emergency contacts for your location?"},
    {"intent": "emergency_contacts", "text": "Contact rescue services", "response": "To contact rescue services, call 911. If you share your location, I can provide additional local emergency numbers."},
    
    {"intent": "report_crisis", "text": "I want to report a crisis", "response": "You can report a crisis through our system. What type of emergency are you reporting and what's your location?"},
    {"intent": "report_crisis", "text": "How to report emergency", "response": "To report an emergency through CrisisConnect, I'll need to know the type of emergency and your location."},
    {"intent": "report_crisis", "text": "Report power outage", "response": "I can help you report a power outage. Could you provide your location and how widespread the outage appears to be?"},
    
    {"intent": "utility_issues", "text": "Gas leak what to do", "response": "For a gas leak: Leave the area immediately, don't use electronics or flames, and once safe, call 911 and your gas company."},
    {"intent": "utility_issues", "text": "No water after earthquake", "response": "I understand you have no water after an earthquake. Are you in a safe location, and do you have any bottled water for immediate needs?"},
    {"intent": "utility_issues", "text": "Power lines down", "response": "For downed power lines: Stay at least 35 feet away, assume they're energized, call 911, and warn others to stay away."},
    
    {"intent": "weather_alerts", "text": "Current weather warnings", "response": "I can check current weather alerts for your area. What is your location?"},
    {"intent": "weather_alerts", "text": "Is there a storm coming", "response": "I can check storm forecasts for your area. Could you share your location?"},
    {"intent": "weather_alerts", "text": "Flash flood warning", "response": "Flash flood warnings are serious. Are you in a safe location away from low-lying areas and waterways?"},
    
    {"intent": "goodbye", "text": "Goodbye", "response": "Stay safe! Remember that CrisisConnect is here 24/7 if you need further assistance."},
    {"intent": "goodbye", "text": "Thanks for your help", "response": "You're welcome. Stay safe, and don't hesitate to return if you need more assistance."},
    {"intent": "goodbye", "text": "Bye", "response": "Take care and stay safe. CrisisConnect is here whenever you need help."}
]

# Create a DataFrame from the sample data
df = pd.DataFrame(crisis_data)

print(f"Training on {len(df)} sample phrases across {df['intent'].nunique()} intents")

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    df['text'], df['intent'], test_size=0.2, random_state=42
)

# Create a pipeline with TF-IDF vectorizer and RandomForest classifier
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(ngram_range=(1, 2), max_features=1000)),
    ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
])

# Train the model
print("Training the model...")
pipeline.fit(X_train, y_train)

# Evaluate the model
print("Evaluating the model...")
y_pred = pipeline.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.2f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Create response lookup dictionary
response_dict = {}
for intent in df['intent'].unique():
    intent_responses = df[df['intent'] == intent]['response'].tolist()
    response_dict[intent] = intent_responses

# Create the chatbot model dictionary with both pipeline and responses
chatbot_model = {
    'pipeline': pipeline,
    'responses': response_dict,
    'intents': df['intent'].unique().tolist(),
    'metadata': {
        'created_at': pd.Timestamp.now().isoformat(),
        'version': '1.0.0',
        'description': 'CrisisConnect AI Chatbot Model',
        'accuracy': accuracy,
        'sample_size': len(df)
    }
}

# Save the model to disk
print(f"Saving model to {MODEL_PATH}...")
with open(MODEL_PATH, 'wb') as f:
    pickle.dump(chatbot_model, f)

print("Model saved successfully!")
print(f"Model metadata: {chatbot_model['metadata']}")