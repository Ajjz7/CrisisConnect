#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
train_chatbot.py
---------------
AI chatbot training script for the CrisisConnect application.
This script trains a conversational AI model to handle crisis-related
queries and provide appropriate responses.
"""

import os
import json
import logging
import argparse
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout, LSTM, Embedding
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, TensorBoard
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import pickle
import random
import re
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("chatbot_training.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Download NLTK resources
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('stopwords')

class ChatbotTrainer:
    """
    Class to handle training of the CrisisConnect AI chatbot model.
    """
    
    def __init__(self, config_path='config/chatbot_config.json'):
        """
        Initialize the ChatbotTrainer with configuration.
        
        Args:
            config_path (str): Path to the configuration JSON file
        """
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        
        # Load configuration
        try:
            with open(config_path, 'r') as f:
                self.config = json.load(f)
                logger.info(f"Configuration loaded from {config_path}")
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            raise
        
        # Set configuration parameters
        self.intents_file = self.config.get('intents_file', 'data/intents.json')
        self.model_dir = self.config.get('model_dir', 'models')
        self.max_sequence_length = self.config.get('max_sequence_length', 20)
        self.embedding_dim = self.config.get('embedding_dim', 128)
        self.epochs = self.config.get('epochs', 200)
        self.batch_size = self.config.get('batch_size', 32)
        self.lstm_units = self.config.get('lstm_units', 128)
        self.dropout_rate = self.config.get('dropout_rate', 0.5)
        
        # Ensure model directory exists
        os.makedirs(self.model_dir, exist_ok=True)
        
        # Model checkpoint path
        self.model_name = f"crisis_chatbot_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.checkpoint_path = os.path.join(self.model_dir, f"{self.model_name}.h5")
        
        # Initialize tokenizer
        self.tokenizer = Tokenizer(oov_token="<OOV>")
        
        logger.info("ChatbotTrainer initialized")
    
    def load_data(self):
        """
        Load and preprocess the intents data.
        
        Returns:
            tuple: (words, classes, documents, intents)
        """
        # Load the intents file
        try:
            with open(self.intents_file, 'r') as f:
                intents = json.load(f)
            logger.info(f"Loaded intents from {self.intents_file}")
        except Exception as e:
            logger.error(f"Error loading intents file: {e}")
            raise
        
        words = []
        classes = []
        documents = []
        
        # Extract patterns and tags
        for intent in intents['intents']:
            for pattern in intent['patterns']:
                # Tokenize pattern
                word_list = nltk.word_tokenize(pattern.lower())
                words.extend(word_list)
                
                # Add document to corpus
                documents.append((word_list, intent['tag']))
                
                # Add to classes list
                if intent['tag'] not in classes:
                    classes.append(intent['tag'])
        
        # Lemmatize and filter words
        words = [self.lemmatizer.lemmatize(word) for word in words if word not in self.stop_words]
        words = sorted(list(set(words)))
        classes = sorted(list(set(classes)))
        
        logger.info(f"Extracted {len(words)} unique lemmatized words")
        logger.info(f"Extracted {len(classes)} unique intent classes")
        logger.info(f"Extracted {len(documents)} pattern-intent pairs")
        
        return words, classes, documents, intents
    
    def prepare_training_data(self, words, classes, documents):
        """
        Prepare training data for the model.
        
        Args:
            words (list): List of unique words
            classes (list): List of intent classes
            documents (list): List of (pattern, intent) pairs
            
        Returns:
            tuple: (X_train, y_train)
        """
        # Prepare training data
        training_data = []
        
        # Create an empty array for output
        output_empty = [0] * len(classes)
        
        # Create bag of words for each document
        for doc in documents:
            # Initialize bag of words
            bag = [0] * len(words)
            
            # List of tokenized words for the pattern
            pattern_words = doc[0]
            
            # Lemmatize pattern words
            pattern_words = [self.lemmatizer.lemmatize(word.lower()) for word in pattern_words]
            
            # Create bag of words array
            for i, word in enumerate(words):
                if word in pattern_words:
                    bag[i] = 1
            
            # Output is a '0' for each tag and '1' for current tag
            output_row = list(output_empty)
            output_row[classes.index(doc[1])] = 1
            
            training_data.append([bag, output_row])
        
        # Shuffle the training data
        random.shuffle(training_data)
        
        # Convert to numpy arrays
        X_train = np.array([item[0] for item in training_data])
        y_train = np.array([item[1] for item in training_data])
        
        logger.info(f"Prepared training data with shape: X {X_train.shape}, y {y_train.shape}")
        
        return X_train, y_train
    
    def prepare_sequence_data(self, documents, classes):
        """
        Prepare sequence data for the LSTM model.
        
        Args:
            documents (list): List of (pattern, intent) pairs
            classes (list): List of intent classes
            
        Returns:
            tuple: (X_train, y_train, tokenizer)
        """
        # Extract patterns and intents
        patterns = [' '.join(doc[0]) for doc in documents]
        intents = [doc[1] for doc in documents]
        
        # Fit tokenizer on patterns
        self.tokenizer.fit_on_texts(patterns)
        
        # Convert patterns to sequences
        sequences = self.tokenizer.texts_to_sequences(patterns)
        
        # Pad sequences
        X_train = pad_sequences(sequences, maxlen=self.max_sequence_length, padding='post')
        
        # Create one-hot encoded output
        y_train = np.zeros((len(intents), len(classes)))
        for i, intent in enumerate(intents):
            y_train[i, classes.index(intent)] = 1
        
        logger.info(f"Prepared sequence data with shape: X {X_train.shape}, y {y_train.shape}")
        
        return X_train, y_train
    
    def build_bow_model(self, input_shape, output_shape):
        """
        Build a simple bag-of-words neural network model.
        
        Args:
            input_shape (int): Size of input layer
            output_shape (int): Size of output layer
            
        Returns:
            tf.keras.Model: Compiled model
        """
        # Build model - 3 layers
        model = Sequential()
        model.add(Dense(128, input_shape=(input_shape,), activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(64, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(output_shape, activation='softmax'))
        
        # Compile model
        model.compile(
            loss='categorical_crossentropy',
            optimizer=tf.keras.optimizers.Adam(1e-4),
            metrics=['accuracy']
        )
        
        logger.info("Built bag-of-words model")
        model.summary(print_fn=logger.info)
        
        return model
    
    def build_lstm_model(self, vocab_size, output_shape):
        """
        Build an LSTM model for sequence data.
        
        Args:
            vocab_size (int): Size of vocabulary
            output_shape (int): Size of output layer
            
        Returns:
            tf.keras.Model: Compiled model
        """
        model = Sequential()
        
        # Embedding layer
        model.add(Embedding(
            input_dim=vocab_size + 1,  # +1 for OOV token
            output_dim=self.embedding_dim,
            input_length=self.max_sequence_length
        ))
        
        # LSTM layer
        model.add(LSTM(self.lstm_units, return_sequences=True))
        model.add(Dropout(self.dropout_rate))
        
        # Second LSTM layer
        model.add(LSTM(self.lstm_units))
        model.add(Dropout(self.dropout_rate))
        
        # Dense layers
        model.add(Dense(64, activation='relu'))
        model.add(Dropout(self.dropout_rate))
        model.add(Dense(output_shape, activation='softmax'))
        
        # Compile model
        model.compile(
            loss='categorical_crossentropy',
            optimizer=tf.keras.optimizers.Adam(1e-4),
            metrics=['accuracy']
        )
        
        logger.info("Built LSTM model")
        model.summary(print_fn=logger.info)
        
        return model
    
    def train_model(self, X_train, y_train, model):
        """
        Train the model with the prepared data.
        
        Args:
            X_train (np.array): Training features
            y_train (np.array): Training labels
            model (tf.keras.Model): Model to train
            
        Returns:
            tf.keras.Model: Trained model
        """
        # Define callbacks
        callbacks = [
            ModelCheckpoint(
                filepath=self.checkpoint_path,
                monitor='val_accuracy',
                verbose=1,
                save_best_only=True,
                mode='max'
            ),
            EarlyStopping(
                monitor='val_accuracy',
                patience=10,
                mode='max',
                verbose=1
            ),
            TensorBoard(
                log_dir=os.path.join(self.model_dir, 'logs', self.model_name),
                histogram_freq=1
            )
        ]
        
        # Train the model
        logger.info(f"Starting model training for {self.epochs} epochs")
        history = model.fit(
            X_train, y_train,
            epochs=self.epochs,
            batch_size=self.batch_size,
            validation_split=0.2,
            callbacks=callbacks,
            verbose=1
        )
        
        # Load the best model
        model = load_model(self.checkpoint_path)
        logger.info(f"Model training completed, best model loaded from {self.checkpoint_path}")
        
        return model, history
    
    def save_model_artifacts(self, words, classes, model_type='lstm'):
        """
        Save model artifacts for later use.
        
        Args:
            words (list): List of unique words
            classes (list): List of intent classes
            model_type (str): Type of model ('bow' or 'lstm')
        """
        # Save words and classes
        with open(os.path.join(self.model_dir, f"{self.model_name}_words.pkl"), 'wb') as f:
            pickle.dump(words, f)
        
        with open(os.path.join(self.model_dir, f"{self.model_name}_classes.pkl"), 'wb') as f:
            pickle.dump(classes, f)
        
        # Save tokenizer if using LSTM model
        if model_type == 'lstm':
            with open(os.path.join(self.model_dir, f"{self.model_name}_tokenizer.pkl"), 'wb') as f:
                pickle.dump(self.tokenizer, f)
        
        logger.info(f"Model artifacts saved to {self.model_dir}")
    
    def train(self, model_type='lstm'):
        """
        Execute the complete training process.
        
        Args:
            model_type (str): Type of model to train ('bow' or 'lstm')
            
        Returns:
            tuple: (model, words, classes, history)
        """
        # Load and prepare data
        words, classes, documents, intents = self.load_data()
        
        if model_type == 'bow':
            # Bag of words approach
            X_train, y_train = self.prepare_training_data(words, classes, documents)
            model = self.build_bow_model(len(words), len(classes))
        elif model_type == 'lstm':
            # LSTM approach
            X_train, y_train = self.prepare_sequence_data(documents, classes)
            vocab_size = len(self.tokenizer.word_index)
            model = self.build_lstm_model(vocab_size, len(classes))
        else:
            raise ValueError(f"Unknown model type: {model_type}")
        
        # Train model
        model, history = self.train_model(X_train, y_train, model)
        
        # Save model artifacts
        self.save_model_artifacts(words, classes, model_type)
        
        return model, words, classes, history

def main():
    """
    Main function to train the chatbot model.
    """
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Train CrisisConnect AI chatbot')
    parser.add_argument('--config', type=str, default='config/chatbot_config.json',
                        help='Path to configuration file')
    parser.add_argument('--model-type', type=str, choices=['bow', 'lstm'], default='lstm',
                        help='Type of model to train')
    args = parser.parse_args()
    
    # Initialize trainer
    trainer = ChatbotTrainer(config_path=args.config)
    
    # Train model
    logger.info(f"Starting training with model type: {args.model_type}")
    model, words, classes, history = trainer.train(model_type=args.model_type)
    logger.info("Training completed successfully")

if __name__ == "__main__":
    main()