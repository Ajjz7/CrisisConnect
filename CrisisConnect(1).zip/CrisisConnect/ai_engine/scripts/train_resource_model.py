#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
train_resource_model.py
----------------------
Crisis resource ML training script for the CrisisConnect application.
This script trains a machine learning model to classify crisis reports
and predict required resources based on text descriptions.
"""

import os
import json
import logging
import argparse
import numpy as np
import pandas as pd
from datetime import datetime
import pickle
import matplotlib.pyplot as plt
import seaborn as sns

# ML libraries
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.pipeline import Pipeline
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

# NLP libraries
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import re

# Download NLTK resources
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("resource_model_training.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ResourceModelTrainer:
    """
    Class to handle training of the CrisisConnect resource classification model.
    """
    
    def __init__(self, config_path='config/resource_model_config.json'):
        """
        Initialize the ResourceModelTrainer with configuration.
        
        Args:
            config_path (str): Path to the configuration JSON file
        """
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        
        # Load configuration
        try:
            with open(config_path, 'r') as f:
                self.config = json.load(f)
                logger.info(f"Configuration loaded from {config_path}")
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            raise
        
        # Set configuration parameters
        self.data_path = self.config.get('data_path', 'data/crisis_reports.csv')
        self.model_dir = self.config.get('model_dir', 'models')
        self.model_type = self.config.get('model_type', 'svm')
        self.test_size = self.config.get('test_size', 0.2)
        self.random_state = self.config.get('random_state', 42)
        self.use_grid_search = self.config.get('use_grid_search', True)
        self.n_jobs = self.config.get('n_jobs', -1)
        self.vectorizer_type = self.config.get('vectorizer_type', 'tfidf')
        self.multilabel = self.config.get('multilabel', True)
        
        # Ensure model directory exists
        os.makedirs(self.model_dir, exist_ok=True)
        
        # Model path
        self.model_name = f"resource_classifier_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.model_path = os.path.join(self.model_dir, f"{self.model_name}.pkl")
        
        logger.info("ResourceModelTrainer initialized")
    
    def load_data(self):
        """
        Load and preprocess the training data.
        
        Returns:
            pandas.DataFrame: Preprocessed data
        """
        # Load the data
        try:
            df = pd.read_csv(self.data_path)
            logger.info(f"Loaded data from {self.data_path} with {len(df)} rows")
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            raise
        
        # Check required columns
        required_columns = ['report_text', 'resource_category']
        for col in required_columns:
            if col not in df.columns:
                logger.error(f"Required column '{col}' not found in data")
                raise ValueError(f"Required column '{col}' not found in data")
        
        # Handle missing values
        df = df.dropna(subset=['report_text', 'resource_category'])
        logger.info(f"Data after dropping NAs: {len(df)} rows")
        
        return df
    
    def preprocess_text(self, text):
        """
        Preprocess text data for model training.
        
        Args:
            text (str): Text to preprocess
            
        Returns:
            str: Preprocessed text
        """
        if not isinstance(text, str):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters and numbers
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords
        tokens = [word for word in tokens if word not in self.stop_words]
        
        # Lemmatize
        tokens = [self.lemmatizer.lemmatize(word) for word in tokens]
        
        # Rejoin tokens
        return ' '.join(tokens)
    
    def prepare_data(self, df):
        """
        Prepare the data for training.
        
        Args:
            df (pandas.DataFrame): Raw data
            
        Returns:
            tuple: (X_train, X_test, y_train, y_test, label_encoder)
        """
        # Preprocess text
        df['processed_text'] = df['report_text'].apply(self.preprocess_text)
        
        # Handle multi-label vs. single-label classification
        if self.multilabel:
            # Create multi-label encoding
            # Assuming resource_category might contain multiple categories separated by delimiter
            delimiters = [',', ';', '|']
            for delimiter in delimiters:
                if df['resource_category'].str.contains(delimiter).any():
                    df['resource_categories'] = df['resource_category'].str.split(delimiter)
                    break
            else:
                # If no delimiter found, assume single category per row
                df['resource_categories'] = df['resource_category'].apply(lambda x: [x])
            
            # Get unique categories
            all_categories = set()
            for categories in df['resource_categories']:
                all_categories.update([c.strip() for c in categories])
            all_categories = sorted(list(all_categories))
            
            # Create one-hot encoding
            for category in all_categories:
                df[category] = df['resource_categories'].apply(
                    lambda cats: 1 if category in [c.strip() for c in cats] else 0
                )
            
            # Features and target
            X = df['processed_text']
            y = df[all_categories]
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=self.test_size, random_state=self.random_state
            )
            
            label_encoder = all_categories
            
        else:
            # Single label classification
            # Features and target
            X = df['processed_text']
            y = df['resource_category']
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=self.test_size, random_state=self.random_state,
                stratify=y
            )
            
            # Get unique categories
            label_encoder = sorted(y.unique())
        
        logger.info(f"Data split: {len(X_train)} training samples, {len(X_test)} test samples")
        logger.info(f"Number of resource categories: {len(label_encoder)}")
        logger.info(f"Categories: {label_encoder}")
        
        return X_train, X_test, y_train, y_test, label_encoder
    
    def build_pipeline(self):
        """
        Build the ML pipeline based on configuration.
        
        Returns:
            sklearn.pipeline.Pipeline: ML pipeline
        """
        # Choose vectorizer
        if self.vectorizer_type == 'tfidf':
            vectorizer = TfidfVectorizer(
                max_features=10000,
                ngram_range=(1, 2),
                min_df=2
            )
        else:
            vectorizer = CountVectorizer(
                max_features=10000,
                ngram_range=(1, 2),
                min_df=2
            )
        
        # Choose classifier
        if self.model_type == 'svm':
            base_classifier = LinearSVC(C=1.0, class_weight='balanced')
        elif self.model_type == 'rf':
            base_classifier = RandomForestClassifier(
                n_estimators=100,
                class_weight='balanced'
            )
        elif self.model_type == 'lr':
            base_classifier = LogisticRegression(
                C=1.0,
                class_weight='balanced',
                max_iter=1000
            )
        else:
            logger.error(f"Unknown model type: {self.model_type}")
            raise ValueError(f"Unknown model type: {self.model_type}")
        
        # Build pipeline
        if self.multilabel:
            classifier = OneVsRestClassifier(base_classifier)
        else:
            classifier = base_classifier
        
        pipeline = Pipeline([
            ('vectorizer', vectorizer),
            ('classifier', classifier)
        ])
        
        logger.info(f"Built pipeline with {self.vectorizer_type} vectorizer and {self.model_type} classifier")
        
        return pipeline
    
    def grid_search(self, pipeline, X_train, y_train):
        """
        Perform grid search for hyperparameter tuning.
        
        Args:
            pipeline (sklearn.pipeline.Pipeline): ML pipeline
            X_train (pandas.Series): Training features
            y_train (pandas.DataFrame/Series): Training labels
            
        Returns:
            sklearn.model_selection.GridSearchCV: Grid search object
        """
        # Define parameter grid based on model type
        if self.model_type == 'svm':
            param_grid = {
                'vectorizer__max_features': [5000, 10000],
                'vectorizer__ngram_range': [(1, 1), (1, 2)],
                'classifier__estimator__C': [0.1, 1.0, 10.0] if self.multilabel else ['classifier__C', [0.1, 1.0, 10.0]]
            }
        elif self.model_type == 'rf':
            param_grid = {
                'vectorizer__max_features': [5000, 10000],
                'vectorizer__ngram_range': [(1, 1), (1, 2)],
                'classifier__estimator__n_estimators': [50, 100, 200] if self.multilabel else ['classifier__n_estimators', [50, 100, 200]]
            }
        else:  # Logistic Regression
            param_grid = {
                'vectorizer__max_features': [5000, 10000],
                'vectorizer__ngram_range': [(1, 1), (1, 2)],
                'classifier__estimator__C': [0.1, 1.0, 10.0] if self.multilabel else ['classifier__C', [0.1, 1.0, 10.0]]
            }
        
        # Define scoring metric based on multi-label vs. single-label
        scoring = 'f1_weighted' if not self.multilabel else 'f1_micro'
        
        # Initialize GridSearchCV
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=self.random_state) if not self.multilabel else 5
        
        grid_search = GridSearchCV(
            pipeline,
            param_grid=param_grid,
            cv=cv,
            scoring=scoring,
            n_jobs=self.n_jobs,
            verbose=1
        )
        
        # Fit grid search
        logger.info("Starting grid search...")
        grid_search.fit(X_train, y_train)
        
        # Log best parameters
        logger.info(f"Best parameters: {grid_search.best_params_}")
        logger.info(f"Best score: {grid_search.best_score_:.4f}")
        
        return grid_search
    
    def evaluate_model(self, model, X_test, y_test, label_encoder):
        """
        Evaluate the trained model.
        
        Args:
            model: Trained model
            X_test (pandas.Series): Test features
            y_test (pandas.DataFrame/Series): Test labels
            label_encoder (list): Label categories
            
        Returns:
            dict: Evaluation metrics
        """
        # Make predictions
        y_pred = model.predict(X_test)
        
        # Compute metrics
        if self.multilabel:
            # Multi-label classification metrics
            report = classification_report(
                y_test, y_pred, target_names=label_encoder, output_dict=True
            )
            accuracy = (y_pred == y_test).mean().mean()
            f1_micro = f1_score(y_test, y_pred, average='micro')
            f1_macro = f1_score(y_test, y_pred, average='macro')
            
            metrics = {
                'accuracy': accuracy,
                'f1_micro': f1_micro,
                'f1_macro': f1_macro,
                'report': report
            }
            
            # Log metrics
            logger.info(f"Accuracy: {accuracy:.4f}")
            logger.info(f"F1 (micro): {f1_micro:.4f}")
            logger.info(f"F1 (macro): {f1_macro:.4f}")
            logger.info(f"Classification Report:\n{classification_report(y_test, y_pred, target_names=label_encoder)}")
            
        else:
            # Single-label classification metrics
            report = classification_report(
                y_test, y_pred, target_names=label_encoder, output_dict=True
            )
            accuracy = accuracy_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred, average='weighted')
            
            # Compute confusion matrix
            cm = confusion_matrix(y_test, y_pred)
            
            metrics = {
                'accuracy': accuracy,
                'f1': f1,
                'report': report,
                'confusion_matrix': cm
            }
            
            # Log metrics
            logger.info(f"Accuracy: {accuracy:.4f}")
            logger.info(f"F1 (weighted): {f1:.4f}")
            logger.info(f"Classification Report:\n{classification_report(y_test, y_pred, target_names=label_encoder)}")
            
            # Plot confusion matrix
            plt.figure(figsize=(10, 8))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=label_encoder, yticklabels=label_encoder)
            plt.title('Confusion Matrix')
            plt.ylabel('True Label')
            plt.xlabel('Predicted Label')
            plt.tight_layout()
            plt.savefig(os.path.join(self.model_dir, f"{self.model_name}_confusion_matrix.png"))
            plt.close()
        
        return metrics
    
    def save_model(self, model, label_encoder):
        """
        Save the trained model and related artifacts.
        
        Args:
            model: Trained model
            label_encoder (list): Label categories
        """
        # Create model data dictionary
        model_data = {
            'model': model,
            'label_encoder': label_encoder,
            'multilabel': self.multilabel,
            'config': self.config,
            'metadata': {
                'creation_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'model_type': self.model_type,
                'vectorizer_type': self.vectorizer_type
            }
        }
        
        # Save model
        with open(self.model_path, 'wb') as f:
            pickle.dump(model_data, f)
        
        logger.info(f"Model saved to {self.model_path}")
    
    def train(self):
        """
        Execute the complete training process.
        
        Returns:
            tuple: (model, label_encoder, metrics)
        """
        # Load data
        df = self.load_data()
        
        # Prepare data
        X_train, X_test, y_train, y_test, label_encoder = self.prepare_data(df)
        
        # Build pipeline
        pipeline = self.build_pipeline()
        
        # Train model (with or without grid search)
        if self.use_grid_search:
            grid = self.grid_search(pipeline, X_train, y_train)
            model = grid.best_estimator_
        else:
            logger.info("Training model...")
            model = pipeline.fit(X_train, y_train)
        
        # Evaluate model
        metrics = self.evaluate_model(model, X_test, y_test, label_encoder)
        
        # Save model
        self.save_model(model, label_encoder)
        
        return model, label_encoder, metrics

def main():
    """
    Main function to train the resource classification model.
    """
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Train CrisisConnect resource classification model')
    parser.add_argument('--config', type=str, default='config/resource_model_config.json',
                        help='Path to configuration file')
    parser.add_argument('--data', type=str, help='Path to training data CSV file')
    parser.add_argument('--model-type', type=str, choices=['svm', 'rf', 'lr'], 
                        help='Type of model to train')
    parser.add_argument('--vectorizer', type=str, choices=['tfidf', 'count'],
                        help='Type of vectorizer to use')
    parser.add_argument('--no-grid-search', action='store_true',
                        help='Disable grid search for hyperparameter tuning')
    parser.add_argument('--single-label', action='store_true',
                        help='Treat as single-label classification problem')
    args = parser.parse_args()
    
    # Initialize trainer
    trainer = ResourceModelTrainer(config_path=args.config)
    
    # Override configuration with command line arguments
    if args.data:
        trainer.data_path = args.data
    if args.model_type:
        trainer.model_type = args.model_type
    if args.vectorizer:
        trainer.vectorizer_type = args.vectorizer
    if args.no_grid_search:
        trainer.use_grid_search = False
    if args.single_label:
        trainer.multilabel = False
    
    # Train model
    logger.info(f"Starting training with model type: {trainer.model_type}")
    model, label_encoder, metrics = trainer.train()
    logger.info("Training completed successfully")
    
    # Log final metrics
    if trainer.multilabel:
        logger.info(f"Final metrics - Accuracy: {metrics['accuracy']:.4f}, F1 (micro): {metrics['f1_micro']:.4f}")
    else:
        logger.info(f"Final metrics - Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1']:.4f}")

if __name__ == "__main__":
    main()