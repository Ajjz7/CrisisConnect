# CrisisConnect

## AI-Powered Crisis Response & Resource Coordination Platform

CrisisConnect is an intelligent platform designed to connect crisis-affected communities with critical resources during emergencies. The system leverages artificial intelligence to analyze crisis reports, predict resource needs, and facilitate efficient coordination between those who need help and those who can provide it.

![CrisisConnect Banner](./images/crisisconnect_banner.png)

## 🚨 Key Features

- **AI Crisis Analysis**: Automatically analyze crisis reports to identify resource needs
- **Real-time Resource Matching**: Connect resources with affected communities in real-time
- **Interactive AI Chatbot**: Provide crisis support and information through an AI assistant
- **Geospatial Visualization**: Map-based interface for resource tracking and coordination
- **Multi-channel Reporting**: Submit crisis reports via web, mobile, SMS, or voice
- **Volunteer Management**: Coordinate volunteer activities and resource distribution
- **Analytics Dashboard**: Track response effectiveness and resource allocation

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Node.js 16+
- MongoDB
- Redis (for caching and queues)

### Installation

1. **Clone the repository**

```bash
git clone https://github.com/your-organization/crisisconnect.git
cd crisisconnect
```

2. **Set up the Python environment**

```bash
python -m venv venv
source venv/bin/activate  # On Windows use: venv\Scripts\activate
pip install -r requirements.txt
```

3. **Set up the frontend**

```bash
cd frontend
npm install
```

4. **Configure environment variables**

Create a `.env` file in the project root with the following variables:

```
# Core Configuration
FLASK_APP=app.py
FLASK_ENV=development
SECRET_KEY=your_secret_key_here

# Database Configuration
MONGODB_URI=mongodb://localhost:27017/crisisconnect

# AI Model Paths
CHATBOT_MODEL_PATH=models/crisis_chatbot_latest.h5
RESOURCE_MODEL_PATH=models/resource_classifier_latest.pkl

# External Services
MAPBOX_API_KEY=your_mapbox_api_key
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
```

5. **Initialize the database**

```bash
python scripts/init_db.py
```

6. **Train the AI models** (optional, pre-trained models included)

```bash
python scripts/train_chatbot.py
python scripts/train_resource_model.py
```

### Running the Application

1. **Start the backend server**

```bash
flask run
```

2. **Start the frontend development server**

```bash
cd frontend
npm start
```

3. **Access the application**

Open your browser and navigate to:
- Web Application: http://localhost:3000
- API Documentation: http://localhost:5000/api/docs

## 🧪 Testing

Run the test suite:

```bash
pytest
```

For frontend tests:

```bash
cd frontend
npm test
```

## 📱 Mobile Application

The CrisisConnect mobile app is available for both iOS and Android:

- 📱 iOS: [App Store Link]
- 🤖 Android: [Google Play Link]

## 🔄 Deployment

For production deployment, we recommend using Docker containers:

```bash
docker-compose up -d
```

See our [Deployment Guide](./docs/DEPLOYMENT.md) for more details.

## 🌐 API Access

CrisisConnect provides a RESTful API for integration with other systems. See [API_DOCS.md](./API_DOCS.md) for comprehensive documentation.

## 🧩 System Architecture

For details on the system architecture, see [ARCHITECTURE.md](./ARCHITECTURE.md).

## 🛠️ Tech Stack

A comprehensive list of technologies used in CrisisConnect can be found in [TECH_STACK.md](./TECH_STACK.md).

## 👥 Contributing

We welcome contributions! Please see our [Contributing Guidelines](./CONTRIBUTING.md) for details.

## 📄 License

CrisisConnect is licensed under the [MIT License](./LICENSE).

## 🙏 Acknowledgements

This project is made possible by contributions from the open-source community and support from our partners:

- [Partner Organization 1]
- [Partner Organization 2]
- [Open Source Project 1]
- [Open Source Project 2]

## 📞 Contact

For more information, contact us at:

- Email: support@crisisconnect.org
- Twitter: [@CrisisConnect](https://twitter.com/CrisisConnect)
- Website: [www.crisisconnect.org](https://www.crisisconnect.org)