# CrisisConnect API Documentation

This document provides comprehensive documentation for the CrisisConnect API, which allows developers to integrate with our crisis response platform.

## API Overview

The CrisisConnect API is a RESTful API that allows developers to:

- Submit and retrieve crisis reports
- Access AI-powered resource predictions
- Interact with the crisis response chatbot
- Manage resources and volunteer coordination
- Access crisis data and analytics

## Base URL

All API requests should be sent to:

```
https://api.crisisconnect.org/v1
```

For development and testing, use:

```
http://localhost:5000/api
```

## Authentication

API requests require authentication using an API key. Include your API key in the request header:

```
Authorization: Bearer YOUR_API_KEY
```

To obtain an API key, register an account on the [CrisisConnect Developer Portal](https://developers.crisisconnect.org).

## Rate Limiting

API requests are limited to:
- 100 requests per minute for standard accounts
- 1000 requests per minute for partner accounts

## API Endpoints

### Crisis Reports

#### Submit a Crisis Report

```
POST /reports
```

**Parameters**

| Name | Type | Description |
|------|------|-------------|
| `text` | string | **Required**. Description of the crisis situation |
| `location` | object | **Required**. Geographic location of the crisis |
| `reporter_id` | string | ID of the person reporting (if authenticated) |
| `contacts` | array | Contact information for follow-up |
| `media` | array | URLs or base64 encoded images/videos |
| `metadata` | object | Additional information about the crisis |

**Example Request**

```json
{
  "text": "Flooding in downtown area. 20 families displaced. Need drinking water and temporary shelter.",
  "location": {
    "latitude": 34.0522,
    "longitude": -118.2437,
    "address": "Los Angeles, CA",
    "radius": 2.5
  },
  "contacts": [
    {
      "type": "phone",
      "value": "+1234567890"
    }
  ],
  "metadata": {
    "disaster_type": "flood",
    "severity": "moderate"
  }
}
```

**Example Response**

```json
{
  "status": "success",
  "report_id": "rep_12345",
  "created_at": "2023-10-15T14:22:31Z",
  "predicted_resources": [
    {
      "resource": "drinking_water",
      "confidence": 0.94,
      "required": true
    },
    {
      "resource": "temporary_shelter",
      "confidence": 0.89,
      "required": true
    },
    {
      "resource": "medical_aid",
      "confidence": 0.32,
      "required": false
    }
  ],
  "status": "pending_verification",
  "priority_level": "high"
}
```

#### Get Crisis Reports

```
GET /reports
```

**Parameters**

| Name | Type | Description |
|------|------|-------------|
| `status` | string | Filter by status (pending, verified, resolved) |
| `location` | object | Filter by geographic area |
| `resource_needs` | array | Filter by predicted resource needs |
| `start_date` | string | Filter by date range start (ISO format) |
| `end_date` | string | Filter by date range end (ISO format) |
| `limit` | integer | Number of results to return (default: 20, max: 100) |
| `offset` | integer | Pagination offset |

**Example Response**

```json
{
  "status": "success",
  "count": 2,
  "total": 243,
  "reports": [
    {
      "report_id": "rep_12345",
      "text": "Flooding in downtown area. 20 families displaced. Need drinking water and temporary shelter.",
      "created_at": "2023-10-15T14:22:31Z",
      "location": {
        "latitude": 34.0522,
        "longitude": -118.2437,
        "address": "Los Angeles, CA"
      },
      "status": "verified",
      "predicted_resources": [
        {
          "resource": "drinking_water",
          "required": true
        },
        {
          "resource": "temporary_shelter",
          "required": true
        }
      ],
      "priority_level": "high"
    },
    {
      "report_id": "rep_12346",
      "text": "Tree down on Main St blocking road. Power lines affected.",
      "created_at": "2023-10-15T15:10:22Z",
      "location": {
        "latitude": 34.0548,
        "longitude": -118.2500,
        "address": "Main St, Los Angeles, CA"
      },
      "status": "pending_verification",
      "predicted_resources": [
        {
          "resource": "debris_removal",
          "required": true
        },
        {
          "resource": "electrical_repair",
          "required": true
        }
      ],
      "priority_level": "medium"
    }
  ]
}
```

### AI Prediction

#### Predict Resources

```
POST /prediction/predict
```

**Parameters**

| Name | Type | Description |
|------|------|-------------|
| `report` | string | **Required**. Crisis report text to analyze |
| `report_id` | string | Unique identifier for the report |
| `metadata` | object | Additional context information |

**Example Request**

```json
{
  "report": "Earthquake damaged multiple buildings in the north area. At least 15 people injured and 50 displaced. Urgent need for medical assistance, shelter, and food.",
  "report_id": "user_report_5678",
  "metadata": {
    "source": "emergency_services",
    "location": "North County"
  }
}
```

**Example Response**

```json
{
  "status": "success",
  "report_id": "user_report_5678",
  "resources": [
    {
      "resource": "medical_aid",
      "required": true,
      "confidence": 0.96
    },
    {
      "resource": "temporary_shelter",
      "required": true,
      "confidence": 0.93
    },
    {
      "resource": "food",
      "required": true,
      "confidence": 0.88
    },
    {
      "resource": "search_rescue",
      "required": false,
      "confidence": 0.45
    }
  ],
  "entities": {
    "locations": ["north area"],
    "quantities": ["15 people", "50 displaced"],
    "severity": "high"
  },
  "summary": {
    "num_resources_needed": 3,
    "priority_level": "HIGH",
    "severity": "high"
  },
  "timestamp": "2023-10-15T16:32:10Z"
}
```

#### Batch Predict Resources

```
POST /prediction/batch_predict
```

**Parameters**

| Name | Type | Description |
|------|------|-------------|
| `reports` | array | **Required**. Array of report objects to analyze |

**Example Request**

```json
{
  "reports": [
    {
      "report_id": "batch_1",
      "report": "Flooding on Oak Street. Water level rising. Need evacuation assistance."
    },
    {
      "report_id": "batch_2",
      "report": "Power outage affecting south side hospital. Backup generators running low."
    }
  ]
}
```

**Example Response**

```json
{
  "status": "success",
  "results": [
    {
      "report_id": "batch_1",
      "resources": [
        {
          "resource": "evacuation_assistance",
          "required": true,
          "confidence": 0.92
        },
        {
          "resource": "water_pumps",
          "required": true,
          "confidence": 0.85
        }
      ],
      "entities": {
        "locations": ["Oak Street"],
        "severity": "medium"
      },
      "summary": {
        "num_resources_needed": 2,
        "priority_level": "MEDIUM",
        "severity": "medium"
      }
    },
    {
      "report_id": "batch_2",
      "resources": [
        {
          "resource": "generators",
          "required": true,
          "confidence": 0.97
        },
        {
          "resource": "fuel",
          "required": true,
          "confidence": 0.88
        }
      ],
      "entities": {
        "locations": ["south side"],
        "severity": "high"
      },
      "summary": {
        "num_resources_needed": 2,
        "priority_level": "HIGH",
        "severity": "high"
      }
    }
  ],
  "timestamp": "2023-10-15T16:35:22Z"
}
```

### Chatbot

#### Chat Interaction

```
POST /chatbot/predict
```

**Parameters**

| Name | Type | Description |
|------|------|-------------|
| `message` | string | **Required**. User message text |
| `session_id` | string | Unique session identifier for conversation tracking |
| `context` | object | Contextual information about the conversation |

**Example Request**

```json
{
  "message": "Where can I find shelter after the flood?",
  "session_id": "user_session_1234",
  "context": {
    "location": "Riverside County",
    "disaster_type": "flood"
  }
}
```

**Example Response**

```json
{
  "status": "success",
  "message": "There are currently 3 emergency shelters available in Riverside County: Riverside High School (20 Main St), Community Center (155 Oak Ave), and Memorial Church (78 River Rd). Would you like directions to the nearest one?",
  "intents": [
    {
      "intent": "shelter_information",
      "probability": 0.92
    },
    {
      "intent": "location_specific_help",
      "probability": 0.65
    }
  ],
  "metadata": {
    "shelter_count": 3,
    "nearest_shelter": "Riverside High School",
    "follow_up_intent": "directions"
  },
  "timestamp": "2023-10-15T16:40:12Z"
}
```

### Resources

#### Get Available Resources

```
GET /resources
```

**Parameters**

| Name | Type | Description |
|------|------|-------------|
| `type` | string | Filter by resource type |
| `location` | object | Filter by geographic availability |
| `status` | string | Filter by status (available, deployed, reserved) |

**Example Response**

```json
{
  "status": "success",
  "resources": [
    {
      "id": 1,
      "name": "drinking_water",
      "display_name": "Drinking Water",
      "category": "essential_supplies",
      "description": "Clean, potable water for drinking and basic needs"
    },
    {
      "id": 2,
      "name": "temporary_shelter",
      "display_name": "Temporary Shelter",
      "category": "housing",
      "description": "Emergency shelter for displaced individuals"
    }
  ],
  "count": 2
}
```

### Analytics

#### Get Crisis Analytics

```
GET /analytics
```

**Parameters**

| Name | Type | Description |
|------|------|-------------|
| `start_date` | string | Filter by date range start (ISO format) |
| `end_date` | string | Filter by date range end (ISO format) |
| `location` | object | Filter by geographic area |
| `disaster_type` | string | Filter by type of disaster |
| `resource_type` | string | Filter by resource type |

**Example Response**

```json
{
  "status": "success",
  "time_period": {
    "start": "2023-09-01T00:00:00Z",
    "end": "2023-10-15T23:59:59Z"
  },
  "report_stats": {
    "total_reports": 1243,
    "verified_reports": 985,
    "avg_response_time_hours": 3.2
  },
  "resource_needs": [
    {
      "resource": "drinking_water",
      "count": 423,
      "percent_of_total": 34.0,
      "fulfilled_percent": 92.0
    },
    {
      "resource": "temporary_shelter",
      "count": 386,
      "percent_of_total": 31.1,
      "fulfilled_percent": 87.3
    }
  ],
  "geographic_distribution": {
    "type": "FeatureCollection",
    "features": [
      {
        "type": "Feature",
        "properties": {
          "region": "North County",
          "report_count": 325,
          "most_needed_resource": "temporary_shelter"
        },
        "geometry": {
          "type": "Polygon",
          "coordinates": [[[...coordinates...]]]
        }
      }
    ]
  }
}
```

## Error Handling

The API uses standard HTTP status codes and returns error details in the response body:

**Example Error Response**

```json
{
  "status": "error",
  "code": "invalid_request",
  "message": "Missing required field: text",
  "details": {
    "field": "text",
    "error": "This field is required"
  }
}
```

### Common Error Codes

| Status Code | Error Code | Description |
|-------------|------------|-------------|
| 400 | invalid_request | The request was malformed or missing required fields |
| 401 | unauthorized | Authentication is required or failed |
| 403 | forbidden | The API key does not have permission for this action |
| 404 | not_found | The requested resource was not found |
| 429 | rate_limit_exceeded | The API rate limit has been exceeded |
| 500 | server_error | An internal server error occurred |

## Webhooks

CrisisConnect supports webhooks to notify your system of events in real-time:

### Available Webhook Events

- `report.created` - A new crisis report has been submitted
- `report.verified` - A crisis report has been verified
- `report.updated` - A crisis report has been updated
- `resource.matched` - A resource has been matched to a need
- `resource.deployed` - A resource has been deployed

### Webhook Configuration

Configure webhooks in the [Developer Portal](https://developers.crisisconnect.org/webhooks).

## SDKs and Client Libraries

We provide official client libraries for easy integration:

- [Python SDK](https://github.com/crisisconnect/python-sdk)
- [JavaScript SDK](https://github.com/crisisconnect/js-sdk)
- [Java SDK](https://github.com/crisisconnect/java-sdk)

## Additional Resources

- [API Changelog](https://developers.crisisconnect.org/changelog)
- [API Status](https://status.crisisconnect.org)
- [Developer Forum](https://community.crisisconnect.org/developers)

## Support

For API support, contact our developer team:

- Email: api-support@crisisconnect.org
- Developer Forum: [community.crisisconnect.org/developers](https://community.crisisconnect.org/developers)