/**
 * CrisisConnect - Production-Ready Main Entry Point
 * 
 * This file serves as the central entry point for the CrisisConnect emergency response platform,
 * with comprehensive security measures, accessibility features, and responsive design support.
 * It initializes all core functionalities and ensures proper integration between components.
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { ErrorBoundary } from 'react-error-boundary';

// Core application components
import App from './src/App';
import ErrorFallback from './src/components/ErrorFallback';
import LoadingScreen from './src/components/LoadingScreen';

// Context providers
import { AuthProvider } from './src/context/AuthContext';
import { CrisisProvider } from './src/context/CrisisContext';
import { ThemeProvider } from './src/context/ThemeContext';
import { NotificationProvider } from './src/context/NotificationContext';

// Service connections
import { setupAxiosInterceptors } from './src/services/apiInterceptors';
import { initializeBackendConnection } from './src/services/backendService';
import { connectAIEngine } from './src/services/aiEngineService';
import { initSecurityMonitoring } from './src/utils/securityMonitor';

// Utilities
import { initializeLogging } from './src/utils/logger';
import { registerServiceWorker } from './src/utils/serviceWorkerRegistration';
import { detectUserLocation } from './src/utils/geoUtils';
import { syncLocalStorage } from './src/utils/storageUtils';

// Import global styles
import './src/assets/styles/main.css';
import './src/assets/styles/responsive.css';
import './src/assets/styles/accessibility.css';

// ---------- APPLICATION INITIALIZATION ----------

// Initialize environment-specific configuration
const ENV = process.env.NODE_ENV || 'development';
const API_URL = process.env.REACT_APP_API_BASE_URL;
const AI_ENGINE_URL = process.env.REACT_APP_AI_ENGINE_URL;
const MAP_API_KEY = process.env.REACT_APP_GOOGLE_MAPS_API_KEY;
const SENTRY_DSN = process.env.REACT_APP_SENTRY_DSN;

// Configure security headers and CSRF protection
if (ENV === 'production') {
  // Setup Content Security Policy
  initSecurityMonitoring({
    enableCSP: true,
    enableCORS: true,
    xssProtection: true,
    reportOnly: false,
    sentryDSN: SENTRY_DSN
  });
}

// Initialize logging based on environment
initializeLogging(ENV);

// Configure HTTP interceptors for authentication and error handling
setupAxiosInterceptors();

// Initialize backend connection with automatic retry mechanism
initializeBackendConnection(API_URL).then(isConnected => {
  if (isConnected) {
    console.log('Successfully connected to CrisisConnect backend');
    // Connect to AI engine after backend is available
    if (ENV === 'production' || process.env.REACT_APP_ENABLE_AI === 'true') {
      connectAIEngine(AI_ENGINE_URL);
    }
  }
}).catch(error => {
  console.error('Failed to connect to backend:', error);
});

// Detect user's location for emergency resource proximity calculations
detectUserLocation().then(location => {
  if (location) {
    console.log('User location detected for emergency proximity services');
  }
});

// Synchronize important data with localStorage for offline capabilities
syncLocalStorage();

// ---------- ERROR HANDLING ----------

// Custom error handler that logs to monitoring service and preserves user state
const errorHandler = (error, errorInfo) => {
  // Log detailed error information to monitoring service
  console.error('CrisisConnect Application Error:', error);
  
  // Save user's current state to prevent data loss
  const currentState = {
    url: window.location.href,
    timestamp: new Date().toISOString()
  };
  
  // Store error context for recovery
  localStorage.setItem('crisis_connect_error_state', JSON.stringify(currentState));
};

// ---------- APPLICATION RENDERING ----------

// Create application root with error handling and fallback UI
const root = ReactDOM.createRoot(document.getElementById('root'));

// Lazy load components to improve initial load time
const renderApp = () => {
  root.render(
    <React.StrictMode>
      <ErrorBoundary FallbackComponent={ErrorFallback} onError={errorHandler}>
        <HelmetProvider>
          <Router>
            <ThemeProvider>
              <AuthProvider>
                <CrisisProvider>
                  <NotificationProvider>
                    <React.Suspense fallback={<LoadingScreen />}>
                      <App 
                        mapApiKey={MAP_API_KEY}
                        environment={ENV}
                        version={process.env.REACT_APP_VERSION || '1.0.0'}
                      />
                    </React.Suspense>
                  </NotificationProvider>
                </CrisisProvider>
              </AuthProvider>
            </ThemeProvider>
          </Router>
        </HelmetProvider>
      </ErrorBoundary>
    </React.StrictMode>
  );
};

// Allow for pre-loading critical resources before rendering
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', renderApp);
} else {
  renderApp();
}

// Register service worker for offline capabilities and push notifications
if ('serviceWorker' in navigator && (ENV === 'production' || ENV === 'staging')) {
  registerServiceWorker({
    enablePushNotifications: true,
    enableOfflineSupport: true,
    onUpdate: () => {
      // Notify user of application update
      console.log('New version available. Please refresh.');
    }
  });
}

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', event => {
  console.error('Unhandled Promise Rejection:', event.reason);
  // Prevent unhandled promise rejections from crashing the app
  event.preventDefault();
});

// Expose minimal configuration for E2E testing frameworks
if (ENV !== 'production') {
  window.__CRISIS_CONNECT_CONFIG__ = {
    apiBaseUrl: API_URL,
    environment: ENV,
    version: process.env.REACT_APP_VERSION || '1.0.0',
    aiEngineEnabled: process.env.REACT_APP_AI_ENGINE_ENABLED === 'true'
  };
}
<script src="https://cdn.jsdelivr.net/npm/react@18.2.0/umd/react.production.min.js" integrity="sha256-S0lp+k7zWUMk2ixteM6HZvu8L9Eh//OVrt+ZfbCpmgY=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/react-dom@18.2.0/umd/react-dom.production.min.js" integrity="sha256-IXWO0ITNDjfnNXIu5POVfqlgYoop36bDzhodR6LW5Pc=" crossorigin="anonymous"></script>
// Export app configuration for integration testing purposes
export const appConfig = {
  apiBaseUrl: API_URL,
  environment: ENV,
  version: process.env.REACT_APP_VERSION || '1.0.0',
  aiEngineEnabled: process.env.REACT_APP_AI_ENGINE_ENABLED === 'true',
  securityEnabled: ENV === 'production',
  offlineCapable: true
};