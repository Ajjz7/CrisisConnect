import os
import jwt
import datetime
import logging
import secrets
import hashlib
import re
from typing import Dict, Any, Optional, Tuple, List, Union

from flask import session, request
from functools import wraps
from sqlalchemy.exc import SQLAlchemyError

# Import database models
from database import db, User

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
TOKEN_EXPIRY = int(os.getenv("TOKEN_EXPIRY", "86400"))  # Default: 24 hours
REFRESH_TOKEN_EXPIRY = int(os.getenv("REFRESH_TOKEN_EXPIRY", "604800"))  # Default: 7 days
JWT_SECRET = os.getenv("JWT_SECRET", secrets.token_hex(32))
JWT_ALGORITHM = "HS256"
PASSWORD_RESET_TIMEOUT = int(os.getenv("PASSWORD_RESET_TIMEOUT", "1800"))  # Default: 30 minutes

# Map of user roles to their permission levels
ROLE_PERMISSIONS = {
    "user": ["view_resources", "submit_reports", "update_profile", "access_chatbot"],
    "responder": ["view_resources", "submit_reports", "update_profile", "access_chatbot", 
                  "respond_to_crises", "view_sensitive_data", "verify_reports"],
    "admin": ["view_resources", "submit_reports", "update_profile", "access_chatbot", 
              "respond_to_crises", "view_sensitive_data", "verify_reports", 
              "manage_users", "delete_reports", "manage_resources"]
}

# Rate limiting settings
MAX_LOGIN_ATTEMPTS = int(os.getenv("MAX_LOGIN_ATTEMPTS", "5"))
LOGIN_COOLDOWN_PERIOD = int(os.getenv("LOGIN_COOLDOWN_PERIOD", "300"))  # 5 minutes
login_attempts = {}  # IP address -> {count: int, timestamp: float}


class AuthServiceError(Exception):
    """Base exception for authentication service errors."""
    pass


class InvalidCredentialsError(AuthServiceError):
    """Exception raised for invalid credentials."""
    pass


class UserNotFoundError(AuthServiceError):
    """Exception raised when user is not found."""
    pass


class TokenExpiredError(AuthServiceError):
    """Exception raised when a token has expired."""
    pass


class InvalidTokenError(AuthServiceError):
    """Exception raised for invalid tokens."""
    pass


class RateLimitedError(AuthServiceError):
    """Exception raised when a user is rate limited."""
    pass


class PermissionDeniedError(AuthServiceError):
    """Exception raised when a user lacks required permissions."""
    pass


def generate_token(user_id: int, role: str, expiry: int = TOKEN_EXPIRY) -> str:
    """
    Generate a JWT token for a user.
    
    Args:
        user_id: User ID
        role: User role
        expiry: Token expiry time in seconds
        
    Returns:
        JWT token string
    """
    payload = {
        "user_id": user_id,
        "role": role,
        "permissions": ROLE_PERMISSIONS.get(role, []),
        "exp": datetime.datetime.utcnow() + datetime.timedelta(seconds=expiry),
        "iat": datetime.datetime.utcnow(),
        "jti": secrets.token_hex(16)  # JWT ID for token tracking/revocation
    }
    
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_token(token: str) -> Dict[str, Any]:
    """
    Decode and validate a JWT token.
    
    Args:
        token: JWT token to decode
        
    Returns:
        Decoded token payload
        
    Raises:
        TokenExpiredError: If the token has expired
        InvalidTokenError: If the token is invalid
    """
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise TokenExpiredError("Token has expired")
    except jwt.InvalidTokenError:
        raise InvalidTokenError("Invalid token")


def validate_email(email: str) -> bool:
    """
    Validate email format.
    
    Args:
        email: Email to validate
        
    Returns:
        True if email is valid, False otherwise
    """
    return bool(re.match(r"[^@]+@[^@]+\.[^@]+", email))


def validate_password(password: str) -> Tuple[bool, str]:
    """
    Validate password strength.
    
    Args:
        password: Password to validate
        
    Returns:
        Tuple of (is_valid, reason)
    """
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r"\d", password):
        return False, "Password must contain at least one digit"
    
    if not re.search(r"[A-Za-z]", password):
        return False, "Password must contain at least one letter"
    
    return True, "Password is valid"


def check_rate_limit(ip_address: str) -> bool:
    """
    Check if an IP address is rate limited for login attempts.
    
    Args:
        ip_address: IP address to check
        
    Returns:
        True if rate limited, False otherwise
    """
    now = datetime.datetime.utcnow().timestamp()
    
    if ip_address in login_attempts:
        attempts = login_attempts[ip_address]
        
        # Reset counter if cooldown period has passed
        if now - attempts["timestamp"] > LOGIN_COOLDOWN_PERIOD:
            login_attempts[ip_address] = {"count": 1, "timestamp": now}
            return False
        
        # Increase counter and check if rate limited
        if attempts["count"] >= MAX_LOGIN_ATTEMPTS:
            return True
        
        attempts["count"] += 1
        return False
    else:
        # First attempt
        login_attempts[ip_address] = {"count": 1, "timestamp": now}
        return False


def reset_rate_limit(ip_address: str) -> None:
    """
    Reset rate limit for an IP address on successful login.
    
    Args:
        ip_address: IP address to reset
    """
    if ip_address in login_attempts:
        del login_attempts[ip_address]


class AuthService:
    """
    Authentication service for handling user authentication and authorization.
    """
    
    @staticmethod
    async def register_user(user_data: Dict[str, Any]) -> User:
        """
        Register a new user.
        
        Args:
            user_data: User data including email, password, firstName, lastName, etc.
            
        Returns:
            Created user object
            
        Raises:
            AuthServiceError: If registration fails
        """
        try:
            # Validate email
            if not validate_email(user_data.get("email", "")):
                raise AuthServiceError("Invalid email format")
            
            # Check if email already exists
            existing_user = User.query.filter_by(email=user_data.get("email")).first()
            if existing_user:
                raise AuthServiceError("Email already registered")
            
            # Validate password
            password = user_data.get("password", "")
            is_valid, reason = validate_password(password)
            if not is_valid:
                raise AuthServiceError(reason)
            
            # Create new user
            new_user = User(
                firstName=user_data.get("firstName"),
                lastName=user_data.get("lastName"),
                middleInitial=user_data.get("middleInitial"),
                suffix=user_data.get("suffix"),
                email=user_data.get("email"),
                role=user_data.get("role", "user")  # Default to standard user
            )
            
            # Set password
            new_user.set_password(password)
            
            # Add and commit to database
            db.session.add(new_user)
            db.session.commit()
            
            return new_user
            
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error during registration: {str(e)}")
            raise AuthServiceError(f"Registration failed: {str(e)}")
        
        except Exception as e:
            logger.error(f"Error during registration: {str(e)}")
            raise AuthServiceError(f"Registration failed: {str(e)}")
    
    @staticmethod
    async def login(email: str, password: str, ip_address: str) -> Dict[str, Any]:
        """
        Authenticate a user and generate tokens.
        
        Args:
            email: User email
            password: User password
            ip_address: Client IP address for rate limiting
            
        Returns:
            Dictionary with tokens and user info
            
        Raises:
            RateLimitedError: If the user is rate limited
            InvalidCredentialsError: If credentials are invalid
        """
        try:
            # Check rate limiting
            if check_rate_limit(ip_address):
                logger.warning(f"Rate limit exceeded for IP: {ip_address}")
                raise RateLimitedError("Too many login attempts, please try again later")
            
            # Find user by email
            user = User.query.filter_by(email=email).first()
            if not user:
                logger.warning(f"Login attempt for non-existent user: {email}")
                raise InvalidCredentialsError("Invalid email or password")
            
            # Verify password
            if not user.verify_password(password):
                logger.warning(f"Failed login attempt for user: {email}")
                raise InvalidCredentialsError("Invalid email or password")
            
            # Reset rate limit on successful login
            reset_rate_limit(ip_address)
            
            # Generate tokens
            access_token = generate_token(user.id, user.role, TOKEN_EXPIRY)
            refresh_token = generate_token(user.id, user.role, REFRESH_TOKEN_EXPIRY)
            
            # Add refresh token to session for future validation
            session["refresh_token"] = refresh_token
            
            # Return tokens and user info
            return {
                "access_token": access_token,
                "refresh_token": refresh_token,
                "token_type": "Bearer",
                "expires_in": TOKEN_EXPIRY,
                "user_id": user.id,
                "role": user.role,
                "permissions": ROLE_PERMISSIONS.get(user.role, [])
            }
            
        except (RateLimitedError, InvalidCredentialsError):
            # Re-raise these specific exceptions
            raise
            
        except Exception as e:
            logger.error(f"Error during login: {str(e)}")
            raise AuthServiceError(f"Login failed: {str(e)}")
    
    @staticmethod
    async def refresh_token(refresh_token: str) -> Dict[str, Any]:
        """
        Refresh an access token using a refresh token.
        
        Args:
            refresh_token: Refresh token
            
        Returns:
            Dictionary with new tokens
            
        Raises:
            InvalidTokenError: If the refresh token is invalid
            TokenExpiredError: If the refresh token has expired
        """
        try:
            # Decode and validate the refresh token
            payload = decode_token(refresh_token)
            
            # Check if token matches session (if available)
            if session.get("refresh_token") != refresh_token:
                logger.warning(f"Refresh token mismatch for user ID: {payload.get('user_id')}")
                raise InvalidTokenError("Invalid refresh token")
            
            # Get user from database
            user = User.query.get(payload.get("user_id"))
            if not user:
                logger.warning(f"Refresh token for non-existent user: {payload.get('user_id')}")
                raise InvalidTokenError("Invalid refresh token")
            
            # Generate new tokens
            new_access_token = generate_token(user.id, user.role, TOKEN_EXPIRY)
            new_refresh_token = generate_token(user.id, user.role, REFRESH_TOKEN_EXPIRY)
            
            # Update session
            session["refresh_token"] = new_refresh_token
            
            return {
                "access_token": new_access_token,
                "refresh_token": new_refresh_token,
                "token_type": "Bearer",
                "expires_in": TOKEN_EXPIRY
            }
            
        except (TokenExpiredError, InvalidTokenError):
            # Clear session on token error
            session.pop("refresh_token", None)
            raise
            
        except Exception as e:
            logger.error(f"Error during token refresh: {str(e)}")
            raise AuthServiceError(f"Token refresh failed: {str(e)}")
    
    @staticmethod
    async def logout() -> None:
        """
        Log out a user by clearing their session.
        
        Note: In a real implementation, this would also invalidate tokens
        by adding them to a blocklist.
        """
        # Clear session
        session.clear()
    
    @staticmethod
    async def get_user_by_id(user_id: int) -> Optional[User]:
        """
        Get user by ID.
        
        Args:
            user_id: User ID
            
        Returns:
            User object or None if not found
        """
        return User.query.get(user_id)
    
    @staticmethod
    async def get_user_by_email(email: str) -> Optional[User]:
        """
        Get user by email.
        
        Args:
            email: User email
            
        Returns:
            User object or None if not found
        """
        return User.query.filter_by(email=email).first()
    
    @staticmethod
    async def update_user(user_id: int, user_data: Dict[str, Any]) -> User:
        """
        Update user information.
        
        Args:
            user_id: User ID
            user_data: Updated user data
            
        Returns:
            Updated user object
            
        Raises:
            UserNotFoundError: If user is not found
            AuthServiceError: If update fails
        """
        try:
            user = User.query.get(user_id)
            if not user:
                raise UserNotFoundError(f"User not found: {user_id}")
            
            # Update fields
            for key, value in user_data.items():
                if key == "password":
                    # Validate and update password
                    is_valid, reason = validate_password(value)
                    if not is_valid:
                        raise AuthServiceError(reason)
                    user.set_password(value)
                elif key == "email":
                    # Validate and update email
                    if not validate_email(value):
                        raise AuthServiceError("Invalid email format")
                    
                    # Check if email is already in use by another user
                    existing_user = User.query.filter_by(email=value).first()
                    if existing_user and existing_user.id != user_id:
                        raise AuthServiceError("Email already in use")
                    
                    user.email = value
                elif hasattr(user, key):
                    # Update other fields
                    setattr(user, key, value)
            
            # Save changes
            db.session.commit()
            
            return user
            
        except (UserNotFoundError, AuthServiceError):
            # Re-raise these specific exceptions
            raise
            
        except SQLAlchemyError as e:
            db.session.rollback()
            logger.error(f"Database error during user update: {str(e)}")
            raise AuthServiceError(f"User update failed: {str(e)}")
            
        except Exception as e:
            logger.error(f"Error during user update: {str(e)}")
            raise AuthServiceError(f"User update failed: {str(e)}")
    
    @staticmethod
    async def initiate_password_reset(email: str) -> str:
        """
        Initiate password reset for a user.
        
        Args:
            email: User email
            
        Returns:
            Reset token
            
        Raises:
            UserNotFoundError: If user is not found
        """
        user = User.query.filter_by(email=email).first()
        if not user:
            raise UserNotFoundError(f"User not found: {email}")
        
        # Generate a password reset token
        reset_token = secrets.token_urlsafe(32)
        
        # Store the token with an expiry time (in a real system, this would be in a database)
        # For now, we'll just store it in the session
        session[f"reset_token_{email}"] = {
            "token": reset_token,
            "expiry": datetime.datetime.utcnow() + datetime.timedelta(seconds=PASSWORD_RESET_TIMEOUT)
        }
        
        return reset_token
    
    @staticmethod
    async def complete_password_reset(email: str, token: str, new_password: str) -> bool:
        """
        Complete password reset with a token.
        
        Args:
            email: User email
            token: Reset token
            new_password: New password
            
        Returns:
            True if reset was successful
            
        Raises:
            UserNotFoundError: If user is not found
            AuthServiceError: If token is invalid or expired
        """
        # Validate token
        reset_data = session.get(f"reset_token_{email}")
        if not reset_data or reset_data.get("token") != token:
            raise AuthServiceError("Invalid reset token")
        
        # Check if token has expired
        if datetime.datetime.utcnow() > reset_data.get("expiry"):
            # Clean up expired token
            session.pop(f"reset_token_{email}", None)
            raise AuthServiceError("Reset token has expired")
        
        # Find user
        user = User.query.filter_by(email=email).first()
        if not user:
            raise UserNotFoundError(f"User not found: {email}")
        
        # Validate password
        is_valid, reason = validate_password(new_password)
        if not is_valid:
            raise AuthServiceError(reason)
        
        try:
            # Update password
            user.set_password(new_password)
            db.session.commit()
            
            # Clean up token
            session.pop(f"reset_token_{email}", None)
            
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during password reset: {str(e)}")
            raise AuthServiceError(f"Password reset failed: {str(e)}")
    
    @staticmethod
    async def change_password(user_id: int, current_password: str, new_password: str) -> bool:
        """
        Change a user's password.
        
        Args:
            user_id: User ID
            current_password: Current password
            new_password: New password
            
        Returns:
            True if password was changed successfully
            
        Raises:
            UserNotFoundError: If user is not found
            InvalidCredentialsError: If current password is incorrect
            AuthServiceError: If password change fails
        """
        user = User.query.get(user_id)
        if not user:
            raise UserNotFoundError(f"User not found: {user_id}")
        
        # Verify current password
        if not user.verify_password(current_password):
            raise InvalidCredentialsError("Current password is incorrect")
        
        # Validate new password
        is_valid, reason = validate_password(new_password)
        if not is_valid:
            raise AuthServiceError(reason)
        
        try:
            # Update password
            user.set_password(new_password)
            db.session.commit()
            
            return True
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error during password change: {str(e)}")
            raise AuthServiceError(f"Password change failed: {str(e)}")


# Authentication middleware for Flask
def requires_auth(*required_permissions):
    """
    Decorator for routes that require authentication.
    
    Args:
        *required_permissions: Permissions required for the route
        
    Returns:
        Decorated function
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Get token from Authorization header
            auth_header = request.headers.get("Authorization")
            if not auth_header or not auth_header.startswith("Bearer "):
                return {"message": "Authentication required"}, 401
            
            token = auth_header.split("Bearer ")[1]
            
            try:
                # Decode and validate token
                payload = decode_token(token)
                
                # Check permissions
                user_permissions = payload.get("permissions", [])
                if required_permissions and not all(perm in user_permissions for perm in required_permissions):
                    logger.warning(f"Permission denied for user ID: {payload.get('user_id')}")
                    return {"message": "Permission denied"}, 403
                
                # Add user info to kwargs
                kwargs["user_id"] = payload.get("user_id")
                kwargs["user_role"] = payload.get("role")
                
                return f(*args, **kwargs)
                
            except TokenExpiredError:
                return {"message": "Token has expired"}, 401
                
            except InvalidTokenError:
                return {"message": "Invalid token"}, 401
                
            except Exception as e:
                logger.error(f"Error in authentication middleware: {str(e)}")
                return {"message": "Authentication failed"}, 401
                
        return decorated_function
    return decorator


# Authentication middleware for FastAPI
async def fastapi_auth_middleware(request, required_permissions=None):
    """
    Authentication middleware for FastAPI.
    
    Args:
        request: FastAPI request
        required_permissions: Permissions required for the route
        
    Returns:
        User ID and role if authenticated
        
    Raises:
        HTTPException: If authentication fails
    """
    from fastapi import HTTPException
    
    # Get token from Authorization header
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    
    token = auth_header.split("Bearer ")[1]
    
    try:
        # Decode and validate token
        payload = decode_token(token)
        
        # Check permissions
        if required_permissions:
            user_permissions = payload.get("permissions", [])
            if not all(perm in user_permissions for perm in required_permissions):
                logger.warning(f"Permission denied for user ID: {payload.get('user_id')}")
                raise HTTPException(status_code=403, detail="Permission denied")
        
        return payload.get("user_id"), payload.get("role")
        
    except TokenExpiredError:
        raise HTTPException(status_code=401, detail="Token has expired")
        
    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
        
    except Exception as e:
        logger.error(f"Error in authentication middleware: {str(e)}")
        raise HTTPException(status_code=401, detail="Authentication failed")