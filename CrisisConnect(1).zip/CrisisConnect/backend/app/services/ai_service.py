import os
import json
import logging
import asyncio
import datetime
import re
import hashlib
from typing import Dict, List, Any, Optional, Tuple, Union

# API integrations
import openai
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# Numpy with error handling
try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False
    
# External function interface for importing from other modules
async def classify_crisis(text: str) -> Dict[str, Any]:
    """
    Classify the type and severity of a crisis from text.
    This is a wrapper function for the AIService.classify_crisis method.
    
    Args:
        text: Crisis description text
        
    Returns:
        Dictionary with crisis type, severity, and confidence score
    """
    ai_service = AIService()
    return await ai_service.classify_crisis(text)


async def calculate_trust_score(report: Dict[str, Any], user_reputation: float = 0.5) -> float:
    """
    Calculate trust score for a crisis report.
    This is a wrapper function for the AIService.calculate_trust_score method.
    
    Args:
        report: Crisis report data
        user_reputation: Reputation score of the reporting user (0 to 1)
        
    Returns:
        Trust score (0 to 1)
    """
    ai_service = AIService()
    return await ai_service.calculate_trust_score(report, user_reputation)


async def generate_report_summary(reports: List[Dict[str, Any]]) -> str:
    """
    Generate a summary of multiple crisis reports.
    This is a wrapper function for the AIService.generate_report_summary method.
    
    Args:
        reports: List of crisis reports
        
    Returns:
        Summary text
    """
    ai_service = AIService()
    return await ai_service.generate_report_summary(reports)


async def suggest_resources(crisis_type: str, description: str, location: str) -> List[str]:
    """
    Suggest resources for a crisis.
    This is a wrapper function for the AIService.suggest_resources method.
    
    Args:
        crisis_type: Type of crisis
        description: Crisis description
        location: Crisis location
        
    Returns:
        List of suggested resources
    """
    ai_service = AIService()
    return await ai_service.suggest_resources(crisis_type, description, location)


def detect_duplicate_reports(new_report: Dict[str, Any], existing_reports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Detect potential duplicate crisis reports.
    This is a wrapper function for the AIService.detect_duplicate_reports method.
    
    Args:
        new_report: New crisis report
        existing_reports: List of existing reports
        
    Returns:
        List of potential duplicate reports with similarity scores
    """
    ai_service = AIService()
    return ai_service.detect_duplicate_reports(new_report, existing_reports)


async def prioritize_reports(reports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Prioritize crisis reports based on severity, urgency, and other factors.
    This is a wrapper function for the AIService.prioritize_reports method.
    
    Args:
        reports: List of crisis reports
        
    Returns:
        List of reports with priority scores
    """
    ai_service = AIService()
    return await ai_service.prioritize_reports(reports)


# FastAPI Router Integration
def create_ai_router():
    """
    Create a FastAPI router for AI service endpoints.
    
    Returns:
        FastAPI router
    """
    from fastapi import APIRouter, Body, Depends, HTTPException
    
    router = APIRouter(prefix="/ai", tags=["AI Services"])
    
    @router.post("/classify")
    async def api_classify_crisis(text: str = Body(..., description="Crisis description text")):
        """Classify the type and severity of a crisis from text."""
        try:
            result = await classify_crisis(text)
            return result
        except ModelUnavailableError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Classification failed: {str(e)}")
    
    @router.post("/trust-score")
    async def api_calculate_trust_score(
        report: Dict[str, Any] = Body(..., description="Crisis report data"),
        user_reputation: float = Body(0.5, description="User reputation score (0 to 1)")
    ):
        """Calculate trust score for a crisis report."""
        try:
            score = await calculate_trust_score(report, user_reputation)
            return {"trust_score": score}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Trust score calculation failed: {str(e)}")
    
    @router.post("/summary")
    async def api_generate_summary(
        reports: List[Dict[str, Any]] = Body(..., description="List of crisis reports")
    ):
        """Generate a summary of multiple crisis reports."""
        try:
            summary = await generate_report_summary(reports)
            return {"summary": summary}
        except ModelUnavailableError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Summary generation failed: {str(e)}")
    
    @router.post("/suggest-resources")
    async def api_suggest_resources(
        crisis_type: str = Body(..., description="Type of crisis"),
        description: str = Body(..., description="Crisis description"),
        location: str = Body(..., description="Crisis location")
    ):
        """Suggest resources for a crisis."""
        try:
            resources = await suggest_resources(crisis_type, description, location)
            return {"resources": resources}
        except ModelUnavailableError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Resource suggestion failed: {str(e)}")
    
    @router.post("/detect-duplicates")
    async def api_detect_duplicates(
        new_report: Dict[str, Any] = Body(..., description="New crisis report"),
        existing_reports: List[Dict[str, Any]] = Body(..., description="List of existing reports")
    ):
        """Detect potential duplicate crisis reports."""
        try:
            duplicates = detect_duplicate_reports(new_report, existing_reports)
            return {"duplicates": duplicates}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Duplicate detection failed: {str(e)}")
    
    @router.post("/prioritize")
    async def api_prioritize_reports(
        reports: List[Dict[str, Any]] = Body(..., description="List of crisis reports")
    ):
        """Prioritize crisis reports based on severity, urgency, and other factors."""
        try:
            prioritized = await prioritize_reports(reports)
            return {"prioritized_reports": prioritized}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Report prioritization failed: {str(e)}")
    
    return router

# NLP and machine learning libraries (with graceful fallbacks)
try:
    import nltk
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    NLTK_AVAILABLE = True
    
    # Download required NLTK resources
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        nltk.download('punkt', quiet=True)
    
    try:
        nltk.data.find('corpora/stopwords')
    except LookupError:
        nltk.download('stopwords', quiet=True)
        
except ImportError:
    NLTK_AVAILABLE = False

try:
    import sklearn
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

# Local imports
from database import CrisisReport, User

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize OpenAI API
openai.api_key = os.getenv("OPENAI_API_KEY")

# Fallback model if OpenAI is not available
FALLBACK_ENABLED = os.getenv("AI_FALLBACK_ENABLED", "True").lower() in ["true", "1", "yes"]

# Crisis keywords for text analysis
CRISIS_KEYWORDS = {
    "hurricane": ["hurricane", "cyclone", "storm", "winds", "flooding", "evacuation", "landfall"],
    "tornado": ["tornado", "twister", "funnel", "winds", "shelter", "warning", "siren"],
    "flood": ["flood", "flooding", "water", "rising", "submerged", "evacuation", "levee"],
    "wildfire": ["wildfire", "fire", "smoke", "burning", "flames", "evacuation", "containment"],
    "earthquake": ["earthquake", "quake", "tremor", "shaking", "aftershock", "epicenter", "magnitude"],
    "tsunami": ["tsunami", "wave", "coastal", "evacuation", "ocean", "warning", "surge"],
    "blizzard": ["blizzard", "snow", "ice", "freezing", "whiteout", "snowstorm", "winter"],
    "heatwave": ["heatwave", "heat", "temperature", "cooling", "hydration", "exhaustion", "drought"],
    "pandemic": ["pandemic", "virus", "infection", "outbreak", "symptoms", "quarantine", "vaccine"],
    "chemical": ["chemical", "spill", "leak", "toxic", "hazardous", "evacuation", "contamination"],
    "nuclear": ["nuclear", "radiation", "radioactive", "fallout", "meltdown", "evacuation", "contamination"],
    "terrorism": ["terrorism", "attack", "bomb", "explosion", "threat", "security", "emergency"],
    "civil_unrest": ["riot", "protest", "unrest", "violence", "looting", "curfew", "martial"],
    "infrastructure": ["outage", "power", "water", "gas", "infrastructure", "utilities", "communications"]
}

# Urgency indicators for prioritization
URGENCY_INDICATORS = [
    "immediate", "urgent", "emergency", "help", "life-threatening", "critical", 
    "trapped", "injured", "dying", "severe", "dangerous", "now", "immediately",
    "stranded", "desperate", "sos", "mayday", "quickly", "asap"
]


class AIServiceError(Exception):
    """Base exception for AI service errors."""
    pass


class ModelUnavailableError(AIServiceError):
    """Exception raised when AI models are unavailable."""
    pass


class AIService:
    """
    AI Service for crisis management platform.
    Provides AI-powered features like crisis classification, priority assessment,
    resource matching, and more.
    """
    
    def __init__(self):
        """Initialize the AI service."""
        self.initialize_models()
    
    def initialize_models(self):
        """Initialize AI models and resources."""
        # Load crisis patterns for rule-based classification
        self.crisis_patterns = self._load_crisis_patterns()
        
        # Initialize NLP resources if available
        if NLTK_AVAILABLE:
            self.stop_words = set(stopwords.words('english'))
        
        # Initialize vectorizers if sklearn is available
        if SKLEARN_AVAILABLE:
            self.tfidf_vectorizer = TfidfVectorizer(
                stop_words='english',
                max_features=5000,
                ngram_range=(1, 3)
            )
            
            # Load pre-trained vectors if available
            vectors_path = os.getenv("CRISIS_VECTORS_PATH", "models/crisis_vectors.npz")
            if os.path.exists(vectors_path) and NUMPY_AVAILABLE:
                try:
                    data = np.load(vectors_path, allow_pickle=True)
                    self.crisis_vectors = data['vectors']
                    self.crisis_labels = data['labels']
                    self.vectorizer_fitted = True
                except Exception as e:
                    logger.error(f"Error loading crisis vectors: {str(e)}")
                    self.vectorizer_fitted = False
            else:
                self.vectorizer_fitted = False
                
        # Initialize responder recommendation model
        self.initialize_responder_model()
    
    def initialize_responder_model(self):
        """Initialize the responder recommendation model."""
        # In a production system, this would load a trained model for matching
        # responders to crises based on expertise, location, availability, etc.
        self.responder_model_loaded = False
        
        try:
            # Simulated model loading
            model_path = os.getenv("RESPONDER_MODEL_PATH", "models/responder_model.pkl")
            if os.path.exists(model_path) and SKLEARN_AVAILABLE:
                import pickle
                with open(model_path, 'rb') as f:
                    self.responder_model = pickle.load(f)
                self.responder_model_loaded = True
        except Exception as e:
            logger.warning(f"Failed to load responder model: {str(e)}")
            # Will fall back to rule-based matching
    
    def _load_crisis_patterns(self) -> Dict[str, List[re.Pattern]]:
        """
        Load regex patterns for crisis classification.
        
        Returns:
            Dictionary of crisis types to regex patterns
        """
        patterns = {}
        for crisis_type, keywords in CRISIS_KEYWORDS.items():
            # Convert keywords to regex patterns
            type_patterns = []
            for keyword in keywords:
                # Create pattern that matches word boundaries
                pattern = re.compile(rf'\b{keyword}\b', re.IGNORECASE)
                type_patterns.append(pattern)
            patterns[crisis_type] = type_patterns
        
        return patterns
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(openai.error.APIError)
    )
    async def classify_crisis(self, text: str) -> Dict[str, Any]:
        """
        Classify the type and severity of a crisis from text.
        Uses a combination of AI and rule-based approaches.
        
        Args:
            text: Crisis description text
            
        Returns:
            Dictionary with crisis type, severity, and confidence score
        """
        # Try OpenAI first for sophisticated classification
        try:
            # Prepare prompt for crisis classification
            prompt = f"""Analyze the following crisis report and classify it:
1. Determine the primary crisis type (hurricane, tornado, flood, wildfire, earthquake, etc.)
2. Assess the severity level (low, medium, high)
3. Identify if there are immediate life-threatening conditions
4. Extract any specific resource needs mentioned

Crisis report: "{text}"

Respond in JSON format only:
"""
            
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo-1106", # Using GPT-3.5 for cost efficiency
                messages=[
                    {"role": "system", "content": "You are a crisis classification AI that outputs only JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                response_format={"type": "json_object"},
                max_tokens=500
            )
            
            # Extract and parse JSON response
            result = json.loads(response.choices[0].message.content)
            
            # Ensure required fields are present
            if not all(key in result for key in ["crisis_type", "severity", "life_threatening"]):
                raise AIServiceError("Incomplete classification from AI model")
                
            return result
            
        except (openai.error.OpenAIError, json.JSONDecodeError, AIServiceError) as e:
            logger.warning(f"OpenAI classification failed, falling back to rule-based: {str(e)}")
            
            if not FALLBACK_ENABLED:
                raise ModelUnavailableError("AI classification is unavailable and fallback is disabled")
            
            # Fallback to rule-based classification
            return self._rule_based_classification(text)
    
    def _rule_based_classification(self, text: str) -> Dict[str, Any]:
        """
        Rule-based classification as fallback when AI is unavailable.
        
        Args:
            text: Crisis description text
            
        Returns:
            Dictionary with crisis type, severity, and other classifications
        """
        text_lower = text.lower()
        
        # Initialize scores for each crisis type
        type_scores = {crisis_type: 0 for crisis_type in CRISIS_KEYWORDS}
        
        # Count keyword matches for each crisis type
        for crisis_type, patterns in self.crisis_patterns.items():
            for pattern in patterns:
                matches = pattern.findall(text)
                type_scores[crisis_type] += len(matches)
        
        # Determine most likely crisis type
        if max(type_scores.values()) > 0:
            crisis_type = max(type_scores.items(), key=lambda x: x[1])[0]
            confidence = min(max(type_scores.values()) / 3, 0.95)  # Normalize confidence
        else:
            crisis_type = "unclassified"
            confidence = 0.3
        
        # Assess severity
        severity_score = 0
        
        # Check for urgency indicators
        for indicator in URGENCY_INDICATORS:
            if indicator in text_lower:
                severity_score += 1
        
        # Check for mentions of injuries, deaths, or large-scale damage
        if any(term in text_lower for term in ["injured", "hurt", "wounded", "bleeding"]):
            severity_score += 2
        
        if any(term in text_lower for term in ["died", "dead", "death", "fatality", "killed"]):
            severity_score += 3
        
        if any(term in text_lower for term in ["many", "multiple", "several", "dozens", "hundreds"]):
            severity_score += 1
        
        # Determine severity level
        if severity_score >= 5:
            severity = "high"
            life_threatening = True
        elif severity_score >= 2:
            severity = "medium"
            life_threatening = "possible"
        else:
            severity = "low"
            life_threatening = False
        
        # Extract resource needs (simple keyword matching)
        resource_needs = []
        resource_keywords = {
            "shelter": ["shelter", "housing", "place to stay", "roof"],
            "food": ["food", "hungry", "meals", "eat"],
            "water": ["water", "thirsty", "drinking", "dehydrated"],
            "medical": ["medical", "medicine", "doctor", "hospital", "injured", "hurt"],
            "evacuation": ["evacuation", "evacuate", "escape", "leave", "flee"],
            "rescue": ["rescue", "save", "trapped", "stranded"]
        }
        
        for resource, keywords in resource_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                resource_needs.append(resource)
        
        return {
            "crisis_type": crisis_type,
            "severity": severity,
            "life_threatening": life_threatening,
            "confidence": confidence,
            "resource_needs": resource_needs
        }
    
    async def calculate_trust_score(self, report: Dict[str, Any], user_reputation: float = 0.5) -> float:
        """
        Calculate trust score for a crisis report.
        
        Args:
            report: Crisis report data
            user_reputation: Reputation score of the reporting user (0 to 1)
            
        Returns:
            Trust score (0 to 1)
        """
        # Start with base trust score from user reputation
        trust_score = user_reputation * 0.3  # 30% weight to user reputation
        
        # Factor in AI classification confidence
        classification = await self.classify_crisis(report.get("description", ""))
        confidence = classification.get("confidence", 0.5)
        trust_score += confidence * 0.3  # 30% weight to AI confidence
        
        # Factor in evidence (images, videos, etc.)
        evidence_score = 0.0
        if report.get("image_url"):
            evidence_score += 0.2
        if report.get("video_url"):
            evidence_score += 0.3
        if report.get("audio_url"):
            evidence_score += 0.1
        
        trust_score += evidence_score * 0.2  # 20% weight to evidence
        
        # Factor in location precision (if we have coordinates)
        location_score = 0.0
        if report.get("latitude") is not None and report.get("longitude") is not None:
            location_score = 0.5
        elif report.get("location"):
            location_score = 0.2
        
        trust_score += location_score * 0.1  # 10% weight to location
        
        # Factor in crisis severity for critical situations
        if classification.get("severity") == "high" or classification.get("life_threatening"):
            trust_score += 0.1  # Boost score for high-severity situations
            
            # Cap at 0.7 for automatic high-severity reports to prevent false alarms
            if trust_score > 0.7 and user_reputation < 0.7:
                trust_score = 0.7
        
        # Add crowd-sourced validation if available
        if "upvotes" in report and "downvotes" in report:
            total_votes = report["upvotes"] + report["downvotes"]
            if total_votes > 0:
                crowd_score = report["upvotes"] / total_votes
                trust_score = trust_score * 0.8 + crowd_score * 0.2  # 20% weight to crowd validation
        
        # Ensure score is within bounds
        return max(0.1, min(trust_score, 0.99))
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(openai.error.APIError)
    )
    async def generate_report_summary(self, reports: List[Dict[str, Any]]) -> str:
        """
        Generate a summary of multiple crisis reports.
        
        Args:
            reports: List of crisis reports
            
        Returns:
            Summary text
        """
        if not reports:
            return "No crisis reports available."
        
        try:
            # Extract key information from reports
            report_texts = []
            for i, report in enumerate(reports):
                report_text = f"Report {i+1}: {report.get('description', 'No description')} "
                report_text += f"(Location: {report.get('location', 'Unknown')}, "
                report_text += f"Type: {report.get('crisis_type', 'Unclassified')}, "
                report_text += f"Trust Score: {report.get('trust_score', 0.0):.2f})"
                report_texts.append(report_text)
            
            all_reports = "\n".join(report_texts)
            
            # Generate summary with OpenAI
            prompt = f"""Summarize the following crisis reports into a concise situation update:

{all_reports}

Provide:
1. Overall situation assessment
2. Key affected areas
3. Most urgent needs and concerns
4. Consistent patterns across reports
5. Discrepancies or potentially unreliable information

Keep the summary factual, clear, and actionable for emergency responders.
"""
            
            response = await openai.ChatCompletion.acreate(
                model="gpt-4",  # Using GPT-4 for more advanced summarization
                messages=[
                    {"role": "system", "content": "You are a crisis assessment AI that generates concise, factual summaries."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=800
            )
            
            return response.choices[0].message.content.strip()
            
        except openai.error.OpenAIError as e:
            logger.warning(f"OpenAI summarization failed, falling back to template: {str(e)}")
            
            if not FALLBACK_ENABLED:
                raise ModelUnavailableError("AI summarization is unavailable and fallback is disabled")
            
            # Fallback to template-based summary
            return self._generate_template_summary(reports)
    
    def _generate_template_summary(self, reports: List[Dict[str, Any]]) -> str:
        """
        Generate a template-based summary when AI is unavailable.
        
        Args:
            reports: List of crisis reports
            
        Returns:
            Summary text
        """
        # Count reports by crisis type
        type_counts = {}
        locations = set()
        high_severity_count = 0
        resource_needs = {}
        
        for report in reports:
            # Count by crisis type
            crisis_type = report.get("crisis_type", "unclassified")
            type_counts[crisis_type] = type_counts.get(crisis_type, 0) + 1
            
            # Collect unique locations
            if "location" in report:
                locations.add(report["location"])
            
            # Count high severity reports
            if report.get("severity") == "high":
                high_severity_count += 1
            
            # Collect resource needs
            if "resource_needs" in report:
                for need in report["resource_needs"]:
                    resource_needs[need] = resource_needs.get(need, 0) + 1
        
        # Generate summary
        summary = f"CRISIS SITUATION SUMMARY ({len(reports)} Reports)\n\n"
        
        # Most common crisis types
        if type_counts:
            primary_type = max(type_counts.items(), key=lambda x: x[1])[0]
            summary += f"Primary Crisis Type: {primary_type.upper()}\n"
            summary += "Crisis Types Reported:\n"
            for crisis_type, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True):
                summary += f"- {crisis_type}: {count} reports\n"
        
        # Affected areas
        if locations:
            summary += f"\nAffected Areas ({len(locations)}):\n"
            for location in sorted(locations):
                summary += f"- {location}\n"
        
        # Severity assessment
        severity_percentage = high_severity_count / len(reports) * 100 if reports else 0
        if severity_percentage >= 50:
            summary += "\nSEVERITY ASSESSMENT: HIGH - Immediate response required\n"
        elif severity_percentage >= 25:
            summary += "\nSEVERITY ASSESSMENT: MEDIUM - Urgent response needed\n"
        else:
            summary += "\nSEVERITY ASSESSMENT: LOW - Monitoring required\n"
        
        # Resource needs
        if resource_needs:
            summary += "\nResource Needs:\n"
            for need, count in sorted(resource_needs.items(), key=lambda x: x[1], reverse=True):
                summary += f"- {need}: mentioned in {count} reports\n"
        
        # Add timestamp
        summary += f"\nReport generated: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}"
        
        return summary
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(openai.error.APIError)
    )
    async def suggest_resources(self, crisis_type: str, description: str, location: str) -> List[str]:
        """
        Suggest resources for a crisis.
        
        Args:
            crisis_type: Type of crisis
            description: Crisis description
            location: Crisis location
            
        Returns:
            List of suggested resources
        """
        try:
            # Generate resource suggestions with OpenAI
            prompt = f"""Based on the following crisis information, suggest the most appropriate emergency resources:

Crisis Type: {crisis_type}
Location: {location}
Description: {description}

Provide a list of 5-7 specific resources or services that would be most helpful for this situation.
Focus on practical, actionable resources that address immediate needs.
"""
            
            response = await openai.ChatCompletion.acreate(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are an emergency resource coordination AI that provides practical resource suggestions."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=300
            )
            
            suggestions_text = response.choices[0].message.content.strip()
            
            # Parse the suggestions into a list
            suggestions = []
            for line in suggestions_text.split('\n'):
                # Look for numbered or bulleted items
                if re.match(r'^[\d\-\*\•\.\s]+', line):
                    # Remove leading numbers, bullets, etc.
                    clean_line = re.sub(r'^[\d\-\*\•\.\s]+', '', line).strip()
                    if clean_line:
                        suggestions.append(clean_line)
            
            # If parsing failed, just use the whole text
            if not suggestions:
                suggestions = [s.strip() for s in suggestions_text.split('\n') if s.strip()]
            
            return suggestions
            
        except openai.error.OpenAIError as e:
            logger.warning(f"OpenAI resource suggestion failed, falling back to template: {str(e)}")
            
            if not FALLBACK_ENABLED:
                raise ModelUnavailableError("AI resource suggestion is unavailable and fallback is disabled")
            
            # Fallback to template-based suggestions
            return self._get_template_resources(crisis_type)
    
    def _get_template_resources(self, crisis_type: str) -> List[str]:
        """
        Get template-based resource suggestions when AI is unavailable.
        
        Args:
            crisis_type: Type of crisis
            
        Returns:
            List of suggested resources
        """
        # Define template resources for common crisis types
        template_resources = {
            "hurricane": [
                "Emergency Shelters",
                "Evacuation Transportation",
                "Food and Water Distribution",
                "Medical Aid Stations",
                "Power Outage Response Teams",
                "Debris Removal Services",
                "Emergency Communication Systems"
            ],
            "tornado": [
                "Storm Shelters",
                "Search and Rescue Teams",
                "Emergency Medical Services",
                "Temporary Housing",
                "Debris Clearing Equipment",
                "Structural Assessment Teams",
                "Community Support Centers"
            ],
            "flood": [
                "Water Rescue Teams",
                "Evacuation Boats",
                "Water Pumping Equipment",
                "Sandbag Distribution",
                "Clean Water Supplies",
                "Waterborne Disease Prevention",
                "Flood Damage Assessment"
            ],
            "wildfire": [
                "Firefighting Units",
                "Evacuation Coordination",
                "Air Quality Monitoring",
                "Emergency Animal Shelter",
                "Respiratory Health Services",
                "Burn Treatment Centers",
                "Fire Containment Resources"
            ],
            "earthquake": [
                "Urban Search and Rescue",
                "Field Hospitals",
                "Structural Engineers",
                "Emergency Water Systems",
                "Temporary Shelter Coordination",
                "Aftershock Monitoring",
                "Utility Restoration Teams"
            ],
            "pandemic": [
                "Testing Facilities",
                "Quarantine Support",
                "Medical Supply Distribution",
                "Remote Healthcare Services",
                "Contact Tracing Teams",
                "Vaccine Distribution",
                "Essential Delivery Services"
            ]
        }
        
        # Return template resources for the specified crisis type or generic resources
        return template_resources.get(crisis_type, [
            "Emergency Response Teams",
            "Temporary Shelter Coordination",
            "Medical Aid Units",
            "Food and Water Distribution",
            "Emergency Communication Systems",
            "Community Support Centers",
            "Recovery Coordination"
        ])
    
    def detect_duplicate_reports(self, new_report: Dict[str, Any], existing_reports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect potential duplicate crisis reports.
        
        Args:
            new_report: New crisis report
            existing_reports: List of existing reports
            
        Returns:
            List of potential duplicate reports with similarity scores
        """
        if not SKLEARN_AVAILABLE or not existing_reports:
            # Without sklearn, use simple keyword matching
            return self._simple_duplicate_detection(new_report, existing_reports)
        
        # Extract text from reports
        new_text = new_report.get("description", "")
        existing_texts = [report.get("description", "") for report in existing_reports]
        
        try:
            # Check if we need to fit the vectorizer first
            if not hasattr(self, 'tfidf_vectorizer') or not self.vectorizer_fitted:
                self.tfidf_vectorizer = TfidfVectorizer(
                    stop_words='english',
                    max_features=5000,
                    ngram_range=(1, 3)
                )
                all_texts = existing_texts + [new_text]
                self.tfidf_vectorizer.fit(all_texts)
                self.vectorizer_fitted = True
            
            # Transform texts to TF-IDF vectors
            new_vector = self.tfidf_vectorizer.transform([new_text])
            existing_vectors = self.tfidf_vectorizer.transform(existing_texts)
            
            # Calculate cosine similarity
            similarities = cosine_similarity(new_vector, existing_vectors).flatten()
            
            # Find potential duplicates (similarity > 0.6)
            duplicates = []
            for i, similarity in enumerate(similarities):
                if similarity > 0.6:
                    duplicates.append({
                        "report": existing_reports[i],
                        "similarity": float(similarity)
                    })
            
            # Sort by similarity (descending)
            duplicates.sort(key=lambda x: x["similarity"], reverse=True)
            
            return duplicates
            
        except Exception as e:
            logger.warning(f"Error in TF-IDF duplicate detection: {str(e)}")
            return self._simple_duplicate_detection(new_report, existing_reports)
    
    def _simple_duplicate_detection(self, new_report: Dict[str, Any], existing_reports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Simple keyword-based duplicate detection as fallback.
        
        Args:
            new_report: New crisis report
            existing_reports: List of existing reports
            
        Returns:
            List of potential duplicate reports with similarity scores
        """
        new_text = new_report.get("description", "").lower()
        new_location = new_report.get("location", "").lower()
        new_crisis_type = new_report.get("crisis_type", "").lower()
        
        # Extract keywords (simple tokenization)
        new_words = set(re.findall(r'\b\w+\b', new_text))
        
        duplicates = []
        for report in existing_reports:
            score = 0.0
            
            # Check for matching location (high importance)
            if new_location and new_location == report.get("location", "").lower():
                score += 0.3
            
            # Check for matching crisis type
            if new_crisis_type and new_crisis_type == report.get("crisis_type", "").lower():
                score += 0.2
            
            # Check for overlapping keywords
            report_text = report.get("description", "").lower()
            report_words = set(re.findall(r'\b\w+\b', report_text))
            
            # Calculate Jaccard similarity
            if new_words and report_words:
                intersection = len(new_words.intersection(report_words))
                union = len(new_words.union(report_words))
                keyword_similarity = intersection / union if union > 0 else 0
                score += keyword_similarity * 0.5
            
            # Consider timestamps (reports within 30 minutes more likely to be duplicates)
            new_timestamp = new_report.get("timestamp")
            report_timestamp = report.get("timestamp")
            
            if new_timestamp and report_timestamp:
                try:
                    # Parse ISO format timestamps
                    if isinstance(new_timestamp, str):
                        new_timestamp = datetime.datetime.fromisoformat(new_timestamp.replace('Z', '+00:00'))
                    if isinstance(report_timestamp, str):
                        report_timestamp = datetime.datetime.fromisoformat(report_timestamp.replace('Z', '+00:00'))
                    
                    # Calculate time difference in minutes
                    time_diff = abs((new_timestamp - report_timestamp).total_seconds() / 60)
                    
                    # Boost similarity for reports close in time
                    if time_diff < 30:
                        score += 0.2 * (1 - time_diff / 30)
                except (ValueError, TypeError):
                    pass
            
            if score > 0.6:
                duplicates.append({
                    "report": report,
                    "similarity": score
                })
        
        # Sort by similarity (descending)
        duplicates.sort(key=lambda x: x["similarity"], reverse=True)
        
        return duplicates
    
    async def match_responders(self, crisis_report: Dict[str, Any], available_responders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Match appropriate responders to a crisis based on expertise, location, and availability.
        
        Args:
            crisis_report: Crisis report data
            available_responders: List of available responders with their attributes
            
        Returns:
            List of matched responders with match scores
        """
        if not available_responders:
            return []
        
        # Try to use machine learning model if available
        if self.responder_model_loaded:
            try:
                return self._ml_responder_matching(crisis_report, available_responders)
            except Exception as e:
                logger.warning(f"ML responder matching failed, falling back to rule-based: {str(e)}")
        
        # Fallback to rule-based matching
        return self._rule_based_responder_matching(crisis_report, available_responders)
    
    def _ml_responder_matching(self, crisis_report: Dict[str, Any], available_responders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Match responders using machine learning model.
        
        Args:
            crisis_report: Crisis report data
            available_responders: List of available responders
            
        Returns:
            List of matched responders with match scores
        """
        # This would use the loaded ML model in a real implementation
        # For now, we'll just call the rule-based method as a placeholder
        return self._rule_based_responder_matching(crisis_report, available_responders)
    
    def _rule_based_responder_matching(self, crisis_report: Dict[str, Any], available_responders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Match responders using rule-based approach.
        
        Args:
            crisis_report: Crisis report data
            available_responders: List of available responders
            
        Returns:
            List of matched responders with match scores
        """
        crisis_type = crisis_report.get("crisis_type", "").lower()
        crisis_location = crisis_report.get("location", "").lower()
        crisis_severity = crisis_report.get("severity", "medium").lower()
        
        # Define responder specialties by crisis type
        specialty_mapping = {
            "hurricane": ["storm", "flood", "evacuation", "rescue"],
            "tornado": ["storm", "rescue", "medical", "debris"],
            "flood": ["flood", "water", "rescue", "evacuation"],
            "wildfire": ["fire", "evacuation", "forestry", "rescue"],
            "earthquake": ["structural", "rescue", "medical", "debris"],
            "pandemic": ["medical", "healthcare", "disease", "public health"],
            "chemical": ["hazmat", "decontamination", "chemical", "evacuation"],
            "terrorism": ["security", "law enforcement", "medical", "evacuation"]
        }
        
        # Get relevant specialties for this crisis
        relevant_specialties = specialty_mapping.get(crisis_type, ["general", "rescue"])
        
        matched_responders = []
        for responder in available_responders:
            match_score = 0.0
            
            # Match by specialty (most important)
            responder_specialties = [s.lower() for s in responder.get("specialties", [])]
            specialty_matches = sum(1 for s in relevant_specialties if any(s in rs for rs in responder_specialties))
            specialty_score = min(specialty_matches / max(1, len(relevant_specialties)), 1.0)
            match_score += specialty_score * 0.5
            
            # Match by location proximity (if coordinates available)
            if ("latitude" in crisis_report and "longitude" in crisis_report and 
                "latitude" in responder and "longitude" in responder):
                
                # Calculate distance (rough approximation)
                crisis_lat = crisis_report["latitude"]
                crisis_lng = crisis_report["longitude"]
                responder_lat = responder["latitude"]
                responder_lng = responder["longitude"]
                
                # Simple Euclidean distance (would use proper geospatial in production)
                distance = ((crisis_lat - responder_lat) ** 2 + (crisis_lng - responder_lng) ** 2) ** 0.5
                
                # Convert to proximity score (closer = higher score, max distance of 1.0 degree)
                proximity_score = max(0, 1 - distance / 1.0)
                match_score += proximity_score * 0.3
            elif crisis_location and responder.get("location", "").lower() == crisis_location:
                # Simple location name matching
                match_score += 0.3
            
            # Match by availability and workload
            availability = responder.get("availability", 0.0)
            match_score += availability * 0.1
            
            # Match by experience level for high-severity crises
            if crisis_severity == "high" and responder.get("experience_level", 0) >= 3:
                match_score += 0.1
            
            # Add to matched responders if score is above threshold
            if match_score >= 0.4:
                matched_responder = {
                    "responder_id": responder.get("id"),
                    "name": responder.get("name"),
                    "match_score": match_score,
                    "specialties": responder.get("specialties", []),
                    "location": responder.get("location"),
                    "availability": responder.get("availability", 0.0)
                }
                matched_responders.append(matched_responder)
        
        # Sort by match score (descending)
        matched_responders.sort(key=lambda x: x["match_score"], reverse=True)
        
        return matched_responders
    
    async def analyze_crisis_trends(self, reports: List[Dict[str, Any]], timeframe_days: int = 7) -> Dict[str, Any]:
        """
        Analyze trends in crisis reports over time.
        
        Args:
            reports: List of crisis reports
            timeframe_days: Timeframe for analysis in days
            
        Returns:
            Dictionary with trend analysis
        """
        if not reports:
            return {
                "total_reports": 0,
                "trends": {},
                "hotspots": [],
                "forecast": "Insufficient data for trend analysis"
            }
        
        # Filter reports within timeframe
        cutoff_date = datetime.datetime.utcnow() - datetime.timedelta(days=timeframe_days)
        
        recent_reports = []
        for report in reports:
            timestamp = report.get("timestamp")
            if timestamp:
                try:
                    # Parse ISO format timestamp
                    if isinstance(timestamp, str):
                        report_time = datetime.datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                    else:
                        report_time = timestamp
                    
                    if report_time >= cutoff_date:
                        recent_reports.append(report)
                except (ValueError, TypeError):
                    pass
        
        if not recent_reports:
            return {
                "total_reports": 0,
                "trends": {},
                "hotspots": [],
                "forecast": "No recent reports within specified timeframe"
            }
        
        # Analyze by crisis type
        crisis_types = {}
        for report in recent_reports:
            crisis_type = report.get("crisis_type", "unclassified")
            crisis_types[crisis_type] = crisis_types.get(crisis_type, 0) + 1
        
        # Analyze by location
        locations = {}
        for report in recent_reports:
            location = report.get("location")
            if location:
                locations[location] = locations.get(location, 0) + 1
        
        # Find hotspots (locations with multiple reports)
        hotspots = [
            {"location": loc, "report_count": count}
            for loc, count in locations.items()
            if count >= 3
        ]
        hotspots.sort(key=lambda x: x["report_count"], reverse=True)
        
        # Calculate trends over time
        daily_counts = {}
        for report in recent_reports:
            timestamp = report.get("timestamp")
            if timestamp:
                try:
                    # Parse ISO format timestamp
                    if isinstance(timestamp, str):
                        report_time = datetime.datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                    else:
                        report_time = timestamp
                    
                    day_key = report_time.strftime("%Y-%m-%d")
                    daily_counts[day_key] = daily_counts.get(day_key, 0) + 1
                except (ValueError, TypeError):
                    pass
        
        # Sort daily counts by date
        sorted_days = sorted(daily_counts.keys())
        trend_data = [{"date": day, "count": daily_counts[day]} for day in sorted_days]
        
        # Calculate trend direction
        trend_direction = "stable"
        if len(sorted_days) >= 2:
            first_half = sum(daily_counts[day] for day in sorted_days[:len(sorted_days)//2])
            second_half = sum(daily_counts[day] for day in sorted_days[len(sorted_days)//2:])
            
            if second_half > first_half * 1.2:
                trend_direction = "increasing"
            elif second_half < first_half * 0.8:
                trend_direction = "decreasing"
        
        # Generate simple forecast
        forecast = "Insufficient data for reliable forecast"
        if len(sorted_days) >= 3:
            if trend_direction == "increasing":
                forecast = "Crisis reports are increasing. Expect continued escalation in the next 24-48 hours."
            elif trend_direction == "decreasing":
                forecast = "Crisis reports are decreasing. Situation appears to be stabilizing."
            else:
                forecast = "Crisis reporting rate is stable. Continue monitoring for changes."
        
        return {
            "total_reports": len(recent_reports),
            "trends": {
                "by_type": crisis_types,
                "by_day": trend_data,
                "direction": trend_direction
            },
            "hotspots": hotspots[:5],  # Top 5 hotspots
            "forecast": forecast
        }
        
    async def prioritize_reports(self, reports: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Prioritize crisis reports based on severity, urgency, and other factors.
        
        Args:
            reports: List of crisis reports
            
        Returns:
            List of reports with priority scores
        """
        prioritized_reports = []
        
        for report in reports:
            # Start with base priority from trust score
            priority = report.get("trust_score", 0.5) * 0.3
            
            # Add priority based on severity
            severity_score = 0.0
            if report.get("severity") == "high":
                severity_score = 1.0
            elif report.get("severity") == "medium":
                severity_score = 0.6
            elif report.get("severity") == "low":
                severity_score = 0.3
            
            priority += severity_score * 0.4
            
            # Add priority for life-threatening situations
            if report.get("life_threatening") is True:
                priority += 0.2
            
            # Factor in recency (newer reports get higher priority)
            timestamp = report.get("timestamp")
            if timestamp:
                try:
                    # Parse ISO format timestamp
                    if isinstance(timestamp, str):
                        report_time = datetime.datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                    else:
                        report_time = timestamp
                    
                    # Calculate hours since report
                    hours_ago = (datetime.datetime.utcnow() - report_time).total_seconds() / 3600
                    
                    # Reduce priority for older reports (up to 24 hours)
                    age_factor = max(0, 1 - hours_ago / 24)
                    priority += age_factor * 0.1
                except (ValueError, TypeError):
                    pass
            
            # Add priority for reports with evidence
            if report.get("image_url") or report.get("video_url") or report.get("audio_url"):
                priority += 0.05
            
            # Add priority for reports with precise location
            if report.get("latitude") is not None and report.get("longitude") is not None:
                priority += 0.05
            
            # Create prioritized report
            prioritized_report = report.copy()
            prioritized_report["priority_score"] = min(priority, 1.0)  # Cap at 1.0
            prioritized_reports.append(prioritized_report)
        
        # Sort by priority (descending)
        prioritized_reports.sort(key=lambda x: x["priority_score"], reverse=True)
        
        return prioritized_reports