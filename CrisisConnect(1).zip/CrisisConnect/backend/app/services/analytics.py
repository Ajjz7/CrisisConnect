import os
import json
import logging
import datetime
from typing import Dict, List, Any, Optional, Tuple, Union
import csv
import io
from collections import defaultdict, Counter

# Data processing libraries with fallbacks
try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    from sklearn.cluster import DBSCAN
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

try:
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.use('Agg')  # Use non-interactive backend
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

# Local imports
from database import CrisisReport, User, db
from services.ai_service import classify_crisis, analyze_crisis_trends

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
REPORT_FIELDS = [
    "id", "user_id", "crisis_type", "description", "latitude", "longitude", 
    "location", "timestamp", "verified", "verified_by", "trust_score", 
    "upvotes", "downvotes", "responder_notified", "responder_id"
]

USER_FIELDS = [
    "id", "firstName", "lastName", "email", "role", "city", "state"
]

class AnalyticsError(Exception):
    """Base exception for analytics service errors."""
    pass


class AnalyticsService:
    """
    Analytics service for crisis management platform.
    Provides data analysis, reporting, visualization, and export functions.
    """
    
    def __init__(self):
        """Initialize the analytics service."""
        self.export_directory = os.getenv("EXPORT_DIRECTORY", "exports")
        
        # Create export directory if it doesn't exist
        os.makedirs(self.export_directory, exist_ok=True)
    
    async def generate_crisis_report(self, 
                                    start_date: Optional[datetime.datetime] = None,
                                    end_date: Optional[datetime.datetime] = None,
                                    crisis_type: Optional[str] = None,
                                    location: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate a comprehensive crisis report for the specified parameters.
        
        Args:
            start_date: Start date for report period
            end_date: End date for report period
            crisis_type: Filter by crisis type
            location: Filter by location
            
        Returns:
            Dictionary with report data
        """
        # Set default dates if not provided
        if end_date is None:
            end_date = datetime.datetime.utcnow()
        
        if start_date is None:
            start_date = end_date - datetime.timedelta(days=30)  # Last 30 days by default
        
        # Build query
        query = CrisisReport.query.filter(CrisisReport.timestamp.between(start_date, end_date))
        
        if crisis_type:
            query = query.filter(CrisisReport.crisis_type == crisis_type)
        
        if location:
            query = query.filter(CrisisReport.location == location)
        
        # Execute query
        reports = query.all()
        
        # Convert to dictionaries for easier processing
        report_dicts = [self._report_to_dict(report) for report in reports]
        
        # Generate report data
        try:
            # Basic statistics
            total_reports = len(report_dicts)
            verified_reports = sum(1 for r in report_dicts if r.get("verified"))
            high_trust_reports = sum(1 for r in report_dicts if r.get("trust_score", 0) >= 0.8)
            responded_reports = sum(1 for r in report_dicts if r.get("responder_notified"))
            
            # Aggregate by crisis type
            type_counts = Counter(r.get("crisis_type", "unclassified") for r in report_dicts)
            
            # Aggregate by location
            location_counts = Counter(r.get("location", "unknown") for r in report_dicts)
            
            # Time series analysis (reports per day)
            if PANDAS_AVAILABLE:
                df = pd.DataFrame(report_dicts)
                if not df.empty and "timestamp" in df.columns:
                    df["date"] = pd.to_datetime(df["timestamp"]).dt.date
                    reports_by_day = df.groupby("date").size().reset_index(name="count")
                    time_series = reports_by_day.to_dict("records")
                else:
                    time_series = []
            else:
                # Fallback without pandas
                date_counts = defaultdict(int)
                for report in report_dicts:
                    timestamp = report.get("timestamp")
                    if timestamp:
                        if isinstance(timestamp, str):
                            try:
                                dt = datetime.datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                                date_str = dt.date().isoformat()
                                date_counts[date_str] += 1
                            except (ValueError, TypeError):
                                pass
                        elif isinstance(timestamp, datetime.datetime):
                            date_str = timestamp.date().isoformat()
                            date_counts[date_str] += 1
                
                time_series = [{"date": date, "count": count} for date, count in date_counts.items()]
                time_series.sort(key=lambda x: x["date"])
            
            # Response time analysis (time between report and response)
            if responded_reports > 0:
                response_times = []
                for report in report_dicts:
                    if report.get("responder_notified") and report.get("timestamp"):
                        report_time = report.get("timestamp")
                        response_time = report.get("response_timestamp")
                        
                        if report_time and response_time:
                            if isinstance(report_time, str):
                                report_time = datetime.datetime.fromisoformat(report_time.replace('Z', '+00:00'))
                            if isinstance(response_time, str):
                                response_time = datetime.datetime.fromisoformat(response_time.replace('Z', '+00:00'))
                            
                            delta = (response_time - report_time).total_seconds() / 60  # minutes
                            response_times.append(delta)
                
                if response_times:
                    avg_response_time = sum(response_times) / len(response_times)
                    median_response_time = sorted(response_times)[len(response_times) // 2]
                else:
                    avg_response_time = None
                    median_response_time = None
            else:
                avg_response_time = None
                median_response_time = None
            
            # AI-powered trend analysis
            try:
                trends = await analyze_crisis_trends(report_dicts, timeframe_days=30)
            except Exception as e:
                logger.warning(f"Failed to analyze trends: {str(e)}")
                trends = {"error": str(e)}
            
            # Generate report
            report = {
                "report_period": {
                    "start_date": start_date.isoformat(),
                    "end_date": end_date.isoformat()
                },
                "filters": {
                    "crisis_type": crisis_type,
                    "location": location
                },
                "summary": {
                    "total_reports": total_reports,
                    "verified_reports": verified_reports,
                    "high_trust_reports": high_trust_reports,
                    "responded_reports": responded_reports,
                    "verification_rate": round(verified_reports / total_reports * 100, 1) if total_reports > 0 else 0,
                    "response_rate": round(responded_reports / total_reports * 100, 1) if total_reports > 0 else 0
                },
                "response_times": {
                    "average_minutes": round(avg_response_time, 1) if avg_response_time is not None else None,
                    "median_minutes": round(median_response_time, 1) if median_response_time is not None else None
                },
                "top_crisis_types": dict(type_counts.most_common(5)),
                "top_locations": dict(location_counts.most_common(5)),
                "time_series": time_series,
                "trends": trends
            }
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating crisis report: {str(e)}")
            raise AnalyticsError(f"Report generation failed: {str(e)}")
    
    def _report_to_dict(self, report: CrisisReport) -> Dict[str, Any]:
        """
        Convert a CrisisReport model to a dictionary.
        
        Args:
            report: CrisisReport model instance
            
        Returns:
            Dictionary representation of the report
        """
        result = {}
        for field in REPORT_FIELDS:
            if hasattr(report, field):
                value = getattr(report, field)
                if isinstance(value, datetime.datetime):
                    value = value.isoformat()
                result[field] = value
        
        return result
    
    def _user_to_dict(self, user: User) -> Dict[str, Any]:
        """
        Convert a User model to a dictionary (excluding sensitive fields).
        
        Args:
            user: User model instance
            
        Returns:
            Dictionary representation of the user
        """
        result = {}
        for field in USER_FIELDS:
            if hasattr(user, field):
                value = getattr(user, field)
                result[field] = value
        
        return result
    
    async def detect_hotspots(self, 
                             timeframe_days: int = 7,
                             crisis_type: Optional[str] = None,
                             min_reports: int = 3) -> List[Dict[str, Any]]:
        """
        Detect geographical hotspots of crisis activity.
        
        Args:
            timeframe_days: Timeframe for analysis in days
            crisis_type: Filter by crisis type
            min_reports: Minimum reports to consider a hotspot
            
        Returns:
            List of hotspot information
        """
        # Calculate cutoff date
        cutoff_date = datetime.datetime.utcnow() - datetime.timedelta(days=timeframe_days)
        
        # Build query
        query = CrisisReport.query.filter(CrisisReport.timestamp >= cutoff_date)
        
        if crisis_type:
            query = query.filter(CrisisReport.crisis_type == crisis_type)
        
        # Execute query
        reports = query.all()
        
        # Convert to dictionaries
        report_dicts = [self._report_to_dict(report) for report in reports]
        
        # Simple hotspot detection by location name
        location_counts = Counter(r.get("location", "unknown") for r in report_dicts if r.get("location") != "unknown")
        
        simple_hotspots = [
            {"location": location, "report_count": count, "detection_method": "name_based"}
            for location, count in location_counts.items()
            if count >= min_reports
        ]
        
        # Advanced hotspot detection using clustering (if coordinates available)
        advanced_hotspots = []
        if SKLEARN_AVAILABLE and NUMPY_AVAILABLE:
            try:
                # Extract reports with coordinates
                coords_reports = [
                    {**r, "coords": (r["latitude"], r["longitude"])}
                    for r in report_dicts
                    if r.get("latitude") is not None and r.get("longitude") is not None
                ]
                
                if len(coords_reports) >= min_reports:
                    # Extract coordinates
                    coords = np.array([r["coords"] for r in coords_reports])
                    
                    # Normalize coordinates
                    scaler = StandardScaler()
                    coords_scaled = scaler.fit_transform(coords)
                    
                    # Run DBSCAN clustering
                    clustering = DBSCAN(eps=0.1, min_samples=min_reports).fit(coords_scaled)
                    
                    # Extract clusters
                    labels = clustering.labels_
                    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
                    
                    # Process each cluster
                    for cluster_id in range(n_clusters):
                        cluster_reports = [r for i, r in enumerate(coords_reports) if labels[i] == cluster_id]
                        
                        if len(cluster_reports) >= min_reports:
                            # Calculate cluster center
                            center_lat = sum(r["latitude"] for r in cluster_reports) / len(cluster_reports)
                            center_lng = sum(r["longitude"] for r in cluster_reports) / len(cluster_reports)
                            
                            # Get most common location name in cluster
                            cluster_locations = Counter(r.get("location", "unknown") for r in cluster_reports if r.get("location") != "unknown")
                            most_common_location = cluster_locations.most_common(1)[0][0] if cluster_locations else "Unnamed Area"
                            
                            # Most common crisis type in cluster
                            cluster_types = Counter(r.get("crisis_type", "unclassified") for r in cluster_reports)
                            most_common_type = cluster_types.most_common(1)[0][0] if cluster_types else "unclassified"
                            
                            # Add to advanced hotspots
                            advanced_hotspots.append({
                                "location": most_common_location,
                                "center": {"latitude": center_lat, "longitude": center_lng},
                                "report_count": len(cluster_reports),
                                "radius_km": self._estimate_cluster_radius(cluster_reports, center_lat, center_lng),
                                "primary_crisis_type": most_common_type,
                                "detection_method": "spatial_clustering"
                            })
            except Exception as e:
                logger.warning(f"Advanced hotspot detection failed: {str(e)}")
        
        # Combine hotspots, with advanced taking precedence
        advanced_locations = {h["location"] for h in advanced_hotspots}
        combined_hotspots = advanced_hotspots + [h for h in simple_hotspots if h["location"] not in advanced_locations]
        
        # Sort by report count (descending)
        combined_hotspots.sort(key=lambda x: x["report_count"], reverse=True)
        
        return combined_hotspots
    
    def _estimate_cluster_radius(self, reports: List[Dict[str, Any]], center_lat: float, center_lng: float) -> float:
        """
        Estimate the radius of a cluster in kilometers.
        
        Args:
            reports: List of reports in the cluster
            center_lat: Center latitude
            center_lng: Center longitude
            
        Returns:
            Estimated radius in kilometers
        """
        # Calculate distances from center
        distances = []
        for report in reports:
            lat = report["latitude"]
            lng = report["longitude"]
            
            # Simple Euclidean distance (rough approximation)
            # In a production system, would use proper geospatial calculations
            distance = ((lat - center_lat) ** 2 + (lng - center_lng) ** 2) ** 0.5
            
            # Rough conversion to kilometers (very approximate)
            km_distance = distance * 111  # 1 degree ≈ 111 km
            distances.append(km_distance)
        
        # Use 95th percentile as radius to exclude outliers
        if distances:
            distances.sort()
            if len(distances) >= 20:
                return distances[int(len(distances) * 0.95)]
            else:
                return max(distances)
        else:
            return 1.0  # Default 1 km radius
    
    async def generate_response_efficiency_report(self, start_date: Optional[datetime.datetime] = None,
                                                end_date: Optional[datetime.datetime] = None) -> Dict[str, Any]:
        """
        Generate a report on responder efficiency.
        
        Args:
            start_date: Start date for report period
            end_date: End date for report period
            
        Returns:
            Dictionary with efficiency report data
        """
        # Set default dates if not provided
        if end_date is None:
            end_date = datetime.datetime.utcnow()
        
        if start_date is None:
            start_date = end_date - datetime.timedelta(days=30)  # Last 30 days by default
        
        # Query reports with responders
        reports = CrisisReport.query.filter(
            CrisisReport.timestamp.between(start_date, end_date),
            CrisisReport.responder_id.isnot(None)
        ).all()
        
        # Convert to dictionaries
        report_dicts = [self._report_to_dict(report) for report in reports]
        
        # Get unique responder IDs
        responder_ids = set(r.get("responder_id") for r in report_dicts if r.get("responder_id") is not None)
        
        # Query responder users
        responders = User.query.filter(User.id.in_(responder_ids)).all()
        responder_dict = {r.id: self._user_to_dict(r) for r in responders}
        
        # Calculate metrics
        responder_metrics = {}
        overall_response_times = []
        
        for responder_id in responder_ids:
            # Get reports for this responder
            responder_reports = [r for r in report_dicts if r.get("responder_id") == responder_id]
            
            # Response times (if available)
            response_times = []
            for report in responder_reports:
                if report.get("timestamp") and report.get("response_timestamp"):
                    report_time = report.get("timestamp")
                    response_time = report.get("response_timestamp")
                    
                    if isinstance(report_time, str):
                        report_time = datetime.datetime.fromisoformat(report_time.replace('Z', '+00:00'))
                    if isinstance(response_time, str):
                        response_time = datetime.datetime.fromisoformat(response_time.replace('Z', '+00:00'))
                    
                    delta = (response_time - report_time).total_seconds() / 60  # minutes
                    response_times.append(delta)
                    overall_response_times.append(delta)
            
            # Calculate metrics
            avg_response_time = sum(response_times) / len(response_times) if response_times else None
            
            # Crisis types handled
            crisis_types = Counter(r.get("crisis_type", "unclassified") for r in responder_reports)
            
            # Add to responder metrics
            responder_info = responder_dict.get(responder_id, {"id": responder_id})
            responder_metrics[responder_id] = {
                "responder_info": responder_info,
                "metrics": {
                    "total_reports_handled": len(responder_reports),
                    "avg_response_time_minutes": round(avg_response_time, 1) if avg_response_time is not None else None,
                    "crisis_types_handled": dict(crisis_types.most_common())
                }
            }
        
        # Overall metrics
        avg_overall_response_time = (
            sum(overall_response_times) / len(overall_response_times)
            if overall_response_times else None
        )
        
        # Generate report
        report = {
            "report_period": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat()
            },
            "summary": {
                "total_reports_handled": len(report_dicts),
                "total_responders": len(responder_ids),
                "avg_response_time_minutes": round(avg_overall_response_time, 1) if avg_overall_response_time is not None else None
            },
            "responder_metrics": responder_metrics
        }
        
        return report
    
    async def generate_resource_usage_report(self, start_date: Optional[datetime.datetime] = None,
                                           end_date: Optional[datetime.datetime] = None) -> Dict[str, Any]:
        """
        Generate a report on resource usage.
        
        Args:
            start_date: Start date for report period
            end_date: End date for report period
            
        Returns:
            Dictionary with resource usage report data
        """
        # Set default dates if not provided
        if end_date is None:
            end_date = datetime.datetime.utcnow()
        
        if start_date is None:
            start_date = end_date - datetime.timedelta(days=30)  # Last 30 days by default
        
        # This would query a ResourceAllocation table in a real implementation
        # For now, we'll just generate mock data
        
        # Mock resource types
        resource_types = [
            "Emergency Shelter",
            "Food Distribution",
            "Medical Supplies",
            "Water Distribution",
            "Search and Rescue",
            "Evacuation Transport",
            "Power Generator"
        ]
        
        # Generate mock resource allocation data
        resource_allocations = {}
        for resource_type in resource_types:
            # Mock allocation count (would come from database in real implementation)
            allocation_count = np.random.randint(10, 100) if NUMPY_AVAILABLE else 50
            
            # Mock utilization rate (percentage of allocated resources actually used)
            utilization_rate = np.random.uniform(0.7, 0.95) if NUMPY_AVAILABLE else 0.85
            
            # Mock average deployment time (hours)
            avg_deployment_time = np.random.uniform(2, 48) if NUMPY_AVAILABLE else 24
            
            # Add to resource allocations
            resource_allocations[resource_type] = {
                "allocation_count": allocation_count,
                "utilization_rate": round(utilization_rate, 2),
                "avg_deployment_time_hours": round(avg_deployment_time, 1)
            }
        
        # Generate mock usage by crisis type
        usage_by_crisis_type = {}
        crisis_types = ["hurricane", "flood", "wildfire", "earthquake", "tornado"]
        
        for crisis_type in crisis_types:
            # Mock resource usage for this crisis type
            resource_usage = {}
            for resource_type in resource_types:
                # Mock usage count
                usage_count = np.random.randint(5, 50) if NUMPY_AVAILABLE else 25
                resource_usage[resource_type] = usage_count
            
            usage_by_crisis_type[crisis_type] = resource_usage
        
        # Generate report
        report = {
            "report_period": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat()
            },
            "summary": {
                "total_allocations": sum(r["allocation_count"] for r in resource_allocations.values()),
                "avg_utilization_rate": round(
                    sum(r["utilization_rate"] for r in resource_allocations.values()) / len(resource_allocations),
                    2
                ) if resource_allocations else 0
            },
            "resource_allocations": resource_allocations,
            "usage_by_crisis_type": usage_by_crisis_type,
            "note": "This is a mock report. In a production system, this would use actual resource allocation data."
        }
        
        return report
    
    async def export_crisis_data(self, 
                               format_type: str = "csv",
                               start_date: Optional[datetime.datetime] = None,
                               end_date: Optional[datetime.datetime] = None,
                               crisis_type: Optional[str] = None,
                               location: Optional[str] = None) -> str:
        """
        Export crisis data in various formats.
        
        Args:
            format_type: Export format ("csv", "json", or "excel")
            start_date: Start date for export period
            end_date: End date for export period
            crisis_type: Filter by crisis type
            location: Filter by location
            
        Returns:
            Path to exported file
        """
        # Set default dates if not provided
        if end_date is None:
            end_date = datetime.datetime.utcnow()
        
        if start_date is None:
            start_date = end_date - datetime.timedelta(days=30)  # Last 30 days by default
        
        # Build query
        query = CrisisReport.query.filter(CrisisReport.timestamp.between(start_date, end_date))
        
        if crisis_type:
            query = query.filter(CrisisReport.crisis_type == crisis_type)
        
        if location:
            query = query.filter(CrisisReport.location == location)
        
        # Execute query
        reports = query.all()
        
        # Convert to dictionaries
        report_dicts = [self._report_to_dict(report) for report in reports]
        
        # Generate filename
        timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename_parts = ["crisis_data", timestamp]
        
        if crisis_type:
            filename_parts.append(crisis_type.replace(" ", "_"))
        
        if location:
            filename_parts.append(location.replace(" ", "_"))
        
        filename = "_".join(filename_parts)
        filepath = os.path.join(self.export_directory, f"{filename}.{format_type}")
        
        # Export based on format type
        try:
            if format_type == "csv":
                return await self._export_to_csv(report_dicts, filepath)
            elif format_type == "json":
                return await self._export_to_json(report_dicts, filepath)
            elif format_type == "excel":
                return await self._export_to_excel(report_dicts, filepath)
            else:
                raise AnalyticsError(f"Unsupported export format: {format_type}")
        except Exception as e:
            logger.error(f"Export failed: {str(e)}")
            raise AnalyticsError(f"Export failed: {str(e)}")
    
    async def _export_to_csv(self, reports: List[Dict[str, Any]], filepath: str) -> str:
        """
        Export reports to CSV.
        
        Args:
            reports: List of report dictionaries
            filepath: Output file path
            
        Returns:
            File path
        """
        if not reports:
            # Create empty file with headers
            with open(filepath, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(REPORT_FIELDS)
            return filepath
        
        # Use pandas if available (better handling of complex data)
        if PANDAS_AVAILABLE:
            try:
                df = pd.DataFrame(reports)
                df.to_csv(filepath, index=False)
                return filepath
            except Exception as e:
                logger.warning(f"Pandas CSV export failed, falling back to standard CSV: {str(e)}")
        
        # Fallback to standard CSV
        with open(filepath, 'w', newline='') as f:
            # Get all fields from the first report
            fields = list(reports[0].keys())
            
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(reports)
        
        return filepath
    
    async def _export_to_json(self, reports: List[Dict[str, Any]], filepath: str) -> str:
        """
        Export reports to JSON.
        
        Args:
            reports: List of report dictionaries
            filepath: Output file path
            
        Returns:
            File path
        """
        with open(filepath, 'w') as f:
            json.dump(reports, f, indent=2, default=str)
        
        return filepath
    
    async def _export_to_excel(self, reports: List[Dict[str, Any]], filepath: str) -> str:
        """
        Export reports to Excel.
        
        Args:
            reports: List of report dictionaries
            filepath: Output file path
            
        Returns:
            File path
        """
        if not PANDAS_AVAILABLE:
            raise AnalyticsError("Excel export requires pandas and openpyxl packages")
        
        try:
            df = pd.DataFrame(reports)
            df.to_excel(filepath, index=False)
            return filepath
        except Exception as e:
            logger.error(f"Excel export failed: {str(e)}")
            raise AnalyticsError(f"Excel export failed: {str(e)}")
    
    async def generate_visualization(self, 
                                   viz_type: str,
                                   data: Dict[str, Any],
                                   output_format: str = "png") -> str:
        """
        Generate a visualization from data.
        
        Args:
            viz_type: Type of visualization ("time_series", "heatmap", "pie_chart", etc.)
            data: Data for visualization
            output_format: Output format (png, svg, pdf)
            
        Returns:
            Path to visualization file
        """
        if not MATPLOTLIB_AVAILABLE:
            raise AnalyticsError("Visualization requires matplotlib package")
        
        try:
            # Create timestamp for filename
            timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"{viz_type}_{timestamp}.{output_format}"
            filepath = os.path.join(self.export_directory, filename)
            
            # Dispatch to appropriate visualization function
            if viz_type == "time_series":
                return self._create_time_series_plot(data, filepath)
            elif viz_type == "pie_chart":
                return self._create_pie_chart(data, filepath)
            elif viz_type == "bar_chart":
                return self._create_bar_chart(data, filepath)
            elif viz_type == "heatmap":
                return self._create_heatmap(data, filepath)
            else:
                raise AnalyticsError(f"Unsupported visualization type: {viz_type}")
                
        except Exception as e:
            logger.error(f"Visualization failed: {str(e)}")
            raise AnalyticsError(f"Visualization failed: {str(e)}")
    
    def _create_time_series_plot(self, data: Dict[str, Any], filepath: str) -> str:
        """
        Create a time series plot.
        
        Args:
            data: Time series data
            filepath: Output file path
            
        Returns:
            File path
        """
        # Extract time series data
        time_series = data.get("time_series", [])
        
        if not time_series:
            raise AnalyticsError("No time series data provided")
        
        # Create figure
        plt.figure(figsize=(10, 6))
        
        # Extract dates and counts
        dates = [entry.get("date") for entry in time_series]
        counts = [entry.get("count") for entry in time_series]
        
        # Convert date strings to datetime objects if needed
        if dates and isinstance(dates[0], str):
            dates = [datetime.datetime.fromisoformat(d) if 'T' in d else datetime.date.fromisoformat(d) for d in dates]
        
        # Create plot
        plt.plot(dates, counts, marker='o', linestyle='-', color='#1f77b4', linewidth=2)
        
        # Add title and labels
        plt.title("Crisis Reports Over Time", fontsize=16)
        plt.xlabel("Date", fontsize=12)
        plt.ylabel("Number of Reports", fontsize=12)
        
        # Format x-axis as dates
        plt.gcf().autofmt_xdate()
        
        # Add grid
        plt.grid(True, linestyle='--', alpha=0.7)
        
        # Add annotations for peaks
        if counts:
            max_idx = counts.index(max(counts))
            plt.annotate(f'Peak: {counts[max_idx]}',
                        xy=(dates[max_idx], counts[max_idx]),
                        xytext=(10, 20),
                        textcoords='offset points',
                        arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=.2'))
        
        # Save figure
        plt.tight_layout()
        plt.savefig(filepath, dpi=300)
        plt.close()
        
        return filepath
    
    def _create_pie_chart(self, data: Dict[str, Any], filepath: str) -> str:
        """
        Create a pie chart.
        
        Args:
            data: Pie chart data
            filepath: Output file path
            
        Returns:
            File path
        """
        # Extract categories and values
        categories = data.get("categories", [])
        values = data.get("values", [])
        title = data.get("title", "Distribution")
        
        if not categories or not values or len(categories) != len(values):
            raise AnalyticsError("Invalid pie chart data")
        
        # Create figure
        plt.figure(figsize=(10, 8))
        
        # Create pie chart
        plt.pie(values, labels=categories, autopct='%1.1f%%', startangle=90, shadow=True)
        
        # Add title
        plt.title(title, fontsize=16)
        
        # Make it a circle
        plt.axis('equal')
        
        # Save figure
        plt.tight_layout()
        plt.savefig(filepath, dpi=300)
        plt.close()
        
        return filepath
    
    def _create_bar_chart(self, data: Dict[str, Any], filepath: str) -> str:
        """
        Create a bar chart.
        
        Args:
            data: Bar chart data
            filepath: Output file path
            
        Returns:
            File path
        """
        # Extract categories and values
        categories = data.get("categories", [])
        values = data.get("values", [])
        title = data.get("title", "Comparison")
        xlabel = data.get("xlabel", "Categories")
        ylabel = data.get("ylabel", "Values")
        
        if not categories or not values or len(categories) != len(values):
            raise AnalyticsError("Invalid bar chart data")
        
        # Create figure
        plt.figure(figsize=(12, 7))
        
        # Create bar chart
        bars = plt.bar(categories, values, color='#1f77b4')
        
        # Add title and labels
        plt.title(title, fontsize=16)
        plt.xlabel(xlabel, fontsize=12)
        plt.ylabel(ylabel, fontsize=12)
        
        # Add data labels on top of bars
        for bar in bars:
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                    f'{height:.1f}',
                    ha='center', va='bottom', rotation=0)
        
        # Rotate x-axis labels if many categories
        if len(categories) > 5:
            plt.xticks(rotation=45, ha='right')
        
        # Add grid for y-axis
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        
        # Save figure
        plt.tight_layout()
        plt.savefig(filepath, dpi=300)
        plt.close()
        
        return filepath
    
    def _create_heatmap(self, data: Dict[str, Any], filepath: str) -> str:
        """
        Create a heatmap.
        
        Args:
            data: Heatmap data
            filepath: Output file path
            
        Returns:
            File path
        """
        # Extract matrix, row labels, and column labels
        matrix = data.get("matrix", [])
        row_labels = data.get("row_labels", [])
        col_labels = data.get("col_labels", [])
        title = data.get("title", "Heatmap")
        
        if not matrix or not row_labels or not col_labels:
            raise AnalyticsError("Invalid heatmap data")
        
        # Convert to numpy array if needed
        if NUMPY_AVAILABLE:
            matrix = np.array(matrix)
        
        # Create figure
        plt.figure(figsize=(12, 10))
        
        # Create heatmap
        plt.imshow(matrix, cmap='viridis')
        
        # Add title
        plt.title(title, fontsize=16)
        
        # Add colorbar
        plt.colorbar(label='Value')
        
        # Set ticks and labels
        plt.xticks(range(len(col_labels)), col_labels, rotation=45, ha='right')
        plt.yticks(range(len(row_labels)), row_labels)
        
        # Add text annotations
        for i in range(len(row_labels)):
            for j in range(len(col_labels)):
                text_color = 'white' if matrix[i][j] > np.mean(matrix) else 'black'
                plt.text(j, i, f'{matrix[i][j]:.1f}', ha='center', va='center', color=text_color)
        
        # Save figure
        plt.tight_layout()
        plt.savefig(filepath, dpi=300)
        plt.close()
        
        return filepath


# External function interface for importing from other modules
async def generate_crisis_report(start_date=None, end_date=None, crisis_type=None, location=None):
    """
    Generate a comprehensive crisis report.
    This is a wrapper function for the AnalyticsService.generate_crisis_report method.
    
    Args:
        start_date: Start date for report period
        end_date: End date for report period
        crisis_type: Filter by crisis type
        location: Filter by location
        
    Returns:
        Dictionary with report data
    """
    analytics_service = AnalyticsService()
    return await analytics_service.generate_crisis_report(start_date, end_date, crisis_type, location)


async def detect_hotspots(timeframe_days=7, crisis_type=None, min_reports=3):
    """
    Detect geographical hotspots of crisis activity.
    This is a wrapper function for the AnalyticsService.detect_hotspots method.
    
    Args:
        timeframe_days: Timeframe for analysis in days
        crisis_type: Filter by crisis type
        min_reports: Minimum reports to consider a hotspot
        
    Returns:
        List of hotspot information
    """
    analytics_service = AnalyticsService()
    return await analytics_service.detect_hotspots(timeframe_days, crisis_type, min_reports)


async def generate_response_efficiency_report(start_date=None, end_date=None):
    """
    Generate a report on responder efficiency.
    This is a wrapper function for the AnalyticsService.generate_response_efficiency_report method.
    
    Args:
        start_date: Start date for report period
        end_date: End date for report period
        
    Returns:
        Dictionary with efficiency report data
    """
    analytics_service = AnalyticsService()
    return await analytics_service.generate_response_efficiency_report(start_date, end_date)


async def generate_resource_usage_report(start_date=None, end_date=None):
    """
    Generate a report on resource usage.
    This is a wrapper function for the AnalyticsService.generate_resource_usage_report method.
    
    Args:
        start_date: Start date for report period
        end_date: End date for report period
        
    Returns:
        Dictionary with resource usage report data
    """
    analytics_service = AnalyticsService()
    return await analytics_service.generate_resource_usage_report(start_date, end_date)


async def export_crisis_data(format_type="csv", start_date=None, end_date=None, crisis_type=None, location=None):
    """
    Export crisis data in various formats.
    This is a wrapper function for the AnalyticsService.export_crisis_data method.
    
    Args:
        format_type: Export format ("csv", "json", or "excel")
        start_date: Start date for export period
        end_date: End date for export period
        crisis_type: Filter by crisis type
        location: Filter by location
        
    Returns:
        Path to exported file
    """
    analytics_service = AnalyticsService()
    return await analytics_service.export_crisis_data(format_type, start_date, end_date, crisis_type, location)


async def generate_visualization(viz_type, data, output_format="png"):
    """
    Generate a visualization from data.
    This is a wrapper function for the AnalyticsService.generate_visualization method.
    
    Args:
        viz_type: Type of visualization ("time_series", "heatmap", "pie_chart", etc.)
        data: Data for visualization
        output_format: Output format (png, svg, pdf)
        
    Returns:
        Path to visualization file
    """
    analytics_service = AnalyticsService()
    return await analytics_service.generate_visualization(viz_type, data, output_format)


# FastAPI Router Integration
def create_analytics_router():
    """
    Create a FastAPI router for analytics service endpoints.
    
    Returns:
        FastAPI router
    """
    from fastapi import APIRouter, Query, Body, HTTPException, BackgroundTasks, Path
    from fastapi.responses import FileResponse
    
    router = APIRouter(prefix="/analytics", tags=["Analytics"])
    
    @router.get("/crisis-report")
    async def api_crisis_report(
        start_date: Optional[str] = Query(None, description="Start date (ISO format)"),
        end_date: Optional[str] = Query(None, description="End date (ISO format)"),
        crisis_type: Optional[str] = Query(None, description="Filter by crisis type"),
        location: Optional[str] = Query(None, description="Filter by location")
    ):
        """Generate a comprehensive crisis report."""
        try:
            # Parse dates if provided
            start_date_obj = datetime.datetime.fromisoformat(start_date) if start_date else None
            end_date_obj = datetime.datetime.fromisoformat(end_date) if end_date else None
            
            report = await generate_crisis_report(start_date_obj, end_date_obj, crisis_type, location)
            return report
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Report generation failed: {str(e)}")
    
    @router.get("/hotspots")
    async def api_detect_hotspots(
        timeframe_days: int = Query(7, description="Timeframe for analysis in days"),
        crisis_type: Optional[str] = Query(None, description="Filter by crisis type"),
        min_reports: int = Query(3, description="Minimum reports to consider a hotspot")
    ):
        """Detect geographical hotspots of crisis activity."""
        try:
            hotspots = await detect_hotspots(timeframe_days, crisis_type, min_reports)
            return {"hotspots": hotspots}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Hotspot detection failed: {str(e)}")
    
    @router.get("/responder-efficiency")
    async def api_responder_efficiency(
        start_date: Optional[str] = Query(None, description="Start date (ISO format)"),
        end_date: Optional[str] = Query(None, description="End date (ISO format)")
    ):
        """Generate a report on responder efficiency."""
        try:
            # Parse dates if provided
            start_date_obj = datetime.datetime.fromisoformat(start_date) if start_date else None
            end_date_obj = datetime.datetime.fromisoformat(end_date) if end_date else None
            
            report = await generate_response_efficiency_report(start_date_obj, end_date_obj)
            return report
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Efficiency report generation failed: {str(e)}")
    
    @router.get("/resource-usage")
    async def api_resource_usage(
        start_date: Optional[str] = Query(None, description="Start date (ISO format)"),
        end_date: Optional[str] = Query(None, description="End date (ISO format)")
    ):
        """Generate a report on resource usage."""
        try:
            # Parse dates if provided
            start_date_obj = datetime.datetime.fromisoformat(start_date) if start_date else None
            end_date_obj = datetime.datetime.fromisoformat(end_date) if end_date else None
            
            report = await generate_resource_usage_report(start_date_obj, end_date_obj)
            return report
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Resource usage report generation failed: {str(e)}")
    
    @router.post("/export")
    async def api_export_data(
        background_tasks: BackgroundTasks,
        format_type: str = Query("csv", description="Export format (csv, json, excel)"),
        start_date: Optional[str] = Query(None, description="Start date (ISO format)"),
        end_date: Optional[str] = Query(None, description="End date (ISO format)"),
        crisis_type: Optional[str] = Query(None, description="Filter by crisis type"),
        location: Optional[str] = Query(None, description="Filter by location")
    ):
        """Export crisis data in various formats."""
        try:
            # Parse dates if provided
            start_date_obj = datetime.datetime.fromisoformat(start_date) if start_date else None
            end_date_obj = datetime.datetime.fromisoformat(end_date) if end_date else None
            
            # Perform export in background
            def do_export():
                return export_crisis_data(format_type, start_date_obj, end_date_obj, crisis_type, location)
            
            # Add background task
            background_tasks.add_task(do_export)
            
            return {"message": f"Export started in {format_type} format. Check export status endpoint for completion."}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")
    
    @router.post("/visualization")
    async def api_create_visualization(
        viz_type: str = Query(..., description="Visualization type (time_series, pie_chart, bar_chart, heatmap)"),
        data: Dict[str, Any] = Body(..., description="Visualization data"),
        output_format: str = Query("png", description="Output format (png, svg, pdf)")
    ):
        """Generate a visualization from data."""
        try:
            filepath = await generate_visualization(viz_type, data, output_format)
            filename = os.path.basename(filepath)
            
            return {
                "message": "Visualization created successfully",
                "file_path": filepath,
                "download_link": f"/analytics/download/{filename}"
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Visualization failed: {str(e)}")
    
    @router.get("/download/{filename}")
    async def download_file(filename: str = Path(..., description="File to download")):
        """Download a generated file."""
        analytics_service = AnalyticsService()
        filepath = os.path.join(analytics_service.export_directory, filename)
        
        if not os.path.exists(filepath):
            raise HTTPException(status_code=404, detail="File not found")
        
        return FileResponse(filepath, filename=filename)
    
    return router