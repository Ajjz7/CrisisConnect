import os
import logging
import hashlib
import ipfshttpclient
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from firebase_admin import credentials, initialize_app
from authlib.integrations.flask_client import OAuth
from fastapi import FastAPI
from dotenv import load_dotenv
import googlemaps
import speech_recognition as sr

# 🌍 Load Environment Variables Securely
load_dotenv()

# 🔥 Initialize Flask App
flask_app = Flask(__name__)
CORS(flask_app)

# 🔑 Security Configurations
flask_app.secret_key = os.getenv("FLASK_SECRET_KEY", "supersecuresecretkey")
flask_app.config['SESSION_TYPE'] = 'filesystem'

# 🛢️ Database Configuration (PostgreSQL)
flask_app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv("DATABASE_URL", "postgresql://username:password@localhost/crisisconnect")
flask_app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(flask_app)

# 🌍 Initialize Firebase for Real-Time Crisis Updates
firebase_config_path = os.getenv("FIREBASE_CONFIG_PATH", "firebase_config.json")
cred = credentials.Certificate(firebase_config_path)
firebase_app = initialize_app(cred, {'databaseURL': os.getenv("FIREBASE_DB_URL", "https://your-firebase-db.firebaseio.com")})

# 📲 OAuth for Secure Social Logins
oauth = OAuth(flask_app)
oauth.init_app(flask_app)

# 🔐 Register OAuth Providers (Google, Facebook, LinkedIn, Yahoo)
oauth.register("google",
               client_id=os.getenv("GOOGLE_CLIENT_ID"),
               client_secret=os.getenv("GOOGLE_CLIENT_SECRET"),
               authorize_url="https://accounts.google.com/o/oauth2/auth")
oauth.register("facebook",
               client_id=os.getenv("FACEBOOK_CLIENT_ID"),
               client_secret=os.getenv("FACEBOOK_CLIENT_SECRET"),
               authorize_url="https://www.facebook.com/dialog/oauth")
oauth.register("linkedin",
               client_id=os.getenv("LINKEDIN_CLIENT_ID"),
               client_secret=os.getenv("LINKEDIN_CLIENT_SECRET"),
               authorize_url="https://www.linkedin.com/oauth/v2/authorization")
oauth.register("yahoo",
               client_id=os.getenv("YAHOO_CLIENT_ID"),
               client_secret=os.getenv("YAHOO_CLIENT_SECRET"),
               authorize_url="https://api.login.yahoo.com/oauth2/request_auth")

# 🚀 Initialize FastAPI for AI Services
fastapi_app = FastAPI(title="CrisisConnect AI Services")

# 🔗 Initialize Blockchain for Crisis Report Validation
def generate_blockchain_hash(report_data):
    """Creates a unique hash for blockchain integrity verification."""
    return hashlib.sha256(report_data.encode()).hexdigest()

# 📡 Initialize IPFS for Decentralized Crisis Data Backup
ipfs_client = ipfshttpclient.connect('/ip4/127.0.0.1/tcp/5001/http')

def store_report_on_ipfs(report_data):
    """Uploads crisis reports to IPFS for decentralized storage."""
    res = ipfs_client.add_json(report_data)
    return f"IPFS Hash: {res}"

# 🏥 AI-Powered Smart Resource Matching
def prioritize_resources(user_profile, available_resources):
    """AI prioritizes resources based on vulnerability and urgency."""
    if user_profile["age"] > 65 or user_profile["disability_status"] == "Yes":
        return sorted(available_resources, key=lambda x: x["priority"], reverse=True)
    return available_resources

# 🗣️ AI Voice Assistant for Hands-Free Crisis Reporting
def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for crisis report...")
        audio = recognizer.listen(source)
    try:
        return recognizer.recognize_google(audio)
    except sr.UnknownValueError:
        return "Sorry, I couldn't understand that."

# 🔍 AI-Powered Missing Persons Identification
import face_recognition
import cv2

def recognize_face(image_path):
    known_image = face_recognition.load_image_file("missing_person.jpg")
    unknown_image = face_recognition.load_image_file(image_path)

    known_encoding = face_recognition.face_encodings(known_image)[0]
    unknown_encoding = face_recognition.face_encodings(unknown_image)[0]

    results = face_recognition.compare_faces([known_encoding], unknown_encoding)
    return "Match Found!" if results[0] else "No match found."

# 🚑 AI-Powered Emergency Vehicle Routing Optimization
gmaps = googlemaps.Client(key=os.getenv("GOOGLE_MAPS_API_KEY"))

def get_optimized_route(start, destination):
    directions = gmaps.directions(start, destination, mode="driving", avoid="traffic")
    return directions[0]['legs'][0]['duration']['text']

# 📦 Import Routes and Models
from .models import User, CrisisReport
from .routes import flask_routes
from .ai_services import fastapi_routes

# 💾 Create Database Tables Automatically
with flask_app.app_context():
    db.create_all()

# 🏁 Register Flask Routes
flask_app.register_blueprint(flask_routes)

# 🏁 Register FastAPI Routes
fastapi_app.include_router(fastapi_routes)

# 📜 Configure Logging for Security & Debugging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[
                        logging.FileHandler("crisisconnect.log"),
                        logging.StreamHandler()
                    ])

logging.info("🚀 CrisisConnect Application Initialized Successfully")
