// This is the config file to use in your web/mobile frontend
const firebaseConfig = {
  apiKey: "AIzaSyC1a8B9XyE3_LjhCr4FCdZY1ScF9XdH56k",
  authDomain: "crisisconnect-app.firebaseapp.com",
  projectId: "crisisconnect-app",
  storageBucket: "crisisconnect-app.appspot.com",
  messagingSenderId: "781023456789",
  appId: "1:781023456789:web:3f5d8a1b2c3d4e5f6a7b8c",
  measurementId: "G-MX1YZ23ABC",
  databaseURL: "https://crisisconnect-app.firebaseio.com"
};

export default firebaseConfig;