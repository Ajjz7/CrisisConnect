import os
import json
import logging
import datetime
import asyncio
from typing import Dict, List, Any, Optional, Tuple

# API integrations
import openai
from fastapi import APIRouter, HTTPException, Depends, Body, Request
from pydantic import BaseModel, Field

# Database models
from database import User, CrisisReport, db

# Resources
from resources import (
    get_safety_instructions,
    get_evacuation_routes,
    get_emergency_contacts,
    translate_text
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize OpenAI API
openai.api_key = os.getenv("OPENAI_API_KEY")

# Create API router
chatbot_router = APIRouter(tags=["Crisis Chatbot"])

# Chat history cache (In production, this would be in a proper database)
chat_histories = {}

# System prompt template for the crisis chatbot
SYSTEM_PROMPT = """
You are CrisisBot, an emergency response AI assistant designed to provide calm, clear guidance during crisis situations.

Current crisis information:
- Crisis Type: {crisis_type}
- Location: {location}
- Severity: {severity}

Your primary functions are:
1. Provide clear, actionable safety instructions
2. Help users find appropriate emergency resources
3. Answer questions about the current crisis in a factual, non-alarmist manner
4. Provide emotional support and reassurance while maintaining factual accuracy
5. Guide users to appropriate emergency services when needed

If the user is in immediate danger or requires emergency services, consistently remind them to contact emergency services (911 in the US) before anything else.

Important guidelines:
- Be concise and clear - people in crisis need simple instructions
- Prioritize life safety information over everything else
- Never downplay the seriousness of a situation, but avoid causing panic
- If you don't know something, say so clearly rather than guessing
- Use simple language that can be understood by someone under stress
- When providing instructions, list them in clear, numbered steps
- Remember that people in crisis may not be thinking clearly - be patient and repeat key information

Current date and time: {timestamp}
"""

# Chat models
class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    user_id: Optional[int] = None
    crisis_id: Optional[int] = None
    crisis_type: str = Field(..., description="Type of crisis (e.g., hurricane, flood, earthquake)")
    location: str = Field(..., description="User's current location")
    severity: str = Field("medium", description="Crisis severity: low, medium, or high")
    message: str = Field(..., description="User's message to the chatbot")
    language: str = Field("en", description="User's preferred language code")
    conversation_id: Optional[str] = None

class ChatResponse(BaseModel):
    conversation_id: str
    response: str
    resources: List[str] = []
    safety_instructions: List[str] = []
    emergency_contacts: Dict[str, str] = {}
    suggested_actions: List[str] = []
    followup_questions: List[str] = []

# Check if message contains emergency indicators
def check_emergency_indicators(message: str) -> bool:
    """Check if the message contains emergency indicators that require immediate attention."""
    emergency_phrases = [
        "help me", "dying", "can't breathe", "heart attack", "stroke", 
        "bleeding badly", "suicide", "kill myself", "injured", "trapped",
        "emergency", "urgent help", "severe injury", "gunshot", "drowning",
        "choking", "severe pain", "unconscious", "not responding"
    ]
    
    message_lower = message.lower()
    for phrase in emergency_phrases:
        if phrase in message_lower:
            return True
            
    return False

# Generate a response using OpenAI API
async def generate_response(
    crisis_type: str,
    location: str, 
    severity: str,
    message: str,
    conversation_history: List[Dict[str, str]],
    language: str = "en"
) -> Tuple[str, List[str], List[str]]:
    """
    Generate a response using the OpenAI API.
    
    Args:
        crisis_type: Type of crisis
        location: User location
        severity: Crisis severity
        message: User message
        conversation_history: Previous conversation history
        language: User's preferred language
        
    Returns:
        Tuple containing (response, resources, suggested_actions)
    """
    try:
        # Format the system prompt with crisis information
        system_prompt = SYSTEM_PROMPT.format(
            crisis_type=crisis_type,
            location=location,
            severity=severity,
            timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        
        # Construct the messages array
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        
        # Add conversation history
        messages.extend(conversation_history)
        
        # Add the current user message
        messages.append({"role": "user", "content": message})
        
        # Check for emergency indicators and add a reminder if needed
        if check_emergency_indicators(message):
            messages.append({
                "role": "system", 
                "content": "IMPORTANT: This message may indicate a life-threatening emergency. " +
                           "Remind the user to call emergency services (911) immediately if they " +
                           "haven't already. Provide clear, simple first aid guidance if relevant."
            })
        
        # Generate response
        response = await openai.ChatCompletion.acreate(
            model="gpt-4",  # Using GPT-4 for handling crisis situations
            messages=messages,
            temperature=0.3,  # Low temperature for more predictable responses
            max_tokens=800,
            top_p=0.8,
            frequency_penalty=0.5,
            presence_penalty=0.0
        )
        
        # Extract the response text
        response_text = response.choices[0].message.content.strip()
        
        # Get safety resources and suggestions
        safety_instructions = get_safety_instructions(crisis_type, severity)
        resources = []
        suggested_actions = []
        
        # Basic resource suggestions based on message content
        message_lower = message.lower()
        if "shelter" in message_lower or "where to go" in message_lower:
            resources.append("Emergency Shelter Information")
            suggested_actions.append("Share your precise location for nearest shelter information")
        if "medical" in message_lower or "injured" in message_lower or "hurt" in message_lower:
            resources.append("Emergency Medical Services")
            suggested_actions.append("Call 911 for immediate medical assistance")
        if "food" in message_lower or "water" in message_lower:
            resources.append("Emergency Supplies Distribution Points")
        if "evacuate" in message_lower or "escape" in message_lower:
            resources.append("Evacuation Route Information")
            suggested_actions.append("Check the evacuation map for your area")
        
        # Translate response if needed
        if language != "en":
            response_text = (await translate_text([response_text], language))[0]
            safety_instructions = await translate_text(safety_instructions, language)
            resources = await translate_text(resources, language)
            suggested_actions = await translate_text(suggested_actions, language)
        
        return response_text, resources, suggested_actions
    
    except Exception as e:
        logger.error(f"Error generating response: {str(e)}")
        # Fallback response in case of API failure
        return (
            "I'm having trouble connecting to my knowledge system right now. " +
            "If this is an emergency, please call 911 immediately. Otherwise, " +
            "please try again in a moment.",
            ["Emergency Services: 911"],
            ["Call emergency services if needed"]
        )

# Chatbot API endpoint
@chatbot_router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest = Body(...)) -> ChatResponse:
    """
    Process a chat request and generate a response.
    
    Args:
        request: Chat request containing user message and crisis details
        
    Returns:
        ChatResponse with AI response and resources
    """
    # Generate or retrieve conversation ID
    conversation_id = request.conversation_id or f"conv_{datetime.datetime.now().timestamp()}"
    
    # Retrieve conversation history or initialize new conversation
    if conversation_id not in chat_histories:
        chat_histories[conversation_id] = []
    
    conversation_history = chat_histories[conversation_id]
    
    # Generate response
    response_text, resources, suggested_actions = await generate_response(
        request.crisis_type,
        request.location,
        request.severity,
        request.message,
        conversation_history,
        request.language
    )
    
    # Update conversation history
    conversation_history.append({"role": "user", "content": request.message})
    conversation_history.append({"role": "assistant", "content": response_text})
    
    # Limit conversation history size (last 10 messages)
    if len(conversation_history) > 20:
        conversation_history = conversation_history[-20:]
    
    chat_histories[conversation_id] = conversation_history
    
    # Get safety instructions and emergency contacts
    safety_instructions = get_safety_instructions(request.crisis_type, request.severity)
    emergency_contacts = get_emergency_contacts(request.location)
    
    # Generate follow-up questions based on context
    followup_questions = generate_followup_questions(
        request.crisis_type, 
        request.message, 
        response_text
    )
    
    # Create and return response
    return ChatResponse(
        conversation_id=conversation_id,
        response=response_text,
        resources=resources,
        safety_instructions=safety_instructions,
        emergency_contacts=emergency_contacts,
        suggested_actions=suggested_actions,
        followup_questions=followup_questions
    )

# Generate contextual follow-up questions
def generate_followup_questions(crisis_type: str, user_message: str, response: str) -> List[str]:
    """
    Generate contextual follow-up questions based on the crisis type and conversation.
    
    Args:
        crisis_type: Type of crisis
        user_message: User's message
        response: AI response
        
    Returns:
        List of follow-up questions
    """
    # Basic follow-up questions by crisis type
    basic_questions = {
        "hurricane": [
            "Do you need evacuation assistance?",
            "Do you have emergency supplies?",
            "Are you in a flood-prone area?",
            "Do you need information about nearby shelters?"
        ],
        "tornado": [
            "Do you have access to a basement or storm shelter?",
            "Do you need help finding the nearest storm shelter?",
            "Have you heard the tornado sirens or warnings?",
            "Is your family all together in a safe place?"
        ],
        "flood": [
            "Are you on higher ground?",
            "Is water entering your home?",
            "Do you have a way to evacuate if needed?",
            "Do you have clean drinking water?"
        ],
        "wildfire": [
            "Is smoke visible from your location?",
            "Do you have an evacuation plan ready?",
            "Do you need information about air quality?",
            "Are there any road closures in your area?"
        ],
        "earthquake": [
            "Is your building structurally sound?",
            "Do you smell gas or see damaged power lines?",
            "Do you need medical assistance?",
            "Are you prepared for aftershocks?"
        ],
        "pandemic": [
            "Do you need medical resources?",
            "Are you experiencing symptoms?",
            "Do you have access to testing?",
            "Do you need assistance with isolation or quarantine?"
        ]
    }
    
    # Start with crisis-specific questions
    questions = basic_questions.get(crisis_type, [
        "Do you need immediate assistance?",
        "Are you in a safe location?",
        "Do you have access to emergency services?",
        "Can I help you locate specific resources?"
    ])
    
    # Contextual questions based on user message
    message_lower = user_message.lower()
    
    if "children" in message_lower or "kids" in message_lower:
        questions.append("Do you need child-specific resources or services?")
    
    if "pet" in message_lower or "dog" in message_lower or "cat" in message_lower:
        questions.append("Do you need information about pet-friendly shelters?")
    
    if "medical" in message_lower or "medicine" in message_lower:
        questions.append("Do you need urgent medical assistance?")
    
    if "food" in message_lower or "water" in message_lower:
        questions.append("Do you need information about emergency supply distribution?")
    
    if "shelter" in message_lower or "evacuat" in message_lower:
        questions.append("Would you like directions to the nearest emergency shelter?")
    
    # Limit to 3 most relevant questions to avoid overwhelming the user
    return questions[:3]

# Log chat for crisis monitoring
@chatbot_router.post("/log-chat")
async def log_chat(
    user_id: int, 
    conversation_id: str, 
    message: str, 
    is_emergency: bool = False
):
    """
    Log chat messages for crisis monitoring.
    Conversations flagged as emergencies can be prioritized by responders.
    
    Args:
        user_id: User ID
        conversation_id: Conversation ID
        message: Chat message
        is_emergency: Whether the message indicates an emergency
        
    Returns:
        Acknowledgment of the log
    """
    try:
        # In a real implementation, this would store the log in a database
        logger.info(f"Chat log - User: {user_id}, Conversation: {conversation_id}, Emergency: {is_emergency}")
        
        # If this is flagged as an emergency, it could trigger notifications to responders
        if is_emergency:
            # In a real implementation, this would trigger emergency notifications
            logger.warning(f"EMERGENCY CHAT detected from User {user_id}: {message[:100]}...")
            
            # Here you would integrate with emergency notification systems
            # This is a placeholder for that functionality
            
        return {"status": "logged", "emergency_flagged": is_emergency}
    
    except Exception as e:
        logger.error(f"Error logging chat: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to log chat: {str(e)}")

# Get crisis-specific chatbot instructions
@chatbot_router.get("/crisis-instructions/{crisis_type}")
async def get_crisis_instructions(crisis_type: str, severity: str = "medium"):
    """
    Get crisis-specific instructions and resources for the chatbot UI.
    
    Args:
        crisis_type: Type of crisis
        severity: Crisis severity
        
    Returns:
        Crisis-specific instructions and resources
    """
    try:
        # Get safety instructions
        safety_instructions = get_safety_instructions(crisis_type, severity)
        
        # Crisis-specific UI elements and quick responses
        quick_responses = {
            "hurricane": [
                "I need evacuation information",
                "Where is the nearest shelter?",
                "How long will the hurricane last?",
                "What should I put in my emergency kit?"
            ],
            "tornado": [
                "Where should I take shelter?",
                "How do I know when it's safe?",
                "I hear a tornado siren",
                "My home is damaged"
            ],
            "flood": [
                "Is it safe to drive?",
                "Water is entering my home",
                "I need clean water",
                "How high will the water get?"
            ],
            "wildfire": [
                "Should I evacuate?",
                "What's the air quality?",
                "Which roads are closed?",
                "How to prepare my home"
            ],
            "earthquake": [
                "Is it safe to go inside?",
                "I smell gas",
                "Are there aftershocks coming?",
                "How to check for structural damage"
            ],
            "pandemic": [
                "I think I have symptoms",
                "Where can I get tested?",
                "I need medical supplies",
                "How to isolate safely"
            ]
        }
        
        # Default quick responses for other crisis types
        default_responses = [
            "I need immediate help",
            "Where is the nearest emergency service?",
            "How to stay safe",
            "I need medical assistance"
        ]
        
        return {
            "crisis_type": crisis_type,
            "severity": severity,
            "safety_instructions": safety_instructions,
            "quick_responses": quick_responses.get(crisis_type, default_responses),
            "emergency_disclaimer": "If you are experiencing a life-threatening emergency, please call 911 immediately."
        }
        
    except Exception as e:
        logger.error(f"Error getting crisis instructions: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get crisis instructions: {str(e)}")

# Function to add chatbot routes to the main app
def add_chatbot_routes(app):
    """Add chatbot routes to the main app."""
    app.include_router(chatbot_router, prefix="/api/chatbot")