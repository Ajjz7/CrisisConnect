import os
import aiohttp
import json
import hashlib
import datetime
from typing import Dict, List, Any, Optional, Union
import asyncio

# OpenAI integration for intelligent resource matching
import openai

# Machine learning imports for prediction
try:
    import numpy as np
    import pandas as pd
    from sklearn.ensemble import RandomForestClassifier
    ML_AVAILABLE = True
except ImportError:
    ML_AVAILABLE = False

# Initialize OpenAI API key
openai.api_key = os.getenv("OPENAI_API_KEY")

# External API URLs
FEMA_API_URL = os.getenv("FEMA_API_URL", "https://www.fema.gov/api/open/v1/DisasterDeclarationsSummaries")
RED_CROSS_API_URL = os.getenv("RED_CROSS_API_URL", "https://api.redcross.org/disaster_relief")
WHO_CRISIS_API = os.getenv("WHO_CRISIS_API", "https://who.int/emergency/api")
WEATHER_API_URL = os.getenv("WEATHER_API_URL", "https://api.weather.gov/points")
ENVIRONMENTAL_API_URL = os.getenv("ENVIRONMENTAL_API_URL", "https://api.epa.gov/air/quality")

# Cache for API responses to reduce load
api_cache = {}
CACHE_DURATION = 300  # Cache duration in seconds


class DisasterResourceManager:
    """
    Manages disaster resources, recommendations, and related information.
    This class centralizes all resource management functionality.
    """
    
    def __init__(self):
        """Initialize the disaster resource manager."""
        self.load_resource_database()
        self.load_prediction_models()
    
    def load_resource_database(self):
        """Load the disaster resource database from file or initialize default resources."""
        resource_file = os.getenv("RESOURCE_DATABASE", "resources/disaster_resources.json")
        try:
            with open(resource_file, 'r') as f:
                self.resources = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # Initialize with default resources if file not found or invalid
            self.resources = self._get_default_resources()
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(resource_file), exist_ok=True)
            
            # Save the default resources
            with open(resource_file, 'w') as f:
                json.dump(self.resources, f, indent=4)
    
    def load_prediction_models(self):
        """Load machine learning models for crisis prediction if available."""
        self.models = {}
        if ML_AVAILABLE:
            model_dir = os.getenv("MODEL_DIRECTORY", "models")
            if os.path.exists(model_dir):
                for disaster_type in os.listdir(model_dir):
                    model_path = os.path.join(model_dir, disaster_type, "model.pkl")
                    if os.path.exists(model_path):
                        try:
                            import pickle
                            with open(model_path, 'rb') as f:
                                self.models[disaster_type] = pickle.load(f)
                        except Exception as e:
                            print(f"Error loading model for {disaster_type}: {str(e)}")
    
    def _get_default_resources(self) -> Dict[str, List[str]]:
        """
        Get the default disaster resources by category.
        This serves as a fallback if resource files aren't available.
        """
        return {
            # Weather-Related Disasters
            "hurricane": [
                "Emergency Shelters", 
                "Food Banks", 
                "Medical Aid", 
                "Evacuation Centers", 
                "Emergency Hotlines", 
                "Power Outage Services", 
                "Water Damage Restoration", 
                "Debris Removal Services"
            ],
            "tornado": [
                "Storm Shelters", 
                "Tornado Warning Systems", 
                "Debris Cleanup", 
                "Structural Engineers", 
                "Medical Triage", 
                "Missing Persons Resources", 
                "Emergency Housing", 
                "Psychological Support"
            ],
            "blizzard": [
                "Snow Removal Services", 
                "Winter Survival Supplies", 
                "Heating Aid", 
                "Stranded Motorist Rescue", 
                "Power Outage Support", 
                "Emergency Fuel Delivery", 
                "Cold-Weather Shelters"
            ],
            "heatwave": [
                "Cooling Centers", 
                "Hydration Stations", 
                "Elder Check-in Services", 
                "Heat Illness Treatment", 
                "Air-Conditioned Public Spaces", 
                "Power Grid Support"
            ],
            "drought": [
                "Water Conservation Resources", 
                "Agricultural Support", 
                "Water Distribution Centers", 
                "Wildfire Prevention", 
                "Emergency Irrigation", 
                "Livestock Support"
            ],
            
            # Geological Disasters
            "earthquake": [
                "Rescue Operations", 
                "Temporary Housing", 
                "Emergency Health Clinics", 
                "Food Assistance", 
                "Structural Assessment Teams", 
                "Aftershock Monitoring", 
                "Utilities Restoration"
            ],
            "tsunami": [
                "Evacuation Routes", 
                "High Ground Locations", 
                "Early Warning Systems", 
                "Maritime Emergency Services", 
                "Family Reunification", 
                "Coastal Damage Assessment"
            ],
            "landslide": [
                "Geotechnical Engineers", 
                "Evacuation Assistance", 
                "Route Clearance", 
                "Soil Stabilization", 
                "Property Damage Assessment", 
                "Structural Inspections"
            ],
            "volcanic_eruption": [
                "Ash Protection Supplies", 
                "Air Quality Monitoring", 
                "Evacuation Transportation", 
                "Respiratory Health Services", 
                "Lahars Warning Systems"
            ],
            
            # Water-Related Disasters
            "flood": [
                "Flood Rescue Teams", 
                "Evacuation Shelters", 
                "Drinking Water Distribution", 
                "Sanitation & Hygiene Kits", 
                "Water Pumping Services", 
                "Mold Prevention Resources", 
                "Waterborne Disease Prevention"
            ],
            "flash_flood": [
                "Swift Water Rescue", 
                "Emergency Alert Systems", 
                "Road Closure Information", 
                "Bridge Structural Assessments", 
                "Flash Flood Shelters", 
                "Helicopter Rescue Services"
            ],
            "dam_failure": [
                "Downstream Evacuation Plan", 
                "Water Level Monitoring", 
                "Emergency Engineering Support", 
                "Rapid Response Rescue Teams", 
                "Inundation Zone Maps"
            ],
            
            # Fire-Related Disasters
            "wildfire": [
                "Evacuation Centers", 
                "Fire Updates", 
                "Volunteer Support", 
                "Air Quality Alerts", 
                "Firefighting Resource Coordination", 
                "Burn Treatment Specialists", 
                "Wildlife Rescue"
            ],
            "urban_fire": [
                "Fire Department Coordination", 
                "Burn Victim Services", 
                "Emergency Housing", 
                "Smoke Inhalation Treatment", 
                "Building Inspection Services", 
                "Displaced Resident Support"
            ],
            
            # Biological Disasters
            "pandemic": [
                "Testing Sites", 
                "Mental Health Support", 
                "Online Medical Consultation", 
                "Vaccine Centers", 
                "Quarantine Support", 
                "Remote Work Resources", 
                "PPE Distribution"
            ],
            "epidemic": [
                "Disease Tracking Systems", 
                "Vaccination Services", 
                "Quarantine Facilities", 
                "Medical Supply Distribution", 
                "Healthcare Provider Coordination", 
                "Public Health Information"
            ],
            "biological_hazard": [
                "Containment Resources", 
                "Decontamination Services", 
                "Specialized Medical Treatment", 
                "Hazardous Material Teams", 
                "Biomonitoring Services"
            ],
            
            # Human-Caused Disasters
            "chemical_spill": [
                "Hazmat Response Teams", 
                "Decontamination Centers", 
                "Environmental Monitoring", 
                "Evacuation Coordination", 
                "Chemical Exposure Treatment"
            ],
            "radiation": [
                "Radiation Detection", 
                "Decontamination Services", 
                "Specialized Medical Care", 
                "Exclusion Zone Mapping", 
                "Long-term Health Monitoring"
            ],
            "terrorism": [
                "Law Enforcement Coordination", 
                "Trauma Services", 
                "Security Perimeter Information", 
                "Family Reunification", 
                "Investigation Support"
            ],
            "conflict": [
                "Refugee Assistance", 
                "Crisis Counseling", 
                "Security Alerts", 
                "Humanitarian Aid Services", 
                "Safe Passage Routes", 
                "Ceasefire Information", 
                "Missing Persons Registry"
            ],
            "infrastructure_failure": [
                "Engineering Assessment", 
                "Utility Restoration", 
                "Alternative Service Providers", 
                "Safety Inspection", 
                "Temporary Infrastructure Solutions"
            ]
        }
    
    def get_safety_instructions(self, crisis_type: str, severity: str = "medium") -> List[str]:
        """
        Get safety instructions based on crisis type and severity.
        
        Args:
            crisis_type: Type of crisis/disaster
            severity: Severity level (low, medium, high)
            
        Returns:
            List of safety instructions
        """
        basic_instructions = {
            # Weather-Related Disasters
            "hurricane": [
                "Stay indoors and away from windows",
                "Have emergency supplies ready",
                "Follow evacuation orders immediately",
                "Avoid flooded areas - turn around, don't drown",
                "Keep devices charged for emergency updates"
            ],
            "tornado": [
                "Seek shelter in basement or interior room without windows",
                "Cover yourself with blankets or mattress if possible",
                "Stay away from windows and exterior doors",
                "If in a vehicle, do not try to outrun a tornado - seek shelter immediately",
                "After passing, beware of downed power lines and debris"
            ],
            "blizzard": [
                "Stay indoors and keep warm",
                "Conserve heat by closing off unused rooms",
                "Dress in layers if going outside is necessary",
                "Keep emergency supplies including food, water, and medications",
                "Clear snow from exhaust pipes before starting vehicles"
            ],
            "heatwave": [
                "Stay hydrated and drink plenty of water",
                "Avoid strenuous activities during peak heat hours",
                "Use air conditioning or seek cooling centers",
                "Check on elderly neighbors and those with health conditions",
                "Never leave children or pets in vehicles"
            ],
            
            # Geological Disasters
            "earthquake": [
                "Drop, Cover, and Hold On under sturdy furniture",
                "Stay away from windows and exterior walls",
                "If outdoors, move to open area away from buildings and power lines",
                "After shaking stops, evacuate if damage is severe",
                "Be prepared for aftershocks"
            ],
            "tsunami": [
                "Move immediately to higher ground if warning issued",
                "Stay away from the coast and low-lying areas",
                "Follow evacuation routes - not shortcuts",
                "Wait for official all-clear before returning",
                "Beware of contaminated water and debris"
            ],
            "landslide": [
                "Evacuate immediately if signs of land movement",
                "Move uphill away from the slide path",
                "Listen for unusual sounds like trees cracking or boulders knocking",
                "Watch for changes in landscape like tilting trees",
                "Stay alert during heavy rainfall which may trigger slides"
            ],
            
            # Water-Related Disasters
            "flood": [
                "Move to higher ground immediately",
                "Do not walk or drive through flood waters",
                "Turn around, don't drown - just 6 inches of water can knock you down",
                "Avoid bridges over fast-moving water",
                "Disconnect utilities if instructed by authorities"
            ],
            "flash_flood": [
                "Seek higher ground immediately",
                "Do not wait for official warnings if you see rising water",
                "Abandon vehicles if surrounded by rising water",
                "Stay away from storm drains and culverts",
                "Be especially cautious at night when floods are harder to recognize"
            ],
            
            # Fire-Related Disasters
            "wildfire": [
                "Follow evacuation orders immediately",
                "Close all windows and doors if indoors",
                "Remove flammable items from around your home if time allows",
                "Wear masks or wet cloth over nose/mouth to filter smoke",
                "Stay tuned to emergency broadcasts for updates"
            ],
            "urban_fire": [
                "Evacuate immediately - do not gather belongings",
                "Stay low to avoid smoke inhalation",
                "Test doors with back of hand before opening",
                "Use stairs, never elevators",
                "Once out, stay out - never re-enter a burning building"
            ],
            
            # Biological Disasters
            "pandemic": [
                "Follow public health guidelines",
                "Practice social distancing and wear recommended PPE",
                "Wash hands frequently and disinfect high-touch surfaces",
                "Avoid large gatherings",
                "Seek medical attention if showing symptoms"
            ],
            
            # Human-Caused Disasters
            "chemical_spill": [
                "Stay upwind and uphill from the spill area",
                "Seal windows and doors if sheltering in place",
                "Turn off HVAC systems that could circulate contaminated air",
                "Follow decontamination instructions if exposed",
                "Evacuate immediately if ordered by authorities"
            ],
            "conflict": [
                "Stay away from areas of active conflict",
                "Remain in secure shelter until situation stabilizes",
                "Keep emergency supplies including food, water, and medications",
                "Follow instructions from emergency services",
                "Stay informed through official channels"
            ]
        }
        
        # Default instructions for unlisted crisis types
        default_instructions = [
            "Follow instructions from local emergency officials",
            "Have emergency supplies ready including food, water, and medications",
            "Keep communication devices charged",
            "Stay informed through official channels",
            "Check on vulnerable neighbors if safe to do so"
        ]
        
        # Get the basic instructions for this crisis type or use default
        instructions = basic_instructions.get(crisis_type, default_instructions)
        
        # Add severity-specific instructions
        if severity == "high":
            instructions.insert(0, "THIS IS A LIFE-THREATENING SITUATION - TAKE IMMEDIATE ACTION")
            
            if crisis_type in ["hurricane", "tornado", "flood", "wildfire", "tsunami"]:
                instructions.append("Evacuate immediately if ordered by authorities")
                
        elif severity == "low":
            instructions.insert(0, "Stay alert and monitor conditions")
        
        return instructions
    
    def get_evacuation_routes(self, location: str, crisis_type: str) -> Dict[str, str]:
        """
        Get evacuation routes based on location and crisis type.
        In a real implementation, this would query mapping services or emergency management systems.
        
        Args:
            location: User's location
            crisis_type: Type of crisis/disaster
            
        Returns:
            Dictionary of evacuation routes and information
        """
        # This is a simplified placeholder
        # In production, this would connect to emergency service APIs
        location_hash = hashlib.md5(location.encode()).hexdigest()
        
        # Different evacuation message based on disaster type
        primary_route_suffix = ""
        if crisis_type == "flood" or crisis_type == "flash_flood":
            primary_route_suffix = " (avoid low-lying roads)"
        elif crisis_type == "wildfire":
            primary_route_suffix = " (check for road closures due to fire)"
        elif crisis_type == "hurricane" or crisis_type == "tornado":
            primary_route_suffix = " (route may change based on storm path)"
            
        return {
            "primary_route": f"Take Main Street north to Highway 101, then proceed to designated shelter at North High School{primary_route_suffix}",
            "secondary_route": "If primary route is blocked, use River Road to State Route 7, then east to East Middle School shelter",
            "walking_route": "If evacuation by vehicle is not possible, proceed on foot north on Pine Street to temporary shelter at Community Center",
            "public_transportation": "Emergency shuttle services running from Central Plaza every 30 minutes",
            "special_needs_transportation": "Call Emergency Services at 555-0000 for assisted evacuation"
        }
        
    def get_emergency_contacts(self, location: str) -> Dict[str, str]:
        """
        Get emergency contacts based on location.
        In a real implementation, this would query location-specific emergency services.
        
        Args:
            location: User's location
            
        Returns:
            Dictionary of emergency contact information
        """
        # This is a simplified placeholder
        # In production, this would connect to a database of region-specific emergency contacts
        return {
            "emergency_services": "911",
            "local_emergency_management": "555-1234",
            "shelter_coordination": "555-2345",
            "medical_emergency": "555-3456",
            "power_outage": "555-4567",
            "gas_leak": "555-5678",
            "water_emergency": "555-6789",
            "poison_control": "1-800-222-1222",
            "disaster_relief": "555-7890"
        }
    
    async def get_external_api_data(self, url: str) -> Dict[str, Any]:
        """
        Get data from external API with caching to reduce load.
        
        Args:
            url: API URL to request
            
        Returns:
            API response data as dictionary
        """
        # Check cache first
        now = datetime.datetime.now().timestamp()
        if url in api_cache and now - api_cache[url]["timestamp"] < CACHE_DURATION:
            return api_cache[url]["data"]
        
        # Cache miss, make actual API request
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    data = await response.json()
                    
                    # Update cache
                    api_cache[url] = {
                        "timestamp": now,
                        "data": data
                    }
                    
                    return data
        except Exception as e:
            # Return error message if API request fails
            return {"error": str(e)}
    
    async def get_weather_data(self, location: str) -> Dict[str, Any]:
        """
        Get weather data for a location.
        
        Args:
            location: Location to get weather data for
            
        Returns:
            Weather data for the location
        """
        # In a real implementation, this would query a weather API with proper geocoding
        # This is a simplified placeholder that returns mock data
        try:
            # Simulate API call (replace with actual geocoding and API call in production)
            return {
                "current_conditions": "Partially cloudy",
                "temperature": 78,
                "wind_speed": 15,
                "wind_direction": "NE",
                "precipitation_chance": 30,
                "alerts": ["Flash Flood Watch in effect until 8PM"]
            }
        except Exception as e:
            return {"error": "Weather data unavailable", "details": str(e)}
    
    async def get_environmental_data(self, location: str) -> Dict[str, Any]:
        """
        Get environmental hazard data for a location.
        
        Args:
            location: Location to get environmental data for
            
        Returns:
            Environmental hazard data for the location
        """
        # In a real implementation, this would query environmental hazard APIs
        # This is a simplified placeholder that returns mock data
        try:
            # Simulate API call (replace with actual API in production)
            return {
                "air_quality_index": 65,
                "water_safety": "Advisory in effect for municipal water",
                "hazardous_materials": ["Chemical plant release south of city", "Road closures on Highway 40"]
            }
        except Exception as e:
            return {"error": "Environmental data unavailable", "details": str(e)}
    
    def predict_crisis_evolution(self, crisis_type: str, severity: str, location: str) -> Dict[str, Any]:
        """
        Use machine learning to predict crisis evolution.
        
        Args:
            crisis_type: Type of crisis/disaster
            severity: Severity level (low, medium, high)
            location: Location of the crisis
            
        Returns:
            Prediction information
        """
        # If ML libraries are available and we have a model for this crisis type, use it
        if ML_AVAILABLE and crisis_type in self.models:
            # In a real implementation, this would use actual features
            # This is a simplified placeholder
            severity_value = {"low": 0, "medium": 1, "high": 2}.get(severity, 1)
            
            # Make prediction
            model = self.models[crisis_type]
            prediction = model.predict([[severity_value]])
            
            return {
                "expected_duration": f"{int(prediction[0])} hours",
                "trend": "worsening" if severity == "high" else "stabilizing",
                "confidence": 0.85,
                "next_48_hours": "Conditions expected to intensify before improving by Wednesday"
            }
        else:
            # Fallback predictions based on crisis type and severity
            if severity == "high":
                duration = "72 hours"
                trend = "worsening"
                confidence = 0.7
                forecast = "Conditions expected to worsen over the next 24-48 hours"
            elif severity == "medium":
                duration = "48 hours"
                trend = "stabilizing"
                confidence = 0.6
                forecast = "Conditions likely to stabilize within 24 hours"
            else:
                duration = "24 hours"
                trend = "improving"
                confidence = 0.8
                forecast = "Conditions expected to improve soon"
                
            # Crisis-specific adjustments
            if crisis_type in ["hurricane", "blizzard", "flood"]:
                duration = "96 hours"
                
            return {
                "expected_duration": duration,
                "trend": trend,
                "confidence": confidence,
                "next_48_hours": forecast
            }
    
    async def translate_text(self, text_list: List[str], target_language: str) -> List[str]:
        """
        Translate text into the target language.
        
        Args:
            text_list: List of texts to translate
            target_language: Target language code (e.g., 'es', 'fr')
            
        Returns:
            List of translated texts
        """
        if target_language == "en":  # No translation needed
            return text_list

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post("https://translation.googleapis.com/language/translate/v2", json={
                    "q": text_list,
                    "target": target_language,
                    "key": os.getenv("GOOGLE_TRANSLATE_API_KEY")
                }) as response:
                    data = await response.json()
                    return [item["translatedText"] for item in data["data"]["translations"]]
        except Exception:
            # Return original text if translation fails
            return text_list
    
    async def match_resources(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Match disaster resources based on user data.
        This is the main method for the AI-powered resource matching.
        
        Args:
            data: User and crisis data dictionary
            
        Returns:
            Dictionary of matched resources and related information
        """
        # Extract data
        location = data.get('location', '').strip().lower()
        crisis_type = data.get('crisis_type', '').strip().lower()
        user_needs = data.get('user_needs', [])
        severity = data.get('severity', 'medium').strip().lower()
        special_needs = data.get('special_needs', False)
        has_children = data.get('has_children', False)
        has_pets = data.get('has_pets', False)
        transportation = data.get('transportation', True)
        language = data.get('language', 'en')
        
        # Get basic resources for this crisis type
        matched_resources = self.resources.get(crisis_type, ["General Crisis Support"])
        
        # Add severity-specific resources
        if severity == 'high':
            matched_resources.append("Critical Emergency Response Team")
            matched_resources.append("Disaster Recovery Center")
            matched_resources.append("Emergency Medical Services")
        
        # Add special needs resources
        if special_needs:
            matched_resources.append("Accessible Transportation Services")
            matched_resources.append("Medical Equipment Resources")
            matched_resources.append("Disability Support Services")
            matched_resources.append("Assisted Evacuation Services")
        
        # Add child-specific resources
        if has_children:
            matched_resources.append("Child-Friendly Shelters")
            matched_resources.append("Family Reunification Services")
            matched_resources.append("Pediatric Medical Support")
            matched_resources.append("Child Care Services")
        
        # Add pet-specific resources
        if has_pets:
            matched_resources.append("Pet-Friendly Shelters")
            matched_resources.append("Animal Rescue Services")
            matched_resources.append("Veterinary Emergency Services")
            matched_resources.append("Pet Supply Distribution")
        
        # Add transportation-specific resources
        if not transportation:
            matched_resources.append("Emergency Transportation Services")
            matched_resources.append("Evacuation Assistance")
            matched_resources.append("Carpool Coordination")
        
        # Filter based on specific user needs
        if user_needs:
            all_resources = matched_resources.copy()
            filtered_resources = [res for res in all_resources if any(need.lower() in res.lower() for need in user_needs)]
            if filtered_resources:
                # Keep the filtered resources, but also maintain critical resources regardless of filtering
                critical_resources = [res for res in all_resources if "Emergency" in res or "Critical" in res]
                matched_resources = list(set(filtered_resources + critical_resources))
        
        # Get external data concurrently
        external_data_tasks = [
            self.get_external_api_data(FEMA_API_URL),
            self.get_external_api_data(RED_CROSS_API_URL),
            self.get_external_api_data(WHO_CRISIS_API),
            self.get_weather_data(location),
            self.get_environmental_data(location)
        ]
        
        fema_data, red_cross_data, who_data, weather_data, environmental_data = await asyncio.gather(*external_data_tasks)
        
        # Get safety instructions and translate if needed
        safety_instructions = self.get_safety_instructions(crisis_type, severity)
        
        # Get crisis prediction
        crisis_prediction = self.predict_crisis_evolution(crisis_type, severity, location)
        
        # Get evacuation routes and emergency contacts
        evacuation_routes = self.get_evacuation_routes(location, crisis_type)
        emergency_contacts = self.get_emergency_contacts(location)
        
        # Translate resources if needed
        if language != 'en':
            matched_resources = await self.translate_text(matched_resources, language)
            safety_instructions = await self.translate_text(safety_instructions, language)
        
        # Prepare response
        response = {
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "location": location,
            "crisis_type": crisis_type,
            "severity": severity,
            "matched_resources": matched_resources,
            "real_time_data": {
                "FEMA": fema_data.get("DisasterDeclarationsSummaries", [])[:3],
                "RedCross": red_cross_data.get("relief_efforts", [])[:3],
                "WHO": who_data.get("emergency_responses", [])[:3]
            },
            "weather_data": weather_data,
            "environmental_data": environmental_data,
            "safety_instructions": safety_instructions,
            "crisis_prediction": crisis_prediction,
            "evacuation_routes": evacuation_routes,
            "emergency_contacts": emergency_contacts
        }
        
        # Add crowdsourced reports if they were fetched from Firebase
        if 'crowdsourced_reports' in data:
            response["crowdsourced_reports"] = data.get("crowdsourced_reports", [])[:5]
        
        return response


# Initialize a global instance of the resource manager
resource_manager = DisasterResourceManager()


# External functions that can be imported by other modules
async def match_resources(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Match resources based on user data.
    This is the main function that can be imported by other modules.
    
    Args:
        data: User and crisis data
        
    Returns:
        Matched resources and related information
    """
    return await resource_manager.match_resources(data)


def get_safety_instructions(crisis_type: str, severity: str = "medium") -> List[str]:
    """
    Get safety instructions based on crisis type and severity.
    
    Args:
        crisis_type: Type of crisis/disaster
        severity: Severity level (low, medium, high)
        
    Returns:
        List of safety instructions
    """
    return resource_manager.get_safety_instructions(crisis_type, severity)


def get_evacuation_routes(location: str, crisis_type: str) -> Dict[str, str]:
    """
    Get evacuation routes based on location and crisis type.
    
    Args:
        location: User's location
        crisis_type: Type of crisis/disaster
        
    Returns:
        Dictionary of evacuation routes
    """
    return resource_manager.get_evacuation_routes(location, crisis_type)


def get_emergency_contacts(location: str) -> Dict[str, str]:
    """
    Get emergency contacts based on location.
    
    Args:
        location: User's location
        
    Returns:
        Dictionary of emergency contact information
    """
    return resource_manager.get_emergency_contacts(location)


async def translate_text(text_list: List[str], target_language: str) -> List[str]:
    """
    Translate text into the target language.
    
    Args:
        text_list: List of texts to translate
        target_language: Target language code
        
    Returns:
        List of translated texts
    """
    return await resource_manager.translate_text(text_list, target_language)