from flask import Blueprint, jsonify, request
import aiohttp
import os
import datetime

resources_bp = Blueprint('resources', __name__)

FEMA_API_URL = "https://www.fema.gov/api/open/v1/DisasterDeclarationsSummaries"
RED_CROSS_API_URL = "https://api.redcross.org/disaster_relief"
WHO_CRISIS_API = "https://who.int/emergency/api"

async def fetch_api_data(url):
    """Fetches data from an external API."""
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url) as response:
                response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
                return await response.json()
        except aiohttp.ClientError as e:
            return {"error": f"Failed to fetch data from {url}: {str(e)}"}
        except Exception as e:
            return {"error": f"An unexpected error occurred: {str(e)}"}

async def translate_text(text_list, target_language):
    """AI-powered translation function."""
    if target_language == "en":
        return text_list

    async with aiohttp.ClientSession() as session:
        try:
            async with session.post("https://translation.googleapis.com/language/translate/v2", json={
                "q": text_list,
                "target": target_language,
                "key": os.getenv("GOOGLE_TRANSLATE_API_KEY")
            }) as response:
                response.raise_for_status()
                data = await response.json()
                return [item["translatedText"] for item in data["data"]["translations"]]
        except aiohttp.ClientError as e:
            return {"error": f"Translation failed: {str(e)}"}
        except Exception as e:
            return {"error": f"Translation failed: An unexpected error occurred: {str(e)}"}

@resources_bp.route('/fema', methods=['GET'])
async def get_fema_data():
    """Retrieves FEMA disaster declaration summaries."""
    fema_data = await fetch_api_data(FEMA_API_URL)
    if "error" in fema_data:
        return jsonify(fema_data), 500
    return jsonify(fema_data), 200

@resources_bp.route('/redcross', methods=['GET'])
async def get_redcross_data():
    """Retrieves Red Cross disaster relief data."""
    redcross_data = await fetch_api_data(RED_CROSS_API_URL)
    if "error" in redcross_data:
        return jsonify(redcross_data), 500
    return jsonify(redcross_data), 200

@resources_bp.route('/who', methods=['GET'])
async def get_who_data():
    """Retrieves WHO emergency response data."""
    who_data = await fetch_api_data(WHO_CRISIS_API)
    if "error" in who_data:
        return jsonify(who_data), 500
    return jsonify(who_data), 200

@resources_bp.route('/match_resources', methods=['POST'])
async def match_resources():
    """Matches resources based on location, crisis type, and user needs."""
    data = request.json
    location = data.get('location', '').strip().lower()
    crisis_type = data.get('crisis_type', '').strip().lower()
    user_needs = data.get('user_needs', [])
    language = data.get("language", "en")

    if not location or not crisis_type:
        return jsonify({"error": "Location and crisis type are required."}), 400

    fema_data = await fetch_api_data(FEMA_API_URL)
    redcross_data = await fetch_api_data(RED_CROSS_API_URL)
    who_data = await fetch_api_data(WHO_CRISIS_API)

    if "error" in fema_data or "error" in redcross_data or "error" in who_data:
        return jsonify({"error": "Failed to retrieve external crisis data"}), 500

    resources = {
        "hurricane": ["Emergency Shelters", "Food Banks", "Medical Aid", "Evacuation Centers", "Emergency Hotlines"],
        "wildfire": ["Evacuation Centers", "Fire Updates", "Volunteer Support", "Air Quality Alerts"],
        "earthquake": ["Rescue Operations", "Temporary Housing", "Emergency Health Clinics", "Food Assistance"],
        "pandemic": ["COVID-19 Testing Sites", "Mental Health Support", "Online Medical Consultation", "Vaccine Centers"],
        "flood": ["Flood Rescue Teams", "Evacuation Shelters", "Drinking Water Distribution", "Sanitation & Hygiene Kits"],
        "conflict": ["Refugee Assistance", "Crisis Counseling", "Security Alerts", "Humanitarian Aid Services"],
    }

    matched_resources = resources.get(crisis_type, ["General Crisis Support"])
    # Placeholder: Replace with actual database/Firebase retrieval logic
    user_location_reports = []  # replace with database logic.

    if user_location_reports:
        for report in user_location_reports:
            matched_resources.append(f"Crowdsourced Report: {report.get('description', 'Resource available')}")

    if user_needs:
        filtered_resources = [res for res in matched_resources if any(need.lower() in res.lower() for need in user_needs)]
        if filtered_resources:
            matched_resources = filtered_resources

    translated_resources = await translate_text(matched_resources, language)

    return jsonify({
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "location": location,
        "crisis_type": crisis_type,
        "matched_resources": translated_resources,
        "real_time_data": {
            "FEMA": fema_data.get("DisasterDeclarationsSummaries", [])[:3] if "DisasterDeclarationsSummaries" in fema_data else [],
            "RedCross": redcross_data.get("relief_efforts", [])[:3] if "relief_efforts" in redcross_data else [],
            "WHO": who_data.get("emergency_responses", [])[:3] if "emergency_responses" in who_data else [],
        },
        "crowdsourced_reports": user_location_reports[:3]
    }), 200