from flask import Blueprint, jsonify, session, request
from .base import db, User  # Import from base.py
import hashlib

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/check_auth', methods=['GET'])
def check_auth():
    """
    Checks if a user is authenticated (logged in).
    """
    user_id = session.get('user_id')
    if user_id:
        user = User.query.get(user_id)
        if user:
            return jsonify({
                "authenticated": True,
                "user_id": user.id,
                "role": user.role,
                "firstName": user.firstName,
                "lastName": user.lastName,
                "email": user.email,
            }), 200
        else:
            return jsonify({"authenticated": False, "message": "User not found"}), 404
    else:
        return jsonify({"authenticated": False, "message": "User not logged in"}), 401

@auth_bp.route('/change_password', methods=['POST'])
def change_password():
    """
    Allows a logged-in user to change their password.
    """
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401

    data = request.json
    old_password = data.get('old_password')
    new_password = data.get('new_password')

    if not old_password or not new_password:
        return jsonify({"message": "Old and new passwords are required"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    if not user.verify_password(old_password):
        return jsonify({"message": "Incorrect old password"}), 401

    if len(new_password) < 8 or not any(char.isdigit() for char in new_password) or not any(char.isalpha() for char in new_password):
        return jsonify({"message": "New password must be at least 8 characters with letters and numbers"}), 400

    user.set_password(new_password)
    db.session.commit()
    return jsonify({"message": "Password changed successfully"}), 200

@auth_bp.route('/update_profile', methods=['PUT'])
def update_profile():
    """
    Allows a logged-in user to update their profile information.
    """
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    data = request.json
    try:
        user.firstName = data.get('firstName', user.firstName)
        user.lastName = data.get('lastName', user.lastName)
        user.middleInitial = data.get('middleInitial', user.middleInitial)
        user.suffix = data.get('suffix', user.suffix)
        user.age = data.get('age', user.age)
        user.disability_status = data.get('disability_status', user.disability_status)
        user.health_issues = data.get('health_issues', user.health_issues)
        user.employment_status = data.get('employment_status', user.employment_status)
        user.location = data.get('location', user.location)
        user.city = data.get('city', user.city)
        user.state = data.get('state', user.state)
        user.zipcode = data.get('zipcode', user.zipcode)
        user.emergency_contact = data.get('emergency_contact', user.emergency_contact)
        user.marital_status = data.get('marital_status', user.marital_status)

        db.session.commit()
        return jsonify({"message": "Profile updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error updating profile: {str(e)}"}), 500