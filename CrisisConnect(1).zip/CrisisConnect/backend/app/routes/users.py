from flask import Blueprint, jsonify, request
from ..base import db, User  # Import from parent directory
import hashlib

users_bp = Blueprint('users', __name__)

@users_bp.route('/', methods=['GET'])
def get_all_users():
    """
    Retrieves a list of all users (admin-only).
    """
    # Placeholder: Implement admin role check
    # if not is_admin():
    #     return jsonify({"message": "Unauthorized"}), 403

    users = User.query.all()
    user_list = [{
        "id": user.id,
        "firstName": user.firstName,
        "lastName": user.lastName,
        "email": user.email,
        "role": user.role
    } for user in users]
    return jsonify(user_list), 200

@users_bp.route('/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """
    Retrieves a specific user's information (admin-only).
    """
    # Placeholder: Implement admin role check
    # if not is_admin():
    #     return jsonify({"message": "Unauthorized"}), 403

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404
    return jsonify({
        "id": user.id,
        "firstName": user.firstName,
        "lastName": user.lastName,
        "email": user.email,
        "role": user.role,
        "middleInitial": user.middleInitial,
        "suffix": user.suffix,
        "age": user.age,
        "disability_status": user.disability_status,
        "health_issues": user.health_issues,
        "employment_status": user.employment_status,
        "location": user.location,
        "city": user.city,
        "state": user.state,
        "zipcode": user.zipcode,
        "emergency_contact": user.emergency_contact,
        "marital_status": user.marital_status
    }), 200

@users_bp.route('/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    """
    Updates a specific user's information (admin-only).
    """
    # Placeholder: Implement admin role check
    # if not is_admin():
    #     return jsonify({"message": "Unauthorized"}), 403

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    data = request.json
    try:
        user.firstName = data.get('firstName', user.firstName)
        user.lastName = data.get('lastName', user.lastName)
        user.email = data.get('email', user.email)
        user.role = data.get('role', user.role)
        user.middleInitial = data.get('middleInitial', user.middleInitial)
        user.suffix = data.get('suffix', user.suffix)
        user.age = data.get('age', user.age)
        user.disability_status = data.get('disability_status', user.disability_status)
        user.health_issues = data.get('health_issues', user.health_issues)
        user.employment_status = data.get('employment_status', user.employment_status)
        user.location = data.get('location', user.location)
        user.city = data.get('city', user.city)
        user.state = data.get('state', user.state)
        user.zipcode = data.get('zipcode', user.zipcode)
        user.emergency_contact = data.get('emergency_contact', user.emergency_contact)
        user.marital_status = data.get('marital_status', user.marital_status)

        db.session.commit()
        return jsonify({"message": "User updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error updating user: {str(e)}"}), 500

@users_bp.route('/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    """
    Deletes a specific user (admin-only).
    """
    # Placeholder: Implement admin role check
    # if not is_admin():
    #     return jsonify({"message": "Unauthorized"}), 403

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    try:
        db.session.delete(user)
        db.session.commit()
        return jsonify({"message": "User deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error deleting user: {str(e)}"}), 500