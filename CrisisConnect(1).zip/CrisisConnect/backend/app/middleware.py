"""
middleware.py - Security middleware for CrisisConnect

This module provides middleware components for:
- Request validation
- Security header enforcement
- API key validation
- Request logging
- Response sanitization
- CORS policy enforcement
- Health check middleware
- Request size limiting

For use with both Flask and FastAPI applications.
"""

import time
import json
import logging
import os
import re
from functools import wraps
from typing import Dict, List, Callable, Any, Optional, Union

from flask import Flask, request, Response, g, jsonify
from werkzeug.datastructures import Headers
from werkzeug.exceptions import RequestEntityTooLarge
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response as StarletteResponse
from starlette.types import ASGIApp
from fastapi import FastAPI, Request as FastAPIRequest, Response as FastAPIResponse
from fastapi.responses import JSONResponse

# Import from security module
from utils.security import log_security_event, validate_ip, sanitize_input, verify_token

# Configure logging
logger = logging.getLogger(__name__)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Load environment variables or use defaults
API_KEYS = os.getenv("API_KEYS", "").split(",")
ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
MAX_CONTENT_LENGTH = int(os.getenv("MAX_CONTENT_LENGTH", "10485760"))  # 10MB default
HEALTH_CHECK_PATH = os.getenv("HEALTH_CHECK_PATH", "/health")
ENABLE_REQUEST_LOGGING = os.getenv("ENABLE_REQUEST_LOGGING", "True").lower() == "true"
SENSITIVE_HEADERS = ["Authorization", "Cookie", "Set-Cookie", "X-API-Key"]

###################
# Flask Middleware
###################

class FlaskMiddleware:
    """Base class for Flask middleware implementations"""
    
    def __init__(self, app: Flask):
        self.app = app
        self.init_app(app)
    
    def init_app(self, app: Flask):
        """Initialize the middleware with a Flask app"""
        pass


class SecurityHeadersMiddleware(FlaskMiddleware):
    """
    Middleware to add security headers to all responses.
    
    This adds headers like Content-Security-Policy, X-XSS-Protection,
    X-Content-Type-Options, etc. to all responses.
    """
    
    def init_app(self, app: Flask):
        @app.after_request
        def add_security_headers(response: Response) -> Response:
            """Add security headers to the response"""
            
            # Content Security Policy
            if not response.headers.get('Content-Security-Policy'):
                response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; frame-ancestors 'none'"
            
            # Prevent MIME type sniffing
            response.headers['X-Content-Type-Options'] = 'nosniff'
            
            # XSS Protection
            response.headers['X-XSS-Protection'] = '1; mode=block'
            
            # Prevent clickjacking
            response.headers['X-Frame-Options'] = 'DENY'
            
            # HTTP Strict Transport Security (HSTS)
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
            
            # Referrer Policy
            response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
            
            # Permissions Policy (formerly Feature Policy)
            response.headers['Permissions-Policy'] = 'geolocation=(), camera=(), microphone=()'
            
            return response


class RequestValidationMiddleware(FlaskMiddleware):
    """
    Middleware to validate incoming requests.
    
    This validates content type, origin, IP address, and other request properties
    to ensure they conform to security policies.
    """
    
    def __init__(self, app: Flask, allowed_content_types: Optional[List[str]] = None):
        self.allowed_content_types = allowed_content_types or [
            'application/json', 
            'application/x-www-form-urlencoded', 
            'multipart/form-data'
        ]
        super().__init__(app)
    
    def init_app(self, app: Flask):
        @app.before_request
        def validate_request() -> Optional[Response]:
            """Validate the incoming request"""
            
            # Skip validation for OPTIONS requests (pre-flight CORS)
            if request.method == 'OPTIONS':
                return None
            
            # Skip validation for the health check endpoint
            if request.path == HEALTH_CHECK_PATH:
                return None
            
            # Content type validation for POST, PUT, PATCH
            if request.method in ['POST', 'PUT', 'PATCH'] and request.content_type:
                # Extract the base content type (remove charset and boundary info)
                base_content_type = request.content_type.split(';')[0].strip()
                
                if base_content_type not in self.allowed_content_types:
                    log_security_event(
                        "invalid_content_type", 
                        {"content_type": base_content_type, "endpoint": request.path},
                        "warning"
                    )
                    return jsonify({
                        "message": "Invalid content type",
                        "allowed_types": self.allowed_content_types
                    }), 415
            
            # Check request size
            content_length = request.content_length or 0
            if content_length > MAX_CONTENT_LENGTH:
                log_security_event(
                    "request_too_large", 
                    {"content_length": content_length, "endpoint": request.path},
                    "warning"
                )
                return jsonify({
                    "message": "Request entity too large",
                    "max_size": MAX_CONTENT_LENGTH
                }), 413
            
            # Validate request data
            if request.is_json and request.json:
                # Example: Scan for SQL injection patterns
                sql_injection_pattern = re.compile(r"('(''|[^'])*')|(;)|(--)|(\/\*.*?\*\/)", re.IGNORECASE)
                
                for key, value in request.json.items():
                    if isinstance(value, str) and sql_injection_pattern.search(value):
                        log_security_event(
                            "possible_sql_injection", 
                            {"field": key, "endpoint": request.path},
                            "warning"
                        )
                        return jsonify({
                            "message": "Invalid input detected"
                        }), 400
            
            return None


class APIKeyMiddleware(FlaskMiddleware):
    """
    Middleware to validate API keys for API routes.
    
    This checks for a valid API key in the X-API-Key header for routes
    that require API authentication.
    """
    
    def __init__(self, app: Flask, api_prefix: str = '/api/'):
        self.api_prefix = api_prefix
        super().__init__(app)
    
    def init_app(self, app: Flask):
        @app.before_request
        def validate_api_key() -> Optional[Response]:
            """Validate API key for API routes"""
            
            # Skip validation for non-API routes
            if not request.path.startswith(self.api_prefix):
                return None
            
            # Skip validation for OPTIONS requests
            if request.method == 'OPTIONS':
                return None
            
            # Skip validation for the health check endpoint
            if request.path == HEALTH_CHECK_PATH:
                return None
            
            # Get API key from header
            api_key = request.headers.get('X-API-Key')
            
            # Check if API key is valid
            if not api_key or api_key not in API_KEYS:
                log_security_event(
                    "invalid_api_key", 
                    {"endpoint": request.path},
                    "warning"
                )
                return jsonify({
                    "message": "Invalid or missing API key"
                }), 401
            
            return None


class RequestLoggingMiddleware(FlaskMiddleware):
    """
    Middleware to log request details.
    
    This logs details about each request including method, path, status code,
    and response time.
    """
    
    def init_app(self, app: Flask):
        @app.before_request
        def log_request_start() -> None:
            """Log the start of a request and set the start time"""
            if not ENABLE_REQUEST_LOGGING:
                return
            
            g.start_time = time.time()
        
        @app.after_request
        def log_request_end(response: Response) -> Response:
            """Log the end of a request with details"""
            if not ENABLE_REQUEST_LOGGING:
                return response
            
            if hasattr(g, 'start_time'):
                duration = time.time() - g.start_time
                
                # Prepare log data, excluding sensitive information
                log_data = {
                    "method": request.method,
                    "path": request.path,
                    "status_code": response.status_code,
                    "duration_ms": round(duration * 1000, 2),
                    "ip": request.remote_addr,
                    "user_agent": request.user_agent.string if request.user_agent else None
                }
                
                # Log request details
                logger.info(f"Request: {json.dumps(log_data)}")
            
            return response


class CORSMiddleware(FlaskMiddleware):
    """
    Middleware to handle CORS (Cross-Origin Resource Sharing).
    
    This adds appropriate CORS headers to responses based on the configured
    allowed origins.
    """
    
    def __init__(self, app: Flask, allowed_origins: Optional[List[str]] = None):
        self.allowed_origins = allowed_origins or ALLOWED_ORIGINS
        super().__init__(app)
    
    def init_app(self, app: Flask):
        @app.after_request
        def add_cors_headers(response: Response) -> Response:
            """Add CORS headers to the response"""
            
            origin = request.headers.get('Origin')
            
            # If the origin is allowed or wildcard is enabled
            if origin in self.allowed_origins or '*' in self.allowed_origins:
                response.headers['Access-Control-Allow-Origin'] = origin or '*'
                response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
                response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-API-Key'
                response.headers['Access-Control-Allow-Credentials'] = 'true'
                response.headers['Access-Control-Max-Age'] = '3600'  # Cache preflight for 1 hour
            
            return response
        
        @app.route('/', defaults={'path': ''}, methods=['OPTIONS'])
        @app.route('/<path:path>', methods=['OPTIONS'])
        def handle_options(path: str) -> Response:
            """Handle OPTIONS requests for CORS preflight"""
            
            origin = request.headers.get('Origin')
            
            # Create a response
            response = app.response_class(
                response='',
                status=200
            )
            
            # Add CORS headers
            if origin in self.allowed_origins or '*' in self.allowed_origins:
                response.headers['Access-Control-Allow-Origin'] = origin or '*'
                response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
                response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-API-Key'
                response.headers['Access-Control-Allow-Credentials'] = 'true'
                response.headers['Access-Control-Max-Age'] = '3600'  # Cache preflight for 1 hour
            
            return response


class ResponseSanitizationMiddleware(FlaskMiddleware):
    """
    Middleware to sanitize response data.
    
    This sanitizes outgoing response data to prevent sensitive information
    leakage and other security issues.
    """
    
    def __init__(self, app: Flask, sensitive_fields: Optional[List[str]] = None):
        self.sensitive_fields = sensitive_fields or [
            'password', 'token', 'secret', 'key', 'auth', 'credit_card',
            'ssn', 'social_security', 'dob', 'birth_date', 'address'
        ]
        super().__init__(app)
    
    def init_app(self, app: Flask):
        @app.after_request
        def sanitize_response(response: Response) -> Response:
            """Sanitize the response data"""
            
            # Skip binary responses
            if response.content_type and not response.content_type.startswith('application/json'):
                return response
            
            try:
                # Check if the response has JSON data
                if hasattr(response, 'json') and callable(getattr(response, 'json')):
                    data = response.json
                else:
                    try:
                        data = json.loads(response.get_data(as_text=True))
                    except (ValueError, TypeError):
                        # Not JSON or empty response
                        return response
                
                # Recursively sanitize the data
                sanitized_data = self._sanitize_dict(data)
                
                # Replace response data with sanitized data
                response.set_data(json.dumps(sanitized_data))
                
            except Exception as e:
                logger.error(f"Error sanitizing response: {str(e)}")
            
            return response
    
    def _sanitize_dict(self, data: Any) -> Any:
        """Recursively sanitize a dictionary or list"""
        
        if isinstance(data, dict):
            sanitized = {}
            for key, value in data.items():
                # Check if this is a sensitive field
                if any(sensitive in key.lower() for sensitive in self.sensitive_fields):
                    # Redact sensitive data
                    sanitized[key] = "[REDACTED]"
                else:
                    # Recursively sanitize the value
                    sanitized[key] = self._sanitize_dict(value)
            return sanitized
        
        elif isinstance(data, list):
            return [self._sanitize_dict(item) for item in data]
        
        else:
            return data


class JWTAuthMiddleware(FlaskMiddleware):
    """
    Middleware to validate JWT tokens for authenticated routes.
    
    This checks for a valid JWT token in the Authorization header for routes
    that require authentication.
    """
    
    def __init__(self, app: Flask, exclude_paths: Optional[List[str]] = None):
        self.exclude_paths = exclude_paths or [
            '/login', '/register', '/login/', '/register/',
            '/health', '/docs', '/openapi.json', '/favicon.ico',
            '/static/', '/api/docs/', '/api/openapi.json'
        ]
        super().__init__(app)
    
    def init_app(self, app: Flask):
        @app.before_request
        def validate_jwt() -> Optional[Response]:
            """Validate JWT token for authenticated routes"""
            
            # Skip validation for excluded paths
            for path in self.exclude_paths:
                if request.path.startswith(path):
                    return None
            
            # Skip validation for OPTIONS requests
            if request.method == 'OPTIONS':
                return None
            
            # Get JWT token from header
            auth_header = request.headers.get('Authorization')
            
            if not auth_header or not auth_header.startswith('Bearer '):
                log_security_event(
                    "missing_jwt", 
                    {"endpoint": request.path},
                    "info"
                )
                return jsonify({
                    "message": "Missing or invalid authentication token"
                }), 401
            
            # Extract token
            token = auth_header.split('Bearer ')[1]
            
            try:
                # Verify token
                payload = verify_token(token)
                
                # Store user info in g for use in the view
                g.user_id = payload['sub']
                g.user_role = payload['role']
                
            except Exception as e:
                log_security_event(
                    "invalid_jwt", 
                    {"endpoint": request.path, "error": str(e)},
                    "warning"
                )
                return jsonify({
                    "message": "Invalid or expired authentication token"
                }), 401
            
            return None


###################
# FastAPI Middleware
###################

class HealthCheckMiddleware(BaseHTTPMiddleware):
    """
    Middleware for FastAPI health check endpoint.
    
    This adds a simple health check endpoint that returns a 200 OK response.
    """
    
    def __init__(self, app: ASGIApp, path: str = HEALTH_CHECK_PATH):
        super().__init__(app)
        self.path = path
    
    async def dispatch(self, request: Request, call_next):
        """Check if this is a health check request"""
        
        if request.url.path == self.path:
            # Return health check response
            return StarletteResponse(
                content=json.dumps({"status": "ok", "time": time.time()}),
                media_type="application/json",
                status_code=200
            )
        
        # Process regular request
        return await call_next(request)


class RequestSizeLimiterMiddleware(BaseHTTPMiddleware):
    """
    Middleware to limit the size of incoming requests.
    
    This prevents denial of service attacks by limiting the size of
    request bodies.
    """
    
    def __init__(self, app: ASGIApp, max_content_length: int = MAX_CONTENT_LENGTH):
        super().__init__(app)
        self.max_content_length = max_content_length
    
    async def dispatch(self, request: Request, call_next):
        """Check request size"""
        
        # Get content length
        content_length = request.headers.get('content-length')
        
        if content_length and int(content_length) > self.max_content_length:
            # Log the event
            log_security_event(
                "request_too_large", 
                {"content_length": content_length, "endpoint": request.url.path},
                "warning"
            )
            
            # Return error response
            return JSONResponse(
                content={
                    "message": "Request entity too large",
                    "max_size": self.max_content_length
                },
                status_code=413
            )
        
        # Process regular request
        return await call_next(request)


class FastAPIRequestValidationMiddleware(BaseHTTPMiddleware):
    """
    Middleware to validate incoming FastAPI requests.
    
    Similar to the Flask RequestValidationMiddleware but for FastAPI.
    """
    
    def __init__(self, app: ASGIApp, allowed_content_types: Optional[List[str]] = None):
        super().__init__(app)
        self.allowed_content_types = allowed_content_types or [
            'application/json', 
            'application/x-www-form-urlencoded', 
            'multipart/form-data'
        ]
    
    async def dispatch(self, request: Request, call_next):
        """Validate the incoming request"""
        
        # Skip validation for OPTIONS requests (pre-flight CORS)
        if request.method == 'OPTIONS':
            return await call_next(request)
        
        # Skip validation for the health check endpoint
        if request.url.path == HEALTH_CHECK_PATH:
            return await call_next(request)
        
        # Content type validation for POST, PUT, PATCH
        if request.method in ['POST', 'PUT', 'PATCH']:
            content_type = request.headers.get('content-type', '')
            
            # Extract the base content type (remove charset and boundary info)
            base_content_type = content_type.split(';')[0].strip()
            
            if base_content_type and base_content_type not in self.allowed_content_types:
                # Log the event
                log_security_event(
                    "invalid_content_type", 
                    {"content_type": base_content_type, "endpoint": request.url.path},
                    "warning"
                )
                
                # Return error response
                return JSONResponse(
                    content={
                        "message": "Invalid content type",
                        "allowed_types": self.allowed_content_types
                    },
                    status_code=415
                )
        
        # Process regular request
        return await call_next(request)


class FastAPIRequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Middleware to log request details for FastAPI.
    
    Similar to the Flask RequestLoggingMiddleware but for FastAPI.
    """
    
    async def dispatch(self, request: Request, call_next):
        """Log request details"""
        
        if not ENABLE_REQUEST_LOGGING:
            return await call_next(request)
        
        start_time = time.time()
        
        # Process the request
        response = await call_next(request)
        
        # Calculate duration
        duration = time.time() - start_time
        
        # Prepare log data, excluding sensitive information
        log_data = {
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "duration_ms": round(duration * 1000, 2),
            "ip": request.client.host if request.client else None,
            "user_agent": request.headers.get('user-agent')
        }
        
        # Log request details
        logger.info(f"Request: {json.dumps(log_data)}")
        
        return response


###################
# Helper Functions
###################

def apply_flask_middleware(app: Flask) -> None:
    """
    Apply all Flask middleware to an app.
    
    Args:
        app: The Flask app to apply middleware to
    """
    SecurityHeadersMiddleware(app)
    RequestValidationMiddleware(app)
    APIKeyMiddleware(app)
    RequestLoggingMiddleware(app)
    CORSMiddleware(app)
    ResponseSanitizationMiddleware(app)
    JWTAuthMiddleware(app)


def apply_fastapi_middleware(app: FastAPI) -> None:
    """
    Apply all FastAPI middleware to an app.
    
    Args:
        app: The FastAPI app to apply middleware to
    """
    app.add_middleware(HealthCheckMiddleware)
    app.add_middleware(RequestSizeLimiterMiddleware)
    app.add_middleware(FastAPIRequestValidationMiddleware)
    app.add_middleware(FastAPIRequestLoggingMiddleware)