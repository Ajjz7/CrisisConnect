import os
from dotenv import load_dotenv

# 🌍 Load Environment Variables
load_dotenv()

class Config:
    """Base configuration with secure, AI-powered, and scalable settings."""
    SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "supersecuresecretkey")
    SESSION_TYPE = 'filesystem'

    # 🛢️ Database Configuration
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "postgresql://username:password@localhost/crisisconnect")

    # 🌍 Firebase Configuration for Real-Time Crisis Tracking
    FIREBASE_CONFIG_PATH = os.getenv("FIREBASE_CONFIG_PATH", "firebase_config.json")
    FIREBASE_DB_URL = os.getenv("FIREBASE_DB_URL", "https://your-firebase-db.firebaseio.com")

    # 🔑 OAuth Social Login Credentials
    GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
    GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
    FACEBOOK_CLIENT_ID = os.getenv("FACEBOOK_CLIENT_ID")
    FACEBOOK_CLIENT_SECRET = os.getenv("FACEBOOK_CLIENT_SECRET")
    LINKEDIN_CLIENT_ID = os.getenv("LINKEDIN_CLIENT_ID")
    LINKEDIN_CLIENT_SECRET = os.getenv("LINKEDIN_CLIENT_SECRET")
    YAHOO_CLIENT_ID = os.getenv("YAHOO_CLIENT_ID")
    YAHOO_CLIENT_SECRET = os.getenv("YAHOO_CLIENT_SECRET")

    # 🤖 AI Services & OpenAI Integration
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    GOOGLE_TRANSLATE_API_KEY = os.getenv("GOOGLE_TRANSLATE_API_KEY")

    # 🔗 Blockchain & IPFS Configuration for Secure Data Backup
    BLOCKCHAIN_ENABLED = os.getenv("BLOCKCHAIN_ENABLED", "True") == "True"
    IPFS_NODE_ADDRESS = os.getenv("IPFS_NODE_ADDRESS", "/ip4/127.0.0.1/tcp/5001/http")

    # 🚨 AI-Powered Risk Prediction System
    AI_RISK_PREDICTION_API = os.getenv("AI_RISK_PREDICTION_API")

    # 📜 Compliance & Privacy Settings
    GDPR_COMPLIANT = True
    HIPAA_COMPLIANT = True

    # 🌍 Geofencing for Location-Based Alerts
    ENABLE_GEOFENCING = os.getenv("ENABLE_GEOFENCING", "True") == "True"

    # 🛡️ Quantum-Resistant Cryptography for Data Security
    QUANTUM_RESISTANT_ENCRYPTION = os.getenv("QUANTUM_RESISTANT_ENCRYPTION", "True") == "True"

    # 🔐 Zero-Trust Security Model for Authentication
    ZERO_TRUST_AUTHENTICATION = os.getenv("ZERO_TRUST_AUTHENTICATION", "True") == "True"

    # 📊 AI-Powered Anomaly Detection for Cybersecurity Threats
    AI_ANOMALY_DETECTION_API = os.getenv("AI_ANOMALY_DETECTION_API")

    # 🚑 AI-Powered Emergency Response Optimization
    AI_EMERGENCY_ROUTING_API = os.getenv("AI_EMERGENCY_ROUTING_API")

    # 📜 Logging Configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

class DevelopmentConfig(Config):
    """Development environment settings."""
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.getenv("DEV_DATABASE_URL", "postgresql://username:password@localhost/crisisconnect_dev")
    LOG_LEVEL = "DEBUG"

class TestingConfig(Config):
    """Testing environment settings."""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = os.getenv("TEST_DATABASE_URL", "sqlite:///test_crisisconnect.db")
    LOG_LEVEL = "WARNING"

class ProductionConfig(Config):
    """Production environment settings with security enhancements."""
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.getenv("PROD_DATABASE_URL", "postgresql://username:password@localhost/crisisconnect_prod")
    LOG_LEVEL = "ERROR"

# 🌎 Define Available Configurations
configurations = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig
}

# 🌍 Load Config Based on Environment
FLASK_ENV = os.getenv("FLASK_ENV", "development")
app_config = configurations.get(FLASK_ENV, DevelopmentConfig)
