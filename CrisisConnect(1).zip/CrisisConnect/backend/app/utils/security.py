"""
security.py - Security utility functions for CrisisConnect

This module provides security-related functionality including:
- JWT token generation and validation
- Password hashing and verification
- Role-based authorization
- Data encryption/decryption
- Input sanitization and validation
- Rate limiting
- Security logging
"""

import os
import jwt
import time
import hashlib
import logging
import secrets
import base64
import re
import ipaddress
import html
from datetime import datetime, timedelta
from functools import wraps
from typing import Dict, List, Optional, Union, Callable, Any

from flask import request, jsonify, session, g
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from werkzeug.security import generate_password_hash as werkzeug_generate_password_hash
from werkzeug.security import check_password_hash

# Configure logging
logger = logging.getLogger(__name__)
handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Load environment variables or use defaults
JWT_SECRET = os.getenv("JWT_SECRET_KEY", "supersecuresecretkey")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXPIRATION = int(os.getenv("JWT_EXPIRATION_SECONDS", "3600"))  # 1 hour default
PASSWORD_SALT = os.getenv("PASSWORD_SALT", "default_salt_change_in_production")
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", None)
RATE_LIMIT_ENABLED = os.getenv("RATE_LIMIT_ENABLED", "True").lower() == "true"
MAX_REQUESTS = int(os.getenv("RATE_LIMIT_MAX_REQUESTS", "100"))
RATE_LIMIT_WINDOW = int(os.getenv("RATE_LIMIT_WINDOW", "3600"))  # 1 hour default

# Generate encryption key if not provided
if not ENCRYPTION_KEY:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=PASSWORD_SALT.encode(),
        iterations=100000,
    )
    ENCRYPTION_KEY = base64.urlsafe_b64encode(kdf.derive(JWT_SECRET.encode()))

# Initialize the Fernet symmetric encryption
try:
    fernet = Fernet(ENCRYPTION_KEY)
except Exception as e:
    logger.error(f"Error initializing Fernet encryption: {str(e)}")
    # Generate a valid key as fallback
    fallback_key = Fernet.generate_key()
    fernet = Fernet(fallback_key)
    logger.warning("Using fallback encryption key")

# Rate limiting storage (in-memory for demonstration)
# In production, use Redis or another distributed cache
rate_limit_store = {}

# Security breach attempt tracking
security_breach_attempts = {}


def generate_password_hash(password: str) -> str:
    """
    Generate a secure hash of the password using Werkzeug's implementation.
    
    Args:
        password: The plaintext password to hash
        
    Returns:
        str: The secure hash of the password
    """
    return werkzeug_generate_password_hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    """
    Verify that a password matches the stored hash.
    
    Args:
        password: The plaintext password to check
        password_hash: The stored hash to compare against
        
    Returns:
        bool: True if the password matches, False otherwise
    """
    return check_password_hash(password_hash, password)


def generate_token(user_id: str, role: str, additional_claims: Optional[Dict] = None) -> str:
    """
    Generate a JWT token for a user.
    
    Args:
        user_id: The unique identifier for the user
        role: The role of the user (e.g., 'admin', 'responder', 'coordinator')
        additional_claims: Any additional data to include in the token
        
    Returns:
        str: The encoded JWT token
    """
    now = datetime.utcnow()
    
    # Create the token payload
    payload = {
        "sub": user_id,
        "role": role,
        "iat": now,
        "exp": now + timedelta(seconds=JWT_EXPIRATION)
    }
    
    # Add any additional claims
    if additional_claims:
        payload.update(additional_claims)
    
    # Generate the token
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    
    # Log token generation (without the actual token)
    logger.info(f"Generated token for user {user_id} with role {role}")
    
    return token


def verify_token(token: str) -> Dict:
    """
    Verify and decode a JWT token.
    
    Args:
        token: The JWT token to verify
        
    Returns:
        dict: The decoded token payload if valid
        
    Raises:
        jwt.InvalidTokenError: If the token is invalid
        jwt.ExpiredSignatureError: If the token has expired
    """
    try:
        # Decode and verify the token
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        
        # Log successful token verification
        logger.debug(f"Successfully verified token for user {payload.get('sub')}")
        
        return payload
    except jwt.ExpiredSignatureError:
        logger.warning(f"Expired token attempted to be used")
        raise
    except jwt.InvalidTokenError as e:
        logger.warning(f"Invalid token verification attempt: {str(e)}")
        raise


def role_required(roles: Union[str, List[str]]) -> Callable:
    """
    Decorator to require specific role(s) for access to a route.
    
    Args:
        roles: A role or list of roles that are allowed to access the route
        
    Returns:
        Callable: The decorated function
    """
    def decorator(f: Callable) -> Callable:
        @wraps(f)
        def decorated_function(*args: Any, **kwargs: Any) -> Any:
            # Check if user is logged in
            if 'user_id' not in session:
                return jsonify({"message": "Authentication required"}), 401
            
            # Get user info from session or database
            user_id = session.get('user_id')
            
            # In a real implementation, you would query the database
            # Here we're assuming the role is also stored in the session
            user_role = session.get('role', 'user')
            
            # Convert roles to list if it's a string
            allowed_roles = roles if isinstance(roles, list) else [roles]
            
            # Check if user's role is allowed
            if user_role not in allowed_roles:
                logger.warning(f"Unauthorized access attempt: User {user_id} with role {user_role} attempted to access a route requiring {allowed_roles}")
                return jsonify({"message": "Insufficient permissions"}), 403
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def encrypt_data(data: str) -> str:
    """
    Encrypt sensitive data using Fernet symmetric encryption.
    
    Args:
        data: The plaintext data to encrypt
        
    Returns:
        str: The encrypted data as a base64 string
    """
    try:
        # Convert to bytes if string
        if isinstance(data, str):
            data = data.encode()
        
        # Encrypt the data
        encrypted_data = fernet.encrypt(data)
        
        # Return as string
        return base64.urlsafe_b64encode(encrypted_data).decode()
    except Exception as e:
        logger.error(f"Encryption error: {str(e)}")
        return ""


def decrypt_data(encrypted_data: str) -> str:
    """
    Decrypt data that was encrypted with the encrypt_data function.
    
    Args:
        encrypted_data: The encrypted data as a base64 string
        
    Returns:
        str: The decrypted plaintext data
    """
    try:
        # Decode from base64 string
        data = base64.urlsafe_b64decode(encrypted_data)
        
        # Decrypt the data
        decrypted_data = fernet.decrypt(data)
        
        # Return as string
        return decrypted_data.decode()
    except Exception as e:
        logger.error(f"Decryption error: {str(e)}")
        return ""


def sanitize_input(input_data: str) -> str:
    """
    Sanitize user input to prevent XSS attacks.
    
    Args:
        input_data: The user input to sanitize
        
    Returns:
        str: The sanitized input
    """
    if not input_data:
        return ""
    
    # Escape HTML special characters
    return html.escape(input_data)


def validate_email(email: str) -> bool:
    """
    Validate email format.
    
    Args:
        email: The email address to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    if not email:
        return False
    
    # Basic email regex pattern
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_password_strength(password: str) -> bool:
    """
    Validate password strength.
    
    Args:
        password: The password to validate
        
    Returns:
        bool: True if strong enough, False otherwise
    """
    if not password:
        return False
    
    # Check length
    if len(password) < 8:
        return False
    
    # Check for at least one letter and one number
    has_letter = False
    has_number = False
    
    for char in password:
        if char.isalpha():
            has_letter = True
        elif char.isdigit():
            has_number = True
    
    return has_letter and has_number


def validate_ip(ip: str) -> bool:
    """
    Validate if string is a valid IP address.
    
    Args:
        ip: The IP address to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False


def rate_limit(f: Callable) -> Callable:
    """
    Decorator to apply rate limiting to a route.
    
    Args:
        f: The function to decorate
        
    Returns:
        Callable: The decorated function
    """
    @wraps(f)
    def decorated_function(*args: Any, **kwargs: Any) -> Any:
        if not RATE_LIMIT_ENABLED:
            return f(*args, **kwargs)
        
        # Get client IP
        client_ip = request.remote_addr
        
        # Get current timestamp
        current_time = time.time()
        
        # Initialize or get client's request history
        if client_ip not in rate_limit_store:
            rate_limit_store[client_ip] = []
        
        # Remove requests outside the time window
        rate_limit_store[client_ip] = [t for t in rate_limit_store[client_ip] 
                                    if current_time - t < RATE_LIMIT_WINDOW]
        
        # Check if max requests exceeded
        if len(rate_limit_store[client_ip]) >= MAX_REQUESTS:
            logger.warning(f"Rate limit exceeded for IP: {client_ip}")
            return jsonify({"message": "Rate limit exceeded. Please try again later."}), 429
        
        # Add current request timestamp
        rate_limit_store[client_ip].append(current_time)
        
        # Call the original function
        return f(*args, **kwargs)
    
    return decorated_function


def log_security_event(event_type: str, details: Dict, severity: str = "info") -> None:
    """
    Log security-related events.
    
    Args:
        event_type: The type of security event
        details: Details about the event
        severity: The severity level (info, warning, error, critical)
    """
    log_data = {
        "timestamp": datetime.utcnow().isoformat(),
        "event_type": event_type,
        "details": details,
        "ip_address": request.remote_addr if request else "N/A",
        "user_agent": request.user_agent.string if request and request.user_agent else "N/A",
        "user_id": session.get("user_id") if session else "N/A"
    }
    
    # Log based on severity
    if severity == "warning":
        logger.warning(f"Security event: {log_data}")
    elif severity == "error":
        logger.error(f"Security event: {log_data}")
    elif severity == "critical":
        logger.critical(f"CRITICAL SECURITY EVENT: {log_data}")
    else:
        logger.info(f"Security event: {log_data}")


def monitor_for_breach_attempts(func: Callable) -> Callable:
    """
    Decorator to monitor and block potential security breach attempts.
    
    Args:
        func: The function to decorate
        
    Returns:
        Callable: The decorated function
    """
    @wraps(func)
    def decorated_function(*args: Any, **kwargs: Any) -> Any:
        client_ip = request.remote_addr
        
        # Initialize tracking for this IP if not exists
        if client_ip not in security_breach_attempts:
            security_breach_attempts[client_ip] = {
                "count": 0,
                "first_attempt": time.time(),
                "blocked_until": None
            }
        
        # Check if IP is blocked
        if (security_breach_attempts[client_ip]["blocked_until"] and 
            time.time() < security_breach_attempts[client_ip]["blocked_until"]):
            log_security_event(
                "blocked_access_attempt", 
                {"ip": client_ip, "endpoint": request.path},
                "warning"
            )
            return jsonify({"message": "Access temporarily blocked due to suspicious activity"}), 403
        
        # Reset counter if it's been a while since first attempt
        if time.time() - security_breach_attempts[client_ip]["first_attempt"] > 3600:  # 1 hour
            security_breach_attempts[client_ip] = {
                "count": 0,
                "first_attempt": time.time(),
                "blocked_until": None
            }
        
        # Try to execute the function
        try:
            return func(*args, **kwargs)
        except Exception as e:
            # Check if this looks like a security breach attempt
            if isinstance(e, (jwt.InvalidTokenError, jwt.ExpiredSignatureError)):
                security_breach_attempts[client_ip]["count"] += 1
                
                # Log the attempt
                log_security_event(
                    "potential_security_breach", 
                    {"ip": client_ip, "endpoint": request.path, "exception": str(e)},
                    "warning"
                )
                
                # Block IP if too many attempts
                if security_breach_attempts[client_ip]["count"] >= 5:
                    security_breach_attempts[client_ip]["blocked_until"] = time.time() + 1800  # 30 minutes
                    log_security_event(
                        "ip_blocked", 
                        {"ip": client_ip, "duration": "30 minutes", "reason": "Too many failed authentication attempts"},
                        "warning"
                    )
            
            # Re-raise the exception
            raise
            
    return decorated_function


def csrf_token() -> str:
    """
    Generate a CSRF token for form protection.
    
    Returns:
        str: A random token
    """
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    return session['csrf_token']


def verify_csrf_token(token: str) -> bool:
    """
    Verify that a CSRF token is valid.
    
    Args:
        token: The CSRF token to verify
        
    Returns:
        bool: True if valid, False otherwise
    """
    return token and token == session.get('csrf_token')


def check_csrf_token(func: Callable) -> Callable:
    """
    Decorator to check CSRF token for POST requests.
    
    Args:
        func: The function to decorate
        
    Returns:
        Callable: The decorated function
    """
    @wraps(func)
    def decorated_function(*args: Any, **kwargs: Any) -> Any:
        if request.method == 'POST':
            # Check for token in form data or headers
            token = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
            
            if not verify_csrf_token(token):
                log_security_event(
                    "csrf_validation_failure", 
                    {"ip": request.remote_addr, "endpoint": request.path},
                    "warning"
                )
                return jsonify({"message": "CSRF validation failed"}), 403
                
        return func(*args, **kwargs)
        
    return decorated_function


def requires_auth(func: Callable) -> Callable:
    """
    Decorator to require authentication for a route.
    
    Args:
        func: The function to decorate
        
    Returns:
        Callable: The decorated function
    """
    @wraps(func)
    def decorated_function(*args: Any, **kwargs: Any) -> Any:
        # Check if user is logged in
        if 'user_id' not in session:
            return jsonify({"message": "Authentication required"}), 401
        
        return func(*args, **kwargs)
        
    return decorated_function


def validate_crisis_report_data(data: Dict) -> Dict:
    """
    Validate and sanitize crisis report data.
    
    Args:
        data: The crisis report data to validate
        
    Returns:
        Dict: Dict containing validation result and errors if any
    """
    errors = []
    
    # Required fields
    required_fields = ["crisis_type", "description", "location"]
    for field in required_fields:
        if field not in data or not data[field]:
            errors.append(f"Field '{field}' is required")
    
    # Validate crisis_type
    valid_crisis_types = [
        "hurricane", "tornado", "blizzard", "heatwave", "drought",
        "earthquake", "tsunami", "landslide", "volcanic_eruption",
        "flood", "flash_flood", "dam_failure",
        "wildfire", "urban_fire",
        "pandemic", "epidemic", "biological_hazard",
        "chemical_spill", "radiation", "terrorism", "conflict", "infrastructure_failure"
    ]
    
    if "crisis_type" in data and data["crisis_type"] not in valid_crisis_types:
        errors.append(f"Invalid crisis type: {data['crisis_type']}")
    
    # Sanitize text fields
    if "description" in data:
        data["description"] = sanitize_input(data["description"])
    
    if "location" in data:
        data["location"] = sanitize_input(data["location"])
    
    # Validate coordinates if present
    if "coordinates" in data:
        try:
            lat = float(data["coordinates"]["latitude"])
            lng = float(data["coordinates"]["longitude"])
            
            if lat < -90 or lat > 90 or lng < -180 or lng > 180:
                errors.append("Invalid coordinates")
        except (ValueError, TypeError, KeyError):
            errors.append("Invalid coordinates format")
    
    # Return validation result
    if errors:
        return {
            "valid": False,
            "errors": errors,
            "data": data
        }
    else:
        return {
            "valid": True,
            "data": data
        }


def generate_2fa_code() -> str:
    """
    Generate a 6-digit 2FA code.
    
    Returns:
        str: The 6-digit code
    """
    return str(secrets.randbelow(1000000)).zfill(6)


def setup_security_headers(response):
    """
    Add security headers to a Flask response.
    
    Args:
        response: The Flask response object
        
    Returns:
        response: The modified response object
    """
    # Content Security Policy
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; frame-ancestors 'none'"
    
    # Prevent MIME type sniffing
    response.headers['X-Content-Type-Options'] = 'nosniff'
    
    # XSS Protection
    response.headers['X-XSS-Protection'] = '1; mode=block'
    
    # Prevent clickjacking
    response.headers['X-Frame-Options'] = 'DENY'
    
    # HTTP Strict Transport Security (HSTS)
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    
    # Referrer Policy
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    
    return response