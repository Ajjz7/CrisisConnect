import os
import re
import json
import hashlib
import logging
import datetime
import uuid
from typing import Dict, List, Any, Optional, Tuple, Union, Callable
import time
import asyncio
import traceback
import functools
import random

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Constants
DEFAULT_TIMEOUT = 30  # seconds
EXPONENTIAL_BACKOFF_MAX_RETRIES = 5
TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"
DEFAULT_CACHE_DURATION = 300  # seconds

# Simple in-memory cache
_cache = {}


def generate_id(prefix: str = "") -> str:
    """
    Generate a unique ID with an optional prefix.
    
    Args:
        prefix: Optional prefix for the ID
        
    Returns:
        Unique ID string
    """
    unique_id = str(uuid.uuid4())
    return f"{prefix}{unique_id}" if prefix else unique_id


def hash_data(data: Any) -> str:
    """
    Generate a hash of the provided data.
    
    Args:
        data: Data to hash
        
    Returns:
        Hash string
    """
    if isinstance(data, dict) or isinstance(data, list):
        # Convert to stable string representation for hashing
        data = json.dumps(data, sort_keys=True)
    
    if not isinstance(data, bytes):
        data = str(data).encode('utf-8')
    
    return hashlib.sha256(data).hexdigest()


def validate_email(email: str) -> bool:
    """
    Validate email format.
    
    Args:
        email: Email to validate
        
    Returns:
        True if valid, False otherwise
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_phone(phone: str) -> bool:
    """
    Validate phone number format.
    
    Args:
        phone: Phone number to validate
        
    Returns:
        True if valid, False otherwise
    """
    # Strip all non-numeric characters
    clean_phone = re.sub(r'\D', '', phone)
    
    # Check length (most countries have between 8 and 15 digits)
    return 8 <= len(clean_phone) <= 15


def format_phone(phone: str) -> str:
    """
    Format phone number to standard format.
    
    Args:
        phone: Phone number to format
        
    Returns:
        Formatted phone number
    """
    # Strip all non-numeric characters
    clean_phone = re.sub(r'\D', '', phone)
    
    # Format based on length
    if len(clean_phone) == 10:  # US format
        return f"({clean_phone[:3]}) {clean_phone[3:6]}-{clean_phone[6:]}"
    elif len(clean_phone) == 11 and clean_phone[0] == '1':  # US with country code
        return f"+1 ({clean_phone[1:4]}) {clean_phone[4:7]}-{clean_phone[7:]}"
    else:
        # Generic international format
        return f"+{clean_phone}"


def sanitize_input(text: str) -> str:
    """
    Sanitize user input to prevent XSS and injection attacks.
    
    Args:
        text: Text to sanitize
        
    Returns:
        Sanitized text
    """
    # Replace potentially dangerous characters
    sanitized = re.sub(r'[<>\'";]', '', text)
    
    # Limit length
    return sanitized[:2000]  # Arbitrary limit


def format_timestamp(timestamp: Union[datetime.datetime, float, str], format_str: Optional[str] = None) -> str:
    """
    Format a timestamp to a human-readable string.
    
    Args:
        timestamp: Timestamp to format (datetime, unix timestamp, or ISO string)
        format_str: Optional custom format string
        
    Returns:
        Formatted timestamp string
    """
    if isinstance(timestamp, float) or isinstance(timestamp, int):
        dt = datetime.datetime.fromtimestamp(timestamp)
    elif isinstance(timestamp, str):
        try:
            dt = datetime.datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        except ValueError:
            return timestamp  # Return original if parsing fails
    else:
        dt = timestamp
    
    format_str = format_str or TIMESTAMP_FORMAT
    return dt.strftime(format_str)


def time_since(timestamp: Union[datetime.datetime, float, str]) -> str:
    """
    Calculate time elapsed since a timestamp in human-readable format.
    
    Args:
        timestamp: Timestamp (datetime, unix timestamp, or ISO string)
        
    Returns:
        Human-readable time difference string
    """
    if isinstance(timestamp, float) or isinstance(timestamp, int):
        dt = datetime.datetime.fromtimestamp(timestamp)
    elif isinstance(timestamp, str):
        try:
            dt = datetime.datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        except ValueError:
            return "unknown time ago"  # Handle parsing failure
    else:
        dt = timestamp
    
    now = datetime.datetime.now()
    
    if dt > now:
        return "in the future"
    
    diff = now - dt
    
    # Calculate time difference components
    seconds = diff.total_seconds()
    minutes = seconds / 60
    hours = minutes / 60
    days = hours / 24
    
    # Format based on the largest time component
    if days >= 365:
        years = days / 365
        return f"{int(years)} year{'s' if years != 1 else ''} ago"
    elif days >= 30:
        months = days / 30
        return f"{int(months)} month{'s' if months != 1 else ''} ago"
    elif days >= 1:
        return f"{int(days)} day{'s' if days != 1 else ''} ago"
    elif hours >= 1:
        return f"{int(hours)} hour{'s' if hours != 1 else ''} ago"
    elif minutes >= 1:
        return f"{int(minutes)} minute{'s' if minutes != 1 else ''} ago"
    else:
        return "just now"


def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate text to a maximum length.
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        suffix: Suffix to add when truncated
        
    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def get_location_coordinates(location_name: str) -> Optional[Tuple[float, float]]:
    """
    Get latitude and longitude for a location name.
    
    Args:
        location_name: Name of location
        
    Returns:
        Tuple of (latitude, longitude) or None if not found
    """
    # This would use a geocoding service in production
    # For now, return mock data for common locations
    location_coordinates = {
        "new york": (40.7128, -74.0060),
        "los angeles": (34.0522, -118.2437),
        "chicago": (41.8781, -87.6298),
        "houston": (29.7604, -95.3698),
        "phoenix": (33.4484, -112.0740),
        "philadelphia": (39.9526, -75.1652),
        "san antonio": (29.4241, -98.4936),
        "san diego": (32.7157, -117.1611),
        "dallas": (32.7767, -96.7970),
        "san francisco": (37.7749, -122.4194)
    }
    
    # Check if location name exists in our mock database
    location_name_lower = location_name.lower()
    return location_coordinates.get(location_name_lower)


def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculate distance between two coordinates using the Haversine formula.
    
    Args:
        lat1: Latitude of first point
        lon1: Longitude of first point
        lat2: Latitude of second point
        lon2: Longitude of second point
        
    Returns:
        Distance in kilometers
    """
    from math import radians, sin, cos, sqrt, atan2
    
    # Earth radius in kilometers
    R = 6371.0
    
    # Convert to radians
    lat1_rad = radians(lat1)
    lon1_rad = radians(lon1)
    lat2_rad = radians(lat2)
    lon2_rad = radians(lon2)
    
    # Differences
    dlon = lon2_rad - lon1_rad
    dlat = lat2_rad - lat1_rad
    
    # Haversine formula
    a = sin(dlat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c
    
    return distance


def retry_with_backoff(func: Callable, max_retries: int = EXPONENTIAL_BACKOFF_MAX_RETRIES, 
                       base_delay: float = 0.5, max_delay: float = 30.0) -> Any:
    """
    Retry a function with exponential backoff.
    
    Args:
        func: Function to retry
        max_retries: Maximum number of retries
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        
    Returns:
        Result of the function call
    """
    retries = 0
    while True:
        try:
            return func()
        except Exception as e:
            retries += 1
            if retries > max_retries:
                logger.error(f"Maximum retries reached ({max_retries}). Last error: {str(e)}")
                raise
            
            # Calculate backoff delay
            delay = min(base_delay * (2 ** (retries - 1)), max_delay)
            # Add jitter (random delay between 0-100% of calculated delay)
            delay = delay * (0.5 + random.random())
            
            logger.warning(f"Retry {retries}/{max_retries} after {delay:.2f}s. Error: {str(e)}")
            time.sleep(delay)


async def async_retry_with_backoff(func: Callable, max_retries: int = EXPONENTIAL_BACKOFF_MAX_RETRIES, 
                                 base_delay: float = 0.5, max_delay: float = 30.0) -> Any:
    """
    Retry an async function with exponential backoff.
    
    Args:
        func: Async function to retry
        max_retries: Maximum number of retries
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        
    Returns:
        Result of the function call
    """
    retries = 0
    while True:
        try:
            return await func()
        except Exception as e:
            retries += 1
            if retries > max_retries:
                logger.error(f"Maximum retries reached ({max_retries}). Last error: {str(e)}")
                raise
            
            # Calculate backoff delay
            delay = min(base_delay * (2 ** (retries - 1)), max_delay)
            # Add jitter
            delay = delay * (0.5 + random.random())
            
            logger.warning(f"Async retry {retries}/{max_retries} after {delay:.2f}s. Error: {str(e)}")
            await asyncio.sleep(delay)


def timeit(func: Callable) -> Callable:
    """
    Decorator to measure function execution time.
    
    Args:
        func: Function to time
        
    Returns:
        Wrapped function
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        logger.debug(f"Function {func.__name__} took {end_time - start_time:.2f} seconds to run")
        return result
    return wrapper


async def async_timeit(func: Callable) -> Callable:
    """
    Decorator to measure async function execution time.
    
    Args:
        func: Async function to time
        
    Returns:
        Wrapped async function
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        start_time = time.time()
        result = await func(*args, **kwargs)
        end_time = time.time()
        logger.debug(f"Async function {func.__name__} took {end_time - start_time:.2f} seconds to run")
        return result
    return wrapper


def cache_result(ttl: int = DEFAULT_CACHE_DURATION) -> Callable:
    """
    Decorator to cache function results for a specified time-to-live.
    
    Args:
        ttl: Time-to-live in seconds
        
    Returns:
        Wrapped function
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create a cache key based on function name and arguments
            key_parts = [func.__name__]
            for arg in args:
                key_parts.append(str(arg))
            for k, v in sorted(kwargs.items()):
                key_parts.append(f"{k}={v}")
            cache_key = hash_data("".join(key_parts))
            
            # Check if result is in cache and not expired
            if cache_key in _cache:
                entry = _cache[cache_key]
                if time.time() - entry["timestamp"] < ttl:
                    return entry["result"]
            
            # Execute function and cache result
            result = func(*args, **kwargs)
            _cache[cache_key] = {
                "result": result,
                "timestamp": time.time()
            }
            
            return result
        return wrapper
    return decorator


async def async_cache_result(ttl: int = DEFAULT_CACHE_DURATION) -> Callable:
    """
    Decorator to cache async function results for a specified time-to-live.
    
    Args:
        ttl: Time-to-live in seconds
        
    Returns:
        Wrapped async function
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Create a cache key based on function name and arguments
            key_parts = [func.__name__]
            for arg in args:
                key_parts.append(str(arg))
            for k, v in sorted(kwargs.items()):
                key_parts.append(f"{k}={v}")
            cache_key = hash_data("".join(key_parts))
            
            # Check if result is in cache and not expired
            if cache_key in _cache:
                entry = _cache[cache_key]
                if time.time() - entry["timestamp"] < ttl:
                    return entry["result"]
            
            # Execute function and cache result
            result = await func(*args, **kwargs)
            _cache[cache_key] = {
                "result": result,
                "timestamp": time.time()
            }
            
            return result
        return wrapper
    return decorator


def clear_cache() -> None:
    """
    Clear the in-memory cache.
    """
    global _cache
    _cache = {}


def async_timeout(seconds: Union[int, float] = DEFAULT_TIMEOUT) -> Callable:
    """
    Decorator to add timeout to an async function.
    
    Args:
        seconds: Timeout in seconds
        
    Returns:
        Wrapped async function
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                return await asyncio.wait_for(func(*args, **kwargs), timeout=seconds)
            except asyncio.TimeoutError:
                logger.error(f"Function {func.__name__} timed out after {seconds} seconds")
                raise TimeoutError(f"Function {func.__name__} timed out after {seconds} seconds")
        return wrapper
    return decorator


def safe_execute(func: Callable, default_value: Any = None, log_error: bool = True) -> Any:
    """
    Safely execute a function, returning a default value if it fails.
    
    Args:
        func: Function to execute
        default_value: Value to return if function fails
        log_error: Whether to log errors
        
    Returns:
        Function result or default value
    """
    try:
        return func()
    except Exception as e:
        if log_error:
            logger.error(f"Error executing function: {str(e)}")
            logger.debug(traceback.format_exc())
        return default_value


async def safe_async_execute(func: Callable, default_value: Any = None, log_error: bool = True) -> Any:
    """
    Safely execute an async function, returning a default value if it fails.
    
    Args:
        func: Async function to execute
        default_value: Value to return if function fails
        log_error: Whether to log errors
        
    Returns:
        Function result or default value
    """
    try:
        return await func()
    except Exception as e:
        if log_error:
            logger.error(f"Error executing async function: {str(e)}")
            logger.debug(traceback.format_exc())
        return default_value


def load_json_file(filepath: str, default: Any = None) -> Any:
    """
    Load JSON data from a file.
    
    Args:
        filepath: Path to JSON file
        default: Default value if file does not exist or is invalid
        
    Returns:
        Loaded JSON data or default value
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning(f"Failed to load JSON from {filepath}: {str(e)}")
        return default


def save_json_file(data: Any, filepath: str, indent: int = 2) -> bool:
    """
    Save data to a JSON file.
    
    Args:
        data: Data to save
        filepath: Path to save JSON file
        indent: JSON indentation level
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Ensure directory exists
        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=indent)
        return True
    except Exception as e:
        logger.error(f"Failed to save JSON to {filepath}: {str(e)}")
        return False


def parse_bool(value: Any) -> bool:
    """
    Parse a boolean value from various input types.
    
    Args:
        value: Value to parse
        
    Returns:
        Parsed boolean
    """
    if isinstance(value, bool):
        return value
    
    if isinstance(value, (int, float)):
        return bool(value)
    
    if isinstance(value, str):
        value = value.lower().strip()
        if value in ('true', 'yes', 'y', '1', 't'):
            return True
        if value in ('false', 'no', 'n', '0', 'f'):
            return False
    
    # Default to False for any other type
    return False


def get_env_var(name: str, default: Any = None, type_cast: Callable = None) -> Any:
    """
    Get environment variable with type casting and default value.
    
    Args:
        name: Environment variable name
        default: Default value if not found
        type_cast: Function to cast the value (int, float, etc.)
        
    Returns:
        Environment variable value or default
    """
    value = os.environ.get(name)
    
    if value is None:
        return default
    
    if type_cast is not None:
        try:
            return type_cast(value)
        except (ValueError, TypeError):
            logger.warning(f"Failed to cast env var {name}={value} to {type_cast.__name__}, using default {default}")
            return default
    
    return value


def get_env_bool(name: str, default: bool = False) -> bool:
    """
    Get boolean environment variable.
    
    Args:
        name: Environment variable name
        default: Default value if not found
        
    Returns:
        Boolean value of environment variable
    """
    value = os.environ.get(name)
    
    if value is None:
        return default
    
    return parse_bool(value)


def normalize_phone_number(phone: str) -> str:
    """
    Normalize phone number to E.164 format.
    
    Args:
        phone: Phone number string
        
    Returns:
        Normalized phone number
    """
    # Remove all non-digit characters
    digits_only = re.sub(r'\D', '', phone)
    
    # Handle US numbers
    if len(digits_only) == 10:
        return f"+1{digits_only}"
    
    # Assume number already has country code
    if len(digits_only) > 10:
        # Add + if missing
        if digits_only.startswith('1'):
            return f"+{digits_only}"
        else:
            return f"+{digits_only}"
    
    # If too short, return original
    return phone


def slugify(text: str) -> str:
    """
    Convert text to URL-friendly slug.
    
    Args:
        text: Text to convert
        
    Returns:
        URL-friendly slug
    """
    # Convert to lowercase
    slug = text.lower()
    
    # Replace non-alphanumeric characters with hyphens
    slug = re.sub(r'[^a-z0-9]+', '-', slug)
    
    # Remove leading/trailing hyphens
    slug = slug.strip('-')
    
    return slug


def extract_urls(text: str) -> List[str]:
    """
    Extract URLs from text.
    
    Args:
        text: Text to extract URLs from
        
    Returns:
        List of extracted URLs
    """
    # URL regex pattern
    url_pattern = r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+'
    
    # Find all matches
    return re.findall(url_pattern, text)


def extract_hashtags(text: str) -> List[str]:
    """
    Extract hashtags from text.
    
    Args:
        text: Text to extract hashtags from
        
    Returns:
        List of extracted hashtags
    """
    # Hashtag regex pattern
    hashtag_pattern = r'#(\w+)'
    
    # Find all matches and remove the # prefix
    return re.findall(hashtag_pattern, text)


def extract_mentions(text: str) -> List[str]:
    """
    Extract mentions (@username) from text.
    
    Args:
        text: Text to extract mentions from
        
    Returns:
        List of extracted mentions
    """
    # Mention regex pattern
    mention_pattern = r'@(\w+)'
    
    # Find all matches and remove the @ prefix
    return re.findall(mention_pattern, text)


def create_thumbnail_filename(original_filename: str) -> str:
    """
    Create a thumbnail filename from an original filename.
    
    Args:
        original_filename: Original filename
        
    Returns:
        Thumbnail filename
    """
    name, ext = os.path.splitext(original_filename)
    return f"{name}_thumb{ext}"


def get_file_extension(filename: str) -> str:
    """
    Get the file extension from a filename.
    
    Args:
        filename: Filename
        
    Returns:
        File extension
    """
    return os.path.splitext(filename)[1].lower()


def is_image_file(filename: str) -> bool:
    """
    Check if a file is an image based on its extension.
    
    Args:
        filename: Filename
        
    Returns:
        True if file is an image, False otherwise
    """
    image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg'}
    return get_file_extension(filename) in image_extensions


def is_audio_file(filename: str) -> bool:
    """
    Check if a file is an audio file based on its extension.
    
    Args:
        filename: Filename
        
    Returns:
        True if file is an audio file, False otherwise
    """
    audio_extensions = {'.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a'}
    return get_file_extension(filename) in audio_extensions


def is_video_file(filename: str) -> bool:
    """
    Check if a file is a video file based on its extension.
    
    Args:
        filename: Filename
        
    Returns:
        True if file is a video file, False otherwise
    """
    video_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm', '.flv', '.wmv'}
    return get_file_extension(filename) in video_extensions


def generate_api_key(prefix: str = "api") -> str:
    """
    Generate a secure API key.
    
    Args:
        prefix: Prefix for the API key
        
    Returns:
        Secure API key
    """
    # Generate a random UUID
    random_id = uuid.uuid4().hex
    
    # Add timestamp hash for uniqueness
    timestamp = datetime.datetime.now().isoformat()
    timestamp_hash = hashlib.sha256(timestamp.encode()).hexdigest()[:8]
    
    return f"{prefix}_{random_id}_{timestamp_hash}"


def estimate_reading_time(text: str, words_per_minute: int = 200) -> int:
    """
    Estimate reading time in minutes for a text.
    
    Args:
        text: Text to estimate reading time for
        words_per_minute: Reading speed in words per minute
        
    Returns:
        Estimated reading time in minutes
    """
    # Count words
    word_count = len(text.split())
    
    # Calculate reading time
    minutes = word_count / words_per_minute
    
    # Round up to nearest minute
    return max(1, int(minutes + 0.5))


def format_number(number: Union[int, float], precision: int = 1) -> str:
    """
    Format a number with abbreviations for thousands, millions, etc.
    
    Args:
        number: Number to format
        precision: Number of decimal places
        
    Returns:
        Formatted number string
    """
    if number is None:
        return "0"
        
    if number < 1000:
        return str(number)
        
    for unit in ['', 'K', 'M', 'B', 'T']:
        if abs(number) < 1000:
            return f"{number:.{precision}f}{unit}".rstrip('0').rstrip('.') if precision > 0 else f"{int(number)}{unit}"
        number /= 1000
    
    return f"{number:.{precision}f}P".rstrip('0').rstrip('.') if precision > 0 else f"{int(number)}P"


def get_severity_color(severity: str) -> str:
    """
    Get a color code for a severity level.
    
    Args:
        severity: Severity level (low, medium, high, critical)
        
    Returns:
        Color code
    """
    severity_colors = {
        "low": "#4CAF50",      # Green
        "medium": "#FFC107",   # Amber
        "high": "#FF9800",     # Orange
        "critical": "#F44336"  # Red
    }
    
    return severity_colors.get(severity.lower(), "#2196F3")  # Default: Blue


def parse_iso_timestamp(timestamp: str) -> Optional[datetime.datetime]:
    """
    Parse an ISO 8601 timestamp string to a datetime object.
    
    Args:
        timestamp: ISO 8601 timestamp string
        
    Returns:
        datetime object or None if parsing fails
    """
    try:
        return datetime.datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
    except (ValueError, AttributeError):
        return None


def format_file_size(size_bytes: int) -> str:
    """
    Format a file size in bytes to a human-readable string.
    
    Args:
        size_bytes: File size in bytes
        
    Returns:
        Human-readable file size
    """
    if size_bytes < 1024:
        return f"{size_bytes} bytes"
    
    size_kb = size_bytes / 1024
    if size_kb < 1024:
        return f"{size_kb:.1f} KB"
    
    size_mb = size_kb / 1024
    if size_mb < 1024:
        return f"{size_mb:.1f} MB"
    
    size_gb = size_mb / 1024
    return f"{size_gb:.2f} GB"


def replace_placeholders(template: str, data: Dict[str, Any]) -> str:
    """
    Replace placeholders in a template string with values from a dictionary.
    
    Args:
        template: Template string with {placeholder} placeholders
        data: Dictionary with placeholder values
        
    Returns:
        String with placeholders replaced
    """
    try:
        return template.format(**data)
    except KeyError as e:
        logger.warning(f"Missing placeholder in template: {e}")
        return template


def is_valid_url(url: str) -> bool:
    """
    Check if a string is a valid URL.
    
    Args:
        url: URL string to check
        
    Returns:
        True if valid URL, False otherwise
    """
    pattern = r'^https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+'
    return bool(re.match(pattern, url))


def get_domain_from_url(url: str) -> Optional[str]:
    """
    Extract domain from URL.
    
    Args:
        url: URL to extract domain from
        
    Returns:
        Domain string or None if invalid URL
    """
    if not is_valid_url(url):
        return None
    
    # Extract domain part using regex
    domain_match = re.search(r'https?://([^/]+)', url)
    if domain_match:
        return domain_match.group(1)
    
    return None


def chunks(lst: List[Any], n: int) -> List[List[Any]]:
    """
    Split a list into chunks of size n.
    
    Args:
        lst: List to split
        n: Chunk size
        
    Returns:
        List of list chunks
    """
    return [lst[i:i + n] for i in range(0, len(lst), n)]


def find_mentions_in_text(text: str, prefix: str = "@") -> List[str]:
    """
    Find all mentions in a text (e.g., @username).
    
    Args:
        text: Text to search
        prefix: Mention prefix
        
    Returns:
        List of mentioned usernames
    """
    pattern = f"{re.escape(prefix)}([a-zA-Z0-9_]+)"
    return re.findall(pattern, text)


def secure_random_string(length: int = 32) -> str:
    """
    Generate a secure random string.
    
    Args:
        length: Length of the string
        
    Returns:
        Random string
    """
    import secrets
    import string
    
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def deep_get(dictionary: Dict[str, Any], keys: Union[str, List[str]], default: Any = None) -> Any:
    """
    Safely get a value from a nested dictionary using dot notation.
    
    Args:
        dictionary: Dictionary to get value from
        keys: Key path (e.g., 'level1.level2.key' or ['level1', 'level2', 'key'])
        default: Default value if key not found
        
    Returns:
        Value at key path or default
    """
    if isinstance(keys, str):
        keys = keys.split('.')
    
    temp_dict = dictionary
    for key in keys:
        if isinstance(temp_dict, dict) and key in temp_dict:
            temp_dict = temp_dict[key]
        else:
            return default
    
    return temp_dict


def deep_set(dictionary: Dict[str, Any], keys: Union[str, List[str]], value: Any) -> Dict[str, Any]:
    """
    Set a value in a nested dictionary using dot notation.
    
    Args:
        dictionary: Dictionary to set value in
        keys: Key path (e.g., 'level1.level2.key' or ['level1', 'level2', 'key'])
        value: Value to set
        
    Returns:
        Updated dictionary
    """
    if isinstance(keys, str):
        keys = keys.split('.')
    
    if not keys:
        return value
    
    # Create a reference to the original dictionary
    current = dictionary
    
    # Traverse the dictionary, creating nested dictionaries as needed
    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]
    
    # Set the value at the final key
    current[keys[-1]] = value
    
    return dictionary


def deep_merge(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deep merge two dictionaries, with dict2 values taking precedence.
    
    Args:
        dict1: First dictionary
        dict2: Second dictionary (overrides dict1 values)
        
    Returns:
        Merged dictionary
    """
    result = dict1.copy()
    
    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            # Recursively merge nested dictionaries
            result[key] = deep_merge(result[key], value)
        else:
            # Override or add the value
            result[key] = value
    
    return result


def flatten_dict(dictionary: Dict[str, Any], separator: str = '.', prefix: str = '') -> Dict[str, Any]:
    """
    Flatten a nested dictionary into a flat dictionary with keys joined by separator.
    
    Args:
        dictionary: Nested dictionary
        separator: Key separator
        prefix: Key prefix
        
    Returns:
        Flattened dictionary
    """
    result = {}
    
    for key, value in dictionary.items():
        new_key = f"{prefix}{separator}{key}" if prefix else key
        
        if isinstance(value, dict):
            # Recursively flatten nested dictionaries
            nested = flatten_dict(value, separator, new_key)
            result.update(nested)
        else:
            # Add the value with the new key
            result[new_key] = value
    
    return result


def unflatten_dict(dictionary: Dict[str, Any], separator: str = '.') -> Dict[str, Any]:
    """
    Convert a flattened dictionary back to a nested dictionary.
    
    Args:
        dictionary: Flattened dictionary
        separator: Key separator
        
    Returns:
        Nested dictionary
    """
    result = {}
    
    for key, value in dictionary.items():
        deep_set(result, key.split(separator), value)
    
    return result


def group_by(items: List[Dict[str, Any]], key: str) -> Dict[str, List[Dict[str, Any]]]:
    """
    Group a list of dictionaries by a key.
    
    Args:
        items: List of dictionaries
        key: Key to group by
        
    Returns:
        Dictionary of grouped items
    """
    result = {}
    
    for item in items:
        if key in item:
            group_value = item[key]
            if group_value not in result:
                result[group_value] = []
            result[group_value].append(item)
    
    return result


def group_by_lambda(items: List[Any], key_func: Callable[[Any], Any]) -> Dict[Any, List[Any]]:
    """
    Group a list of items by a key function.
    
    Args:
        items: List of items
        key_func: Function to extract the key from an item
        
    Returns:
        Dictionary of grouped items
    """
    result = {}
    
    for item in items:
        group_value = key_func(item)
        if group_value not in result:
            result[group_value] = []
        result[group_value].append(item)
    
    return result


def to_camel_case(snake_str: str) -> str:
    """
    Convert snake_case to camelCase.
    
    Args:
        snake_str: snake_case string
        
    Returns:
        camelCase string
    """
    components = snake_str.split('_')
    return components[0] + ''.join(x.title() for x in components[1:])


def to_snake_case(camel_str: str) -> str:
    """
    Convert camelCase to snake_case.
    
    Args:
        camel_str: camelCase string
        
    Returns:
        snake_case string
    """
    # Handle first capital letter
    if camel_str and camel_str[0].isupper():
        camel_str = camel_str[0].lower() + camel_str[1:]
    
    # Insert underscore before uppercase letters
    snake_str = re.sub(r'(?<!^)(?=[A-Z])', '_', camel_str).lower()
    
    return snake_str


def keys_to_camel_case(data: Any) -> Any:
    """
    Recursively convert dictionary keys from snake_case to camelCase.
    
    Args:
        data: Data structure with dictionary keys
        
    Returns:
        Data structure with camelCase keys
    """
    if isinstance(data, dict):
        return {to_camel_case(k): keys_to_camel_case(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [keys_to_camel_case(item) for item in data]
    else:
        return data


def keys_to_snake_case(data: Any) -> Any:
    """
    Recursively convert dictionary keys from camelCase to snake_case.
    
    Args:
        data: Data structure with dictionary keys
        
    Returns:
        Data structure with snake_case keys
    """
    if isinstance(data, dict):
        return {to_snake_case(k): keys_to_snake_case(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [keys_to_snake_case(item) for item in data]
    else:
        return data


def encrypt_string(text: str, key: str) -> str:
    """
    Simple encryption of a string (not for sensitive data).
    
    Args:
        text: Text to encrypt
        key: Encryption key
        
    Returns:
        Encrypted string (base64)
    """
    import base64
    
    # Create a deterministic key from the provided key
    key_hash = hashlib.sha256(key.encode()).digest()
    
    # XOR encryption
    encrypted = bytearray()
    text_bytes = text.encode()
    
    for i in range(len(text_bytes)):
        encrypted.append(text_bytes[i] ^ key_hash[i % len(key_hash)])
    
    # Encode to base64
    return base64.b64encode(encrypted).decode()


def decrypt_string(encrypted_text: str, key: str) -> str:
    """
    Simple decryption of a string (not for sensitive data).
    
    Args:
        encrypted_text: Encrypted text (base64)
        key: Decryption key
        
    Returns:
        Decrypted string
    """
    import base64
    
    try:
        # Create a deterministic key from the provided key
        key_hash = hashlib.sha256(key.encode()).digest()
        
        # Decode from base64
        encrypted = base64.b64decode(encrypted_text)
        
        # XOR decryption
        decrypted = bytearray()
        
        for i in range(len(encrypted)):
            decrypted.append(encrypted[i] ^ key_hash[i % len(key_hash)])
        
        return decrypted.decode()
    except Exception as e:
        logger.error(f"Failed to decrypt string: {str(e)}")
        return ""


def parse_duration(duration_str: str) -> Optional[int]:
    """
    Parse a duration string (e.g., '1h 30m') to seconds.
    
    Args:
        duration_str: Duration string
        
    Returns:
        Duration in seconds or None if invalid
    """
    if not duration_str:
        return None
    
    total_seconds = 0
    
    # Regular expression to match numbers followed by time units
    pattern = r'(\d+)\s*([wdhms])'
    matches = re.findall(pattern, duration_str.lower())
    
    if not matches:
        try:
            # Try to parse as a plain number of seconds
            return int(duration_str)
        except ValueError:
            return None
    
    for value, unit in matches:
        value = int(value)
        
        if unit == 'w':  # Week
            total_seconds += value * 7 * 24 * 60 * 60
        elif unit == 'd':  # Day
            total_seconds += value * 24 * 60 * 60
        elif unit == 'h':  # Hour
            total_seconds += value * 60 * 60
        elif unit == 'm':  # Minute
            total_seconds += value * 60
        elif unit == 's':  # Second
            total_seconds += value
    
    return total_seconds


def format_duration(seconds: int) -> str:
    """
    Format seconds to a duration string (e.g., '1h 30m').
    
    Args:
        seconds: Duration in seconds
        
    Returns:
        Formatted duration string
    """
    if seconds < 60:
        return f"{seconds}s"
    
    minutes, seconds = divmod(seconds, 60)
    if minutes < 60:
        if seconds == 0:
            return f"{minutes}m"
        return f"{minutes}m {seconds}s"
    
    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        if minutes == 0:
            return f"{hours}h"
        return f"{hours}h {minutes}m"
    
    days, hours = divmod(hours, 24)
    if days < 7:
        if hours == 0:
            return f"{days}d"
        return f"{days}d {hours}h"
    
    weeks, days = divmod(days, 7)
    if days == 0:
        return f"{weeks}w"
    return f"{weeks}w {days}d"


def format_list_to_string(items: List[str], conjunction: str = "and") -> str:
    """
    Format a list of items into a natural language string.
    
    Args:
        items: List of items
        conjunction: Conjunction to use (and, or)
        
    Returns:
        Formatted string
    """
    if not items:
        return ""
    
    if len(items) == 1:
        return items[0]
    
    if len(items) == 2:
        return f"{items[0]} {conjunction} {items[1]}"
    
    return ", ".join(items[:-1]) + f", {conjunction} {items[-1]}"


def escape_html(text: str) -> str:
    """
    Escape HTML special characters.
    
    Args:
        text: Text to escape
        
    Returns:
        Escaped HTML
    """
    html_escape_table = {
        "&": "&amp;",
        '"': "&quot;",
        "'": "&apos;",
        ">": "&gt;",
        "<": "&lt;",
    }
    
    return "".join(html_escape_table.get(c, c) for c in text)


def levenshtein_distance(s1: str, s2: str) -> int:
    """
    Calculate the Levenshtein distance between two strings.
    
    Args:
        s1: First string
        s2: Second string
        
    Returns:
        Levenshtein distance
    """
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    
    # len(s1) >= len(s2)
    if not s2:
        return len(s1)
    
    previous_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            # Calculate cost
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            
            # Get minimum
            current_row.append(min(insertions, deletions, substitutions))
        
        previous_row = current_row
    
    return previous_row[-1]


def string_similarity(s1: str, s2: str) -> float:
    """
    Calculate string similarity as a value between 0 and 1.
    
    Args:
        s1: First string
        s2: Second string
        
    Returns:
        Similarity score (0-1)
    """
    if not s1 and not s2:
        return 1.0
    
    if not s1 or not s2:
        return 0.0
    
    distance = levenshtein_distance(s1.lower(), s2.lower())
    max_len = max(len(s1), len(s2))
    
    return 1.0 - (distance / max_len)


def find_similar_items(query: str, items: List[str], threshold: float = 0.7) -> List[Tuple[str, float]]:
    """
    Find items similar to a query string.
    
    Args:
        query: Query string
        items: List of items to search
        threshold: Similarity threshold
        
    Returns:
        List of (item, similarity) tuples above threshold
    """
    query = query.lower()
    results = []
    
    for item in items:
        similarity = string_similarity(query, item.lower())
        if similarity >= threshold:
            results.append((item, similarity))
    
    # Sort by similarity (descending)
    results.sort(key=lambda x: x[1], reverse=True)
    
    return results


def find_similar_keys(query: str, mapping: Dict[str, Any], threshold: float = 0.7) -> List[Tuple[str, float]]:
    """
    Find dictionary keys similar to a query string.
    
    Args:
        query: Query string
        mapping: Dictionary to search
        threshold: Similarity threshold
        
    Returns:
        List of (key, similarity) tuples above threshold
    """
    return find_similar_items(query, list(mapping.keys()), threshold)


def tokenize_text(text: str) -> List[str]:
    """
    Tokenize text into words.
    
    Args:
        text: Text to tokenize
        
    Returns:
        List of tokens
    """
    # Remove punctuation
    text = re.sub(r'[^\w\s]', ' ', text.lower())
    
    # Split on whitespace
    return [token for token in text.split() if token]


def get_keyword_density(text: str) -> Dict[str, float]:
    """
    Calculate keyword density in a text.
    
    Args:
        text: Text to analyze
        
    Returns:
        Dictionary of {keyword: density}
    """
    tokens = tokenize_text(text)
    
    if not tokens:
        return {}
    
    # Count tokens
    token_counts = {}
    for token in tokens:
        token_counts[token] = token_counts.get(token, 0) + 1
    
    # Calculate density
    total_tokens = len(tokens)
    return {token: count / total_tokens for token, count in token_counts.items()}


def get_top_keywords(text: str, n: int = 10) -> List[Tuple[str, float]]:
    """
    Get top keywords in a text by density.
    
    Args:
        text: Text to analyze
        n: Number of top keywords to return
        
    Returns:
        List of (keyword, density) tuples
    """
    # Get keyword density
    densities = get_keyword_density(text)
    
    # Sort by density (descending)
    sorted_keywords = sorted(densities.items(), key=lambda x: x[1], reverse=True)
    
    # Return top n keywords
    return sorted_keywords[:n]


def encode_base64(data: Union[str, bytes]) -> str:
    """
    Encode data to base64 string.
    
    Args:
        data: Data to encode (string or bytes)
        
    Returns:
        Base64 encoded string
    """
    import base64
    
    if isinstance(data, str):
        data = data.encode('utf-8')
    
    return base64.b64encode(data).decode('utf-8')


def decode_base64(data: str) -> bytes:
    """
    Decode base64 string to bytes.
    
    Args:
        data: Base64 encoded string
        
    Returns:
        Decoded bytes
    """
    import base64
    return base64.b64decode(data)


def generate_password(length: int = 12, include_special: bool = True) -> str:
    """
    Generate a random password.
    
    Args:
        length: Password length
        include_special: Whether to include special characters
        
    Returns:
        Random password
    """
    import secrets
    import string
    
    # Define character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = '!@#$%^&*()_+-=[]{}|;:,.<>?'
    
    # Define character pool
    if include_special:
        pool = lowercase + uppercase + digits + special
    else:
        pool = lowercase + uppercase + digits
    
    # Ensure password has at least one of each character type
    password = []
    password.append(secrets.choice(lowercase))
    password.append(secrets.choice(uppercase))
    password.append(secrets.choice(digits))
    
    if include_special:
        password.append(secrets.choice(special))
    
    # Fill the rest with random characters
    password.extend(secrets.choice(pool) for _ in range(length - len(password)))
    
    # Shuffle the password
    secrets.SystemRandom().shuffle(password)
    
    return ''.join(password)


def deduplicate_list(items: List[Any]) -> List[Any]:
    """
    Remove duplicates from a list while preserving order.
    
    Args:
        items: List with potential duplicates
        
    Returns:
        List with duplicates removed
    """
    seen = set()
    result = []
    
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    
    return result


def deduplicate_list_of_dicts(items: List[Dict[str, Any]], key: str) -> List[Dict[str, Any]]:
    """
    Remove duplicate dictionaries from a list based on a key.
    
    Args:
        items: List of dictionaries
        key: Key to check for duplicates
        
    Returns:
        List with duplicates removed
    """
    seen = set()
    result = []
    
    for item in items:
        if key in item:
            value = item[key]
            # Skip if we've seen this value before
            if value in seen:
                continue
            seen.add(value)
        result.append(item)
    
    return result


def dict_diff(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Calculate differences between two dictionaries.
    
    Args:
        dict1: First dictionary
        dict2: Second dictionary
        
    Returns:
        Dictionary of differences
    """
    result = {}
    
    # Keys in dict1 but not in dict2
    for key in dict1:
        if key not in dict2:
            result[key] = {"old": dict1[key], "new": None, "status": "removed"}
    
    # Keys in dict2 but not in dict1
    for key in dict2:
        if key not in dict1:
            result[key] = {"old": None, "new": dict2[key], "status": "added"}
    
    # Keys in both dictionaries
    for key in dict1:
        if key in dict2 and dict1[key] != dict2[key]:
            result[key] = {"old": dict1[key], "new": dict2[key], "status": "changed"}
    
    return result