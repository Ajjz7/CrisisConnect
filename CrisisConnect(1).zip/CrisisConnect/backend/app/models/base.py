from flask import Flask, request, jsonify, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from firebase_admin import credentials, initialize_app, db as firebase_db
import openai
import requests
import os
import hashlib
import re
import aiohttp
import datetime
from fastapi import HTTPException
from authlib.integrations.flask_client import OAuth
from fastapi import FastAPI
from datetime import datetime
from sqlalchemy import func
from sqlalchemy.orm import validates
from sqlalchemy import CheckConstraint

# Initialize Flask & FastAPI
flask_app = Flask(__name__)
CORS(flask_app)
fastapi_app = FastAPI()

# Security & Session Configuration
flask_app.secret_key = os.getenv("FLASK_SECRET_KEY", "supersecuresecretkey")
flask_app.config['SESSION_TYPE'] = 'filesystem'

# Database Configuration (PostgreSQL)
flask_app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv("DATABASE_URL", 'postgresql://username:password@localhost/crisisconnect')
flask_app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(flask_app)

# Initialize Firebase (Real-Time Crisis Updates)
cred = credentials.Certificate("firebase_config.json")
firebase_app = initialize_app(cred, {'databaseURL': "https://your-firebase-db.firebaseio.com"})

# OpenAI API Key for AI Chatbot
openai.api_key = os.getenv("OPENAI_API_KEY")

# OAuth for Social Logins (Google, Facebook, LinkedIn, Yahoo)
oauth = OAuth(flask_app)
oauth.init_app(flask_app)

# Social Login Providers
oauth.register("google", client_id=os.getenv("GOOGLE_CLIENT_ID"), client_secret=os.getenv("GOOGLE_CLIENT_SECRET"), authorize_url="https://accounts.google.com/o/oauth2/auth")
oauth.register("facebook", client_id=os.getenv("FACEBOOK_CLIENT_ID"), client_secret=os.getenv("FACEBOOK_CLIENT_SECRET"), authorize_url="https://www.facebook.com/dialog/oauth")
oauth.register("linkedin", client_id=os.getenv("LINKEDIN_CLIENT_ID"), client_secret=os.getenv("LINKEDIN_CLIENT_SECRET"), authorize_url="https://www.linkedin.com/oauth/v2/authorization")

# 🌍 External Disaster Resource APIs
FEMA_API_URL = "https://www.fema.gov/api/open/v1/DisasterDeclarationsSummaries"
RED_CROSS_API_URL = "https://api.redcross.org/disaster_relief"
WHO_CRISIS_API = "https://who.int/emergency/api"

# 🔒 Secure User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstName = db.Column(db.String(100), nullable=False)
    middleInitial = db.Column(db.String(10), nullable=True)
    lastName = db.Column(db.String(100), nullable=False)
    suffix = db.Column(db.String(10), nullable=True)
    ssn = db.Column(db.String(64), nullable=True, unique=True)
    age = db.Column(db.Integer, nullable=True, CheckConstraint('age > 0'))
    disability_status = db.Column(db.String(50), nullable=True)
    health_issues = db.Column(db.Text, nullable=True)
    employment_status = db.Column(db.String(50), nullable=True)
    location = db.Column(db.String(200), nullable=True)
    city = db.Column(db.String(100), nullable=True)
    state = db.Column(db.String(100), nullable=True)
    zipcode = db.Column(db.String(20), nullable=True)
    emergency_contact = db.Column(db.String(100), nullable=True)
    marital_status = db.Column(db.String(50), nullable=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(50), nullable=False, default='user')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def set_password(self, password):
        self.password = hashlib.sha256(password.encode()).hexdigest()

    def verify_password(self, password):
        return self.password == hashlib.sha256(password.encode()).hexdigest()

    @validates('email')
    def validate_email(self, key, email):
        if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            raise ValueError("Invalid email format")
        return email

    @validates('zipcode')
    def validate_zipcode(self, key, zipcode):
        if zipcode and not re.match(r"^\d{5}(?:-\d{4})?$", zipcode):
            raise ValueError("Invalid zipcode format")
        return zipcode

# 🚨 Crisis Report Model (Real-Time Verified Reports)
class CrisisReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    crisis_type = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    location = db.Column(db.String(200), nullable=False)
    image_url = db.Column(db.String(300), nullable=True)
    video_url = db.Column(db.String(300), nullable=True)
    audio_url = db.Column(db.String(300), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    verified = db.Column(db.Boolean, default=False)
    verified_by = db.Column(db.String(100), nullable=True)
    trust_score = db.Column(db.Float, default=0.0)
    upvotes = db.Column(db.Integer, default=0)
    downvotes = db.Column(db.Integer, default=0)
    responder_notified = db.Column(db.Boolean, default=False)
    responder_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def calculate_trust_score(self):
        if self.upvotes + self.downvotes > 0:
            vote_score = self.upvotes / (self.upvotes + self.downvotes)
        else:
            vote_score = 0.5
        ai_severity_score = 0.8 if "life-threatening" in self.description.lower() else 0.6
        self.trust_score = round((vote_score * 0.5) + (ai_severity_score * 0.5), 2)
        if self.trust_score >= 0.85:
            self.verified = True
            self.verified_by = "AI"

    def notify_responder(self):
        critical_crises = ["fire", "earthquake", "medical emergency"]
        if self.trust_score >= 0.75 or any(crisis in self.crisis_type.lower() for crisis in critical_crises):
            self.responder_notified = True
            self.responder_id = func.random()

# 📧 Email & Password Verification
def validate_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

def validate_password(password):
    return len(password) >= 8 and re.search(r"\d", password) and re.search(r"[A-Za-z]", password)

# 🔑 Secure User Registration
@flask_app.