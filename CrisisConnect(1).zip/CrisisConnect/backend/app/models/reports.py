from flask import Blueprint, request, jsonify, session
from .base import db, CrisisReport, User  # Import from base.py
from datetime import datetime
from sqlalchemy import func

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/report', methods=['POST'])
def create_report():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401

    data = request.json
    try:
        new_report = CrisisReport(
            user_id=user_id,
            crisis_type=data.get('crisis_type'),
            description=data.get('description'),
            latitude=data.get('latitude'),
            longitude=data.get('longitude'),
            location=data.get('location'),
            image_url=data.get('image_url'),
            video_url=data.get('video_url'),
            audio_url=data.get('audio_url'),
        )
        db.session.add(new_report)
        db.session.commit()
        return jsonify({"message": "Crisis report created successfully"}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error creating report: {str(e)}"}), 500

@reports_bp.route('/report/<int:report_id>', methods=['GET'])
def get_report(report_id):
    report = CrisisReport.query.get(report_id)
    if not report:
        return jsonify({"message": "Report not found"}), 404
    return jsonify({
        "id": report.id,
        "user_id": report.user_id,
        "crisis_type": report.crisis_type,
        "description": report.description,
        "latitude": report.latitude,
        "longitude": report.longitude,
        "location": report.location,
        "image_url": report.image_url,
        "video_url": report.video_url,
        "audio_url": report.audio_url,
        "timestamp": report.timestamp,
        "verified": report.verified,
        "verified_by": report.verified_by,
        "trust_score": report.trust_score,
        "upvotes": report.upvotes,
        "downvotes": report.downvotes,
        "responder_notified": report.responder_notified,
        "responder_id": report.responder_id
    }), 200

@reports_bp.route('/report/<int:report_id>', methods=['PUT'])
def update_report(report_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401

    report = CrisisReport.query.get(report_id)
    if not report:
        return jsonify({"message": "Report not found"}), 404

    if report.user_id != user_id:
        return jsonify({"message": "Unauthorized"}), 403

    data = request.json
    try:
        report.crisis_type = data.get('crisis_type', report.crisis_type)
        report.description = data.get('description', report.description)
        report.latitude = data.get('latitude', report.latitude)
        report.longitude = data.get('longitude', report.longitude)
        report.location = data.get('location', report.location)
        report.image_url = data.get('image_url', report.image_url)
        report.video_url = data.get('video_url', report.video_url)
        report.audio_url = data.get('audio_url', report.audio_url)
        db.session.commit()
        return jsonify({"message": "Report updated successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error updating report: {str(e)}"}), 500

@reports_bp.route('/report/<int:report_id>', methods=['DELETE'])
def delete_report(report_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401

    report = CrisisReport.query.get(report_id)
    if not report:
        return jsonify({"message": "Report not found"}), 404

    if report.user_id != user_id:
        return jsonify({"message": "Unauthorized"}), 403

    try:
        db.session.delete(report)
        db.session.commit()
        return jsonify({"message": "Report deleted successfully"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error deleting report: {str(e)}"}), 500

@reports_bp.route('/report/<int:report_id>/vote', methods=['POST'])
def vote_report(report_id):
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401

    report = CrisisReport.query.get(report_id)
    if not report:
        return jsonify({"message": "Report not found"}), 404

    data = request.json
    vote_type = data.get('vote_type')  # 'upvote' or 'downvote'

    if vote_type == 'upvote':
        report.upvotes += 1
    elif vote_type == 'downvote':
        report.downvotes += 1
    else:
        return jsonify({"message": "Invalid vote type"}), 400

    report.calculate_trust_score() #Recalculate trust score after vote
    db.session.commit()
    return jsonify({"message": f"Report {vote_type}d successfully"}), 200

@reports_bp.route('/reports', methods=['GET'])
def get_all_reports():
    reports = CrisisReport.query.all()
    report_list = [{
        "id": report.id,
        "user_id": report.user_id,
        "crisis_type": report.crisis_type,
        "description": report.description,
        "latitude": report.latitude,
        "longitude": report.longitude,
        "location": report.location,
        "timestamp": report.timestamp,
        "verified": report.verified,
        "verified_by": report.verified_by,
        "trust_score": report.trust_score,
        "upvotes": report.upvotes,
        "downvotes": report.downvotes,
        "responder_notified": report.responder_notified,
        "responder_id": report.responder_id,
    } for report in reports]
    return jsonify(report_list), 200

@reports_bp.route('/report/<int:report_id>/notify_responder', methods=['POST'])
def notify_responder(report_id):
    report = CrisisReport.query.get(report_id)
    if not report:
        return jsonify({"message": "Report not found"}), 404

    report.notify_responder()
    db.session.commit()
    return jsonify({"message": "Responder notified successfully"}), 200