from flask import Blueprint, request, jsonify, session, url_for, redirect
from .base import db, User, validate_email, validate_password, oauth  # Import from base.py
import hashlib

user_bp = Blueprint('user', __name__)

# 🔑 Secure User Registration
@user_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    if not validate_email(data.get("email")):
        return jsonify({"message": "Invalid email format"}), 400
    if not validate_password(data.get("password")):
        return jsonify({"message": "Password must be at least 8 characters, with a mix of letters and numbers"}), 400

    if User.query.filter_by(email=data.get("email")).first():
        return jsonify({"message": "Email already registered"}), 400

    new_user = User(
        firstName=data.get("firstName"),
        middleInitial=data.get("middleInitial"),
        lastName=data.get("lastName"),
        suffix=data.get("suffix"),
        ssn=hashlib.sha256(data.get("ssn", "").encode()).hexdigest() if data.get("ssn") else None,
        email=data.get("email"),
        role="user"
    )
    new_user.set_password(data.get("password"))
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "User registered successfully."})

# 🔐 Secure User Login
@user_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(email=data.get("email")).first()
    if user and user.verify_password(data.get("password")):
        session["user_id"] = user.id
        return jsonify({"message": "Login successful", "user_id": user.id})
    return jsonify({"message": "Invalid credentials"}), 401

# 📲 Social Login (Google, Facebook, LinkedIn)
@user_bp.route('/login/<provider>')
def social_login(provider):
    if provider not in ["google", "facebook", "linkedin"]:
        return jsonify({"message": "Unsupported provider"}), 400
    return oauth.create_client(provider).authorize_redirect(redirect_uri=url_for('user.authorize', provider=provider, _external=True))

@user_bp.route('/authorize/<provider>')
def authorize(provider):
    token = oauth.create_client(provider).authorize_access_token()
    user_info = oauth.create_client(provider).userinfo()
    user = User.query.filter_by(email=user_info["email"]).first()
    if not user:
        user = User(email=user_info["email"], firstName=user_info["name"].split()[0], role="user")
        db.session.add(user)
        db.session.commit()
    session["user_id"] = user.id
    return redirect(url_for('dashboard')) # Replace 'dashboard' with your desired route.

@user_bp.route('/logout', methods=['POST'])
def logout():
    session.pop('user_id', None)
    return jsonify({"message": "Logged out successfully"}), 200

@user_bp.route('/user_info', methods=['GET'])
def user_info():
    user_id = session.get('user_id')
    if user_id:
        user = User.query.get(user_id)
        if user:
            return jsonify({
                'firstName': user.firstName,
                'lastName': user.lastName,
                'email': user.email,
                'role': user.role,
                'id': user.id
            }), 200
        else:
            return jsonify({'message': 'User not found'}), 404
    else:
        return jsonify({'message': 'User not logged in'}), 401