from flask import Blueprint, jsonify, request
from .base import fastapi_app  # Import FastAPI app from base.py
import aiohttp
import os
import datetime

resources_bp = Blueprint('resources', __name__)

FEMA_API_URL = "https://www.fema.gov/api/open/v1/DisasterDeclarationsSummaries"
RED_CROSS_API_URL = "https://api.redcross.org/disaster_relief"
WHO_CRISIS_API = "https://who.int/emergency/api"

async def translate_text(text_list, target_language):
    """
    AI-powered translation function to translate text into the user's preferred language.
    """
    if target_language == "en":  # No translation needed
        return text_list

    async with aiohttp.ClientSession() as session:
        try:
            async with session.post("https://translation.googleapis.com/language/translate/v2", json={
                "q": text_list,
                "target": target_language,
                "key": os.getenv("GOOGLE_TRANSLATE_API_KEY")
            }) as response:
                data = await response.json()
                return [item["translatedText"] for item in data["data"]["translations"]]

        except Exception:
            return text_list  # Return original text if translation fails

@resources_bp.route('/match_resources', methods=['POST'])
async def match_resources():
    data = request.json
    location = data.get('location', '').strip().lower()
    crisis_type = data.get('crisis_type', '').strip().lower()
    user_needs = data.get('user_needs', [])  # List of user-specific requirements (e.g., "medical aid", "mental health support")
    language = data.get("language", "en") #default to english

    if not location or not crisis_type:
        return jsonify({"error": "Location and crisis type are required."}), 400

    # 🌍 Step 1: Retrieve Real-Time Data from Government & NGO APIs
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(FEMA_API_URL) as fema_response:
                fema_data = await fema_response.json()

            async with session.get(RED_CROSS_API_URL) as rc_response:
                red_cross_data = await rc_response.json()

            async with session.get(WHO_CRISIS_API) as who_response:
                who_data = await who_response.json()

        except Exception as e:
            return jsonify({"error": "Failed to retrieve external crisis data", "details": str(e)}), 500

    # 🔍 Step 2: AI-Powered Crisis Resource Recommendations
    resources = {
        "hurricane": ["Emergency Shelters", "Food Banks", "Medical Aid", "Evacuation Centers", "Emergency Hotlines"],
        "wildfire": ["Evacuation Centers", "Fire Updates", "Volunteer Support", "Air Quality Alerts"],
        "earthquake": ["Rescue Operations", "Temporary Housing", "Emergency Health Clinics", "Food Assistance"],
        "pandemic": ["COVID-19 Testing Sites", "Mental Health Support", "Online Medical Consultation", "Vaccine Centers"],
        "flood": ["Flood Rescue Teams", "Evacuation Shelters", "Drinking Water Distribution", "Sanitation & Hygiene Kits"],
        "conflict": ["Refugee Assistance", "Crisis Counseling", "Security Alerts", "Humanitarian Aid Services"],
    }

    matched_resources = resources.get(crisis_type, ["General Crisis Support"])

    # 📡 Step 3: Incorporate Crowdsourced Reports for Real-Time Resource Availability
    # Placeholder: Replace with actual database/Firebase retrieval logic
    # This is a placeholder as the database interaction from fastAPI is not available in flask.
    user_location_reports = [] # replace with database logic.

    if user_location_reports:
        for report in user_location_reports:
            matched_resources.append(f"Crowdsourced Report: {report.get('description', 'Resource available')}")

    # 🤖 Step 4: AI-Driven Personalized Resource Matching
    if user_needs:
        filtered_resources = [res for res in matched_resources if any(need.lower() in res.lower() for need in user_needs)]
        if filtered_resources:
            matched_resources = filtered_resources

    # 🗣️ Step 5: Multilingual Translation for Resource Accessibility (NLP)
    translated_resources = await translate_text(matched_resources, language)

    # 🗺️ Step 6: Return AI-Matched Crisis Resources
    return jsonify({
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "location": location,
        "crisis_type": crisis_type,
        "matched_resources": translated_resources,
        "real_time_data": {
            "FEMA": fema_data.get("DisasterDeclarationsSummaries", [])[:3],  # Return the 3 latest FEMA updates
            "RedCross": red_cross_data.get("relief_efforts", [])[:3],  # Latest Red Cross data
            "WHO": who_data.get("emergency_responses", [])[:3]  # Latest WHO updates
        },
        "crowdsourced_reports": user_location_reports[:3]  # Show latest 3 crowdsourced crisis updates
    }), 200