from flask import Flask, request, jsonify, session, redirect, url_for, render_template
from flask_sqlalchemy import SQLAlchemy
#from Flask_Cors import CORS
import requests
import os
import hashlib
import re
import aiohttp
import datetime
from fastapi import HTTPException
from authlib.integrations.flask_client import OAuth
from fastapi import FastAPI
from datetime import datetime
from sqlalchemy import func
import firebase_admin
from firebase_admin import credentials, firestore, db as firebase_db
from functools import wraps

flask_app = Flask(__name__, 
                 template_folder='C:/xampp/htdocs/CrisisConnect/templates')
#CORS(flask_app)
fastapi_app = FastAPI()

# Security & Session Configuration
flask_app.secret_key = os.getenv("FLASK_SECRET_KEY", "supersecuresecretkey")
flask_app.config['SESSION_TYPE'] = 'filesystem'

# Database Configuration (PostgreSQL)
flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://actual_username:actual_password@localhost/crisisconnect'
flask_app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(flask_app)

# Initialize Firebase - ONCE only with a named app
if not firebase_admin._apps:
    cred = credentials.Certificate("firebase_service_account.json")
    firebase_app = firebase_admin.initialize_app(cred, {
        'databaseURL': "https://your-firebase-db.firebaseio.com"
    }, name='crisisconnect')
else:
    firebase_app = firebase_admin._apps['crisisconnect'] if 'crisisconnect' in firebase_admin._apps else firebase_admin._apps['[DEFAULT]']

# Get Firestore client
firestore_client = firestore.client(app=firebase_app)

# OpenAI API Key for AI Chatbot
import openai
openai.api_key = os.getenv("OPENAI_API_KEY")

# OAuth for Social Logins (Google, Facebook, LinkedIn, Yahoo)
oauth = OAuth(flask_app)
oauth.init_app(flask_app)

# Social Login Providers
oauth.register("google", client_id="GOOGLE_CLIENT_ID", client_secret="GOOGLE_CLIENT_SECRET", authorize_url="https://accounts.google.com/o/oauth2/auth")
oauth.register("facebook", client_id="FACEBOOK_CLIENT_ID", client_secret="FACEBOOK_CLIENT_SECRET", authorize_url="https://www.facebook.com/dialog/oauth")
oauth.register("linkedin", client_id="LINKEDIN_CLIENT_ID", client_secret="LINKEDIN_CLIENT_SECRET", authorize_url="https://www.linkedin.com/oauth/v2/authorization")

# 🌍 External Disaster Resource APIs
FEMA_API_URL = "https://www.fema.gov/api/open/v1/DisasterDeclarationsSummaries"
RED_CROSS_API_URL = "https://api.redcross.org/disaster_relief"
WHO_CRISIS_API = "https://who.int/emergency/api"

# 🔒 Secure User Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstName = db.Column(db.String(100), nullable=False)
    middleInitial = db.Column(db.String(10), nullable=True)
    lastName = db.Column(db.String(100), nullable=False)
    suffix = db.Column(db.String(10), nullable=True)
    ssn = db.Column(db.String(64), nullable=True, unique=True)
    age = db.Column(db.Integer, nullable=True)
    disability_status = db.Column(db.String(50), nullable=True)
    health_issues = db.Column(db.Text, nullable=True)
    employment_status = db.Column(db.String(50), nullable=True)
    location = db.Column(db.String(200), nullable=True)
    city = db.Column(db.String(100), nullable=True)
    state = db.Column(db.String(100), nullable=True)
    zipcode = db.Column(db.String(20), nullable=True)
    emergency_contact = db.Column(db.String(100), nullable=True)
    marital_status = db.Column(db.String(50), nullable=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(50), nullable=False)

    def set_password(self, password):
        self.password = hashlib.sha256(password.encode()).hexdigest()

    def verify_password(self, password):
        return self.password == hashlib.sha256(password.encode()).hexdigest()


# 🚨 Crisis Report Model (Real-Time Verified Reports)
class CrisisReport(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    crisis_type = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    
    # 📍 Geolocation Fields (Lat/Lon for Precise Mapping)
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    location = db.Column(db.String(200), nullable=False)

    # 📸 Multimedia Evidence (Images, Videos, Audio)
    image_url = db.Column(db.String(300), nullable=True)
    video_url = db.Column(db.String(300), nullable=True)
    audio_url = db.Column(db.String(300), nullable=True)

    # ⏰ Timestamp Fields
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    # ✅ Verification & Trust Score
    verified = db.Column(db.Boolean, default=False)  # Default: Unverified
    verified_by = db.Column(db.String(100), nullable=True)  # 'AI', 'User', 'Responder', 'Admin'
    trust_score = db.Column(db.Float, default=0.0)  # AI-Generated Score (0 to 1)
    
    # 🤝 Crowdsourced Validation (Upvotes/Downvotes)
    upvotes = db.Column(db.Integer, default=0)
    downvotes = db.Column(db.Integer, default=0)

    # 🚑 Emergency Responder Status
    responder_notified = db.Column(db.Boolean, default=False)
    responder_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # Assigned Responder ID

    def calculate_trust_score(self):
        """
        AI-Powered Trust Score Calculation:
        - Factors in crowdsourced validation (upvotes/downvotes)
        - Analyzes crisis type & previous verified reports
        - Uses NLP to detect urgency levels in crisis descriptions
        """
        if self.upvotes + self.downvotes > 0:
            vote_score = self.upvotes / (self.upvotes + self.downvotes)
        else:
            vote_score = 0.5  # Default neutral trust score
        
        # Assign AI trust score based on crisis severity (Placeholder for ML Model)
        ai_severity_score = 0.8 if "life-threatening" in self.description.lower() else 0.6
        
        # Final Weighted Score (50% votes, 50% AI analysis)
        self.trust_score = round((vote_score * 0.5) + (ai_severity_score * 0.5), 2)
        
        # Auto-verify if trust score is high
        if self.trust_score >= 0.85:
            self.verified = True
            self.verified_by = "AI"
    
    def notify_responder(self):
        """
        Automatically notify emergency responders if:
        - Crisis is 'severe' and trust_score >= 0.75
        - Crisis is 'critical' (e.g., 'fire', 'earthquake', 'medical emergency')
        """
        critical_crises = ["fire", "earthquake", "medical emergency"]
        if self.trust_score >= 0.75 or any(crisis in self.crisis_type.lower() for crisis in critical_crises):
            self.responder_notified = True
            # 🚑 Assign responder dynamically (Placeholder Logic)
            self.responder_id = func.random()  # Select a responder randomly (Replace with actual responder assignment logic)

# 📧 Email & Password Verification
def validate_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

def validate_password(password):
    return len(password) >= 8 and re.search(r"\d", password) and re.search(r"[A-Za-z]", password)

# Authentication middleware
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login_page'))
        return f(*args, **kwargs)
    return decorated_function

# 🌐 Front-end routes for HTML templates
@flask_app.route('/')
def index():
    return render_template('index.html')

# Routes without .html extensions
@flask_app.route('/login')
def login_page():
    return render_template('login.html')

@flask_app.route('/register')
def register_page():
    return render_template('register.html')

@flask_app.route('/report')
@login_required
def report_crisis_page():
    return render_template('report.html')

@flask_app.route('/dashboard')
@login_required
def dashboard_page():
    return render_template('dashboard.html')

@flask_app.route('/resources')
def find_resources_page():
    return render_template('resources.html')

@flask_app.route('/crisis-map')
def crisis_map_page():
    return render_template('crisis-map.html')

# Legacy routes with .html extensions (for backward compatibility)
@flask_app.route('/login.html')
def login_page_legacy():
    return redirect(url_for('login_page'))

@flask_app.route('/register.html')
def register_page_legacy():
    return redirect(url_for('register_page'))

@flask_app.route('/report.html')
@login_required
def report_crisis_page_legacy():
    return redirect(url_for('report_crisis_page'))

@flask_app.route('/dashboard.html')
@login_required
def dashboard_page_legacy():
    return redirect(url_for('dashboard_page'))

@flask_app.route('/resources.html')
def find_resources_page_legacy():
    return redirect(url_for('find_resources_page'))

@flask_app.route('/crisis-map.html')
def crisis_map_page_legacy():
    return redirect(url_for('crisis_map_page'))

@flask_app.route('/api')
def api_index():
    return jsonify({"message": "Welcome to CrisisConnect API", "status": "online"})

# 🔑 Secure User Registration
@flask_app.route('/register', methods=['POST'])
def register():
    data = request.json
    if not validate_email(data.get("email")):
        return jsonify({"message": "Invalid email format"}), 400
    if not validate_password(data.get("password")):
        return jsonify({"message": "Password must be at least 8 characters, with a mix of letters and numbers"}), 400

    new_user = User(
        firstName=data.get("firstName"),
        middleInitial=data.get("middleInitial"),
        lastName=data.get("lastName"),
        suffix=data.get("suffix"),
        ssn=hashlib.sha256(data.get("ssn", "").encode()).hexdigest() if data.get("ssn") else None,
        email=data.get("email"),
        role="user"
    )
    new_user.set_password(data.get("password"))
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "User registered successfully."})


# 🔐 Secure User Login
@flask_app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(email=data.get("email")).first()
    if user and user.verify_password(data.get("password")):
        session["user_id"] = user.id
        return jsonify({"message": "Login successful", "user_id": user.id})
    return jsonify({"message": "Invalid credentials"}), 401

# 🚪 Logout
@flask_app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('index'))

# 📲 Social Login (Google, Facebook, LinkedIn)
@flask_app.route('/login/<provider>')
def social_login(provider):
    if provider not in ["google", "facebook", "linkedin"]:
        return jsonify({"message": "Unsupported provider"}), 400
    return oauth.create_client(provider).authorize_redirect(redirect_uri=url_for('authorize', provider=provider, _external=True))


@flask_app.route('/authorize/<provider>')
def authorize(provider):
    token = oauth.create_client(provider).authorize_access_token()
    user_info = oauth.create_client(provider).userinfo()
    user = User.query.filter_by(email=user_info["email"]).first()
    if not user:
        user = User(email=user_info["email"], firstName=user_info["name"].split()[0], lastName="", role="user")
        user.set_password(os.urandom(16).hex())  # Generate a random secure password
        db.session.add(user)
        db.session.commit()
    session["user_id"] = user.id
    return redirect(url_for('dashboard_page'))

# 📊 API endpoint for submitting crisis reports
@flask_app.route('/api/crisis-reports', methods=['POST'])
@login_required
def submit_crisis_report():
    data = request.json
    
    # Create new crisis report
    new_report = CrisisReport(
        user_id=data.get("user_id") or session.get("user_id"),
        crisis_type=data.get("crisis_type"),
        description=data.get("description"),
        latitude=data.get("latitude"),
        longitude=data.get("longitude"),
        location=data.get("location")
        # Add other fields as needed
    )
    
    # Calculate trust score and notify responders
    new_report.calculate_trust_score()
    new_report.notify_responder()
    
    db.session.add(new_report)
    db.session.commit()
    
    return jsonify({
        "id": new_report.id,
        "message": "Crisis report submitted successfully.",
        "trust_score": new_report.trust_score,
        "verified": new_report.verified
    })

# 🚀 AI-Powered Resource Matching (FastAPI)
@fastapi_app.post("/ai/match_resources")
async def match_resources(data: dict):
    location = data.get('location', '').strip().lower()
    crisis_type = data.get('crisis_type', '').strip().lower()
    user_needs = data.get('user_needs', [])  # List of user-specific requirements (e.g., "medical aid", "mental health support")

    if not location or not crisis_type:
        raise HTTPException(status_code=400, detail="Location and crisis type are required.")

    # 🌍 Step 1: Retrieve Real-Time Data from Government & NGO APIs
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(FEMA_API_URL) as fema_response:
                fema_data = await fema_response.json()

            async with session.get(RED_CROSS_API_URL) as rc_response:
                red_cross_data = await rc_response.json()

            async with session.get(WHO_CRISIS_API) as who_response:
                who_data = await who_response.json()

        except Exception as e:
            return {"error": "Failed to retrieve external crisis data", "details": str(e)}

    # 🔍 Step 2: AI-Powered Crisis Resource Recommendations
    resources = {
        "hurricane": ["Emergency Shelters", "Food Banks", "Medical Aid", "Evacuation Centers", "Emergency Hotlines", "Storm Updates"],
        "wildfire": ["Evacuation Centers", "Fire Updates", "Volunteer Support", "Air Quality Alerts", "Animal Rescue", "Burn Treatment Centers"],
        "earthquake": ["Rescue Operations", "Temporary Housing", "Emergency Health Clinics", "Food Assistance", "Structural Engineers", "Safety Inspections"],
        "pandemic": ["COVID-19 Testing Sites", "Mental Health Support", "Online Medical Consultation", "Vaccine Centers", "Isolation Facilities", "PPE Distribution"],
        "flood": ["Flood Rescue Teams", "Evacuation Shelters", "Drinking Water Distribution", "Sanitation & Hygiene Kits", "Pumping Services", "Mold Remediation"],
        "conflict": ["Refugee Assistance", "Crisis Counseling", "Security Alerts", "Humanitarian Aid Services", "Legal Aid", "Missing Persons"],
        "tornado": ["Storm Shelters", "Debris Removal", "Weather Alerts", "Home Repair Services", "Power Restoration", "Emergency Communications"],
        "medical_emergency": ["Emergency Medical Services", "Hospitals", "Specialized Clinics", "Pharmacy Services", "Blood Donation Centers", "Medical Transport"],
        "power_outage": ["Charging Stations", "Generator Locations", "Cooling/Warming Centers", "Food Storage", "Emergency Lighting", "Utility Assistance"],
        "gas_leak": ["Evacuation Routes", "Gas Company Contacts", "Safety Inspection", "Temporary Housing", "Emergency Response", "Air Quality Monitoring"],
        "water_shortage": ["Water Distribution Points", "Water Conservation Guidelines", "Bottled Water Suppliers", "Sanitation Services", "Hygiene Supplies", "Emergency Plumbing"],
        "civil_unrest": ["Safe Zones", "Legal Aid", "Medical Assistance", "Emergency Communications", "Transportation Services", "Community Support Groups"],
        "drought": ["Water Conservation Programs", "Agricultural Aid", "Food Assistance", "Well Drilling Services", "Livestock Support", "Financial Relief Programs"],
        "chemical_spill": ["Hazmat Teams", "Decontamination Centers", "Medical Treatment", "Environmental Testing", "Evacuation Routes", "Safety Information"],
        "nuclear_incident": ["Radiation Shelters", "Decontamination Centers", "Radiation Testing", "Medical Treatment", "Evacuation Routes", "Emergency Communications"],
        "winter_storm": ["Warming Centers", "Snow Removal", "Emergency Supplies", "Road Conditions", "Power Restoration", "Cold Weather Health Services"],
        "heat_wave": ["Cooling Centers", "Water Distribution", "Heat Illness Treatment", "Power Assistance", "Vulnerable Population Checks", "Air Conditioning Services"],
        "landslide": ["Search and Rescue", "Geological Assessment", "Temporary Housing", "Road Clearing", "Evacuation Assistance", "Structural Engineering"],
        "tsunami": ["High Ground Locations", "Evacuation Routes", "Emergency Shelters", "Search and Rescue", "Medical Aid", "Missing Persons"],
        "volcanic_eruption": ["Evacuation Routes", "Air Quality Monitoring", "Respiratory Health Services", "Emergency Shelters", "Ash Cleanup", "Transportation Services"]
    }

    matched_resources = resources.get(crisis_type, ["General Crisis Support"])

    # 📡 Step 3: Incorporate Crowdsourced Reports for Real-Time Resource Availability
    ref = firebase_db.reference("/crisis_reports", app=firebase_app)
    crisis_reports = ref.get() or {}

    user_location_reports = [report for report in crisis_reports.values() if report.get("location", "").lower() == location]

    if user_location_reports:
        for report in user_location_reports:
            matched_resources.append(f"Crowdsourced Report: {report.get('description', 'Resource available')}")

    # 🤖 Step 4: AI-Driven Personalized Resource Matching
    if user_needs:
        filtered_resources = [res for res in matched_resources if any(need.lower() in res.lower() for need in user_needs)]
        if filtered_resources:
            matched_resources = filtered_resources

    # 🗣️ Step 5: Multilingual Translation for Resource Accessibility (NLP)
    language = data.get("language", "en")  # Default to English
    translated_resources = await translate_text(matched_resources, language)

    # 🗺️ Step 6: Return AI-Matched Crisis Resources
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "location": location,
        "crisis_type": crisis_type,
        "matched_resources": translated_resources,
        "real_time_data": {
            "FEMA": fema_data.get("DisasterDeclarationsSummaries", [])[:3],  # Return the 3 latest FEMA updates
            "RedCross": red_cross_data.get("relief_efforts", [])[:3],  # Latest Red Cross data
            "WHO": who_data.get("emergency_responses", [])[:3]  # Latest WHO updates
        },
        "crowdsourced_reports": user_location_reports[:3]  # Show latest 3 crowdsourced crisis updates
    }

# 🗣️ AI-Based Multilingual Translation (Google Translate API or OpenAI NLP)
async def translate_text(text_list, target_language):
    """
    AI-powered translation function to translate text into the user's preferred language.
    """
    if target_language == "en":  # No translation needed
        return text_list

    async with aiohttp.ClientSession() as session:
        try:
            async with session.post("https://translation.googleapis.com/language/translate/v2", json={
                "q": text_list,
                "target": target_language,
                "key": os.getenv("GOOGLE_TRANSLATE_API_KEY")
            }) as response:
                data = await response.json()
                return [item["translatedText"] for item in data["data"]["translations"]]

        except Exception:
            return text_list  # Return original text if translation fails

# For newer Flask versions (2.x+), we need to use a different approach instead of before_first_request
with flask_app.app_context():
    # Create all tables if they don't exist
    try:
        db.create_all()
        print("Database tables created successfully")
    except Exception as e:
        print(f"Error creating database tables: {e}")

# 🚀 Run Flask & FastAPI together
if __name__ == '__main__':
    import uvicorn
    from threading import Thread
    
    # Start Flask in a separate thread
    Thread(target=lambda: flask_app.run(debug=True, use_reloader=False)).start()
    
    # Start FastAPI
    uvicorn.run(fastapi_app, host="0.0.0.0", port=8000)