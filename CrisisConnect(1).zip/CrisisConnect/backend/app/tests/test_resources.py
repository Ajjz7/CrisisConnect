"""
test_resources.py - Test suite for resource management functionality in CrisisConnect

Tests for:
- Crisis report creation and management
- Resource matching algorithm
- External API integrations (FEMA, Red Cross, WHO)
- Voting on crisis reports
- Trust score calculation
- Responder notification
- AI-based resource matching
- Multilingual translation
- Weather data integration
"""

import unittest
import json
import os
from unittest.mock import patch, MagicMock
from datetime import datetime

import pytest
import aiohttp
import firebase_admin

# Import the Flask and FastAPI apps
from main import flask_app, fastapi_app
from database import db, User, CrisisReport

# Test constants
TEST_USER_EMAIL = "responder@example.com"
TEST_USER_PASSWORD = "Secure123!"
TEST_USER_FIRST_NAME = "Crisis"
TEST_USER_LAST_NAME = "Responder"
TEST_USER_ROLE = "responder"

# Test crisis report data
TEST_CRISIS_REPORT = {
    "crisis_type": "flood",
    "description": "Rising water levels in downtown area",
    "location": "Springfield, Main Street",
    "severity": "medium",
    "affected_population": 500,
    "immediate_needs": ["evacuation", "water", "shelter"],
    "infrastructure_status": {
        "power": "intermittent",
        "water": "contaminated",
        "communications": "operational",
        "transportation": "limited"
    }
}

# Test resource matching request
TEST_RESOURCE_MATCH_REQUEST = {
    "location": "Springfield, Main Street",
    "crisis_type": "flood",
    "severity": "high",
    "user_needs": ["medical", "shelter", "evacuation"],
    "special_needs": True,
    "has_children": True,
    "has_pets": True,
    "transportation": False,
    "language": "en"
}


@pytest.fixture
def client():
    """Create a test client for the Flask app."""
    # Set app to testing mode
    flask_app.config['TESTING'] = True
    flask_app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for testing
    
    # Use in-memory SQLite for testing
    flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    # Create a test client
    with flask_app.test_client() as client:
        # Set up application context
        with flask_app.app_context():
            # Create all tables
            db.create_all()
            
            # Seed a test user
            test_user = User(
                email=TEST_USER_EMAIL,
                password=TEST_USER_PASSWORD,  # This would normally be hashed
                first_name=TEST_USER_FIRST_NAME,
                last_name=TEST_USER_LAST_NAME,
                role=TEST_USER_ROLE
            )
            db.session.add(test_user)
            db.session.commit()
            
            # Login the test user (create a session)
            client.post(
                '/login',
                data=json.dumps({
                    "email": TEST_USER_EMAIL,
                    "password": TEST_USER_PASSWORD
                }),
                content_type='application/json'
            )
            
            yield client
            
            # Clean up
            db.session.remove()
            db.drop_all()


@pytest.fixture
def fastapi_client():
    """Create a test client for the FastAPI app."""
    from fastapi.testclient import TestClient
    
    client = TestClient(fastapi_app)
    return client


class TestCrisisReporting(unittest.TestCase):
    """Test case for crisis reporting functionality."""
    
    def setUp(self):
        """Set up test client and environment."""
        # Set app to testing mode
        flask_app.config['TESTING'] = True
        flask_app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for testing
        
        # Use in-memory SQLite for testing
        flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        
        # Create a test client
        self.client = flask_app.test_client()
        
        # Set up application context
        with flask_app.app_context():
            # Create all tables
            db.create_all()
            
            # Seed a test user
            test_user = User(
                email=TEST_USER_EMAIL,
                password=TEST_USER_PASSWORD,  # This would normally be hashed
                first_name=TEST_USER_FIRST_NAME,
                last_name=TEST_USER_LAST_NAME,
                role=TEST_USER_ROLE
            )
            db.session.add(test_user)
            db.session.commit()
            
            # Login the test user (create a session)
            self.client.post(
                '/login',
                data=json.dumps({
                    "email": TEST_USER_EMAIL,
                    "password": TEST_USER_PASSWORD
                }),
                content_type='application/json'
            )
    
    def tearDown(self):
        """Clean up after tests."""
        with flask_app.app_context():
            db.session.remove()
            db.drop_all()
    
    @patch('main.firebase_db')
    def test_create_crisis_report(self, mock_firebase_db):
        """Test creating a new crisis report."""
        # Mock firebase reference and child
        mock_ref = MagicMock()
        mock_firebase_db.reference.return_value = mock_ref
        mock_child = MagicMock()
        mock_ref.child.return_value = mock_child
        
        # Send request to create crisis report
        response = self.client.post(
            '/crisis/report',
            data=json.dumps(TEST_CRISIS_REPORT),
            content_type='application/json'
        )
        
        # Check response
        self.assertEqual(response.status_code, 201)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("report_id", response_data)
        self.assertIn("trust_score", response_data)
        
        # Verify report was created in database
        with flask_app.app_context():
            report = CrisisReport.query.get(response_data["report_id"])
            self.assertIsNotNone(report)
            self.assertEqual(report.crisis_type, TEST_CRISIS_REPORT["crisis_type"])
            self.assertEqual(report.description, TEST_CRISIS_REPORT["description"])
            self.assertEqual(report.location, TEST_CRISIS_REPORT["location"])
        
        # Verify Firebase was updated
        mock_firebase_db.reference.assert_called_once_with("/crisis_reports")
        mock_ref.child.assert_called_once()
        mock_child.set.assert_called_once()
    
    def test_create_crisis_report_unauthenticated(self):
        """Test creating a crisis report when not authenticated."""
        # Create a new client without authentication
        unauthenticated_client = flask_app.test_client()
        
        # Send request to create crisis report
        response = unauthenticated_client.post(
            '/crisis/report',
            data=json.dumps(TEST_CRISIS_REPORT),
            content_type='application/json'
        )
        
        # Check response - should fail with 401
        self.assertEqual(response.status_code, 401)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("authentication required", response_data["message"].lower())
    
    def test_create_crisis_report_missing_fields(self):
        """Test creating a crisis report with missing required fields."""
        # Create report data with missing fields
        incomplete_report = {
            "crisis_type": "flood",
            # Missing description
            "location": "Springfield, Main Street"
        }
        
        # Send request to create crisis report
        response = self.client.post(
            '/crisis/report',
            data=json.dumps(incomplete_report),
            content_type='application/json'
        )
        
        # Check response - should fail with 400
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
    
    @patch('main.firebase_db')
    def test_vote_on_crisis_report(self, mock_firebase_db):
        """Test voting on a crisis report."""
        # First create a crisis report
        with flask_app.app_context():
            report = CrisisReport(
                crisis_type=TEST_CRISIS_REPORT["crisis_type"],
                description=TEST_CRISIS_REPORT["description"],
                location=TEST_CRISIS_REPORT["location"],
                user_id=1,  # Assuming user ID 1 exists
                created_at=datetime.utcnow(),
                upvotes=0,
                downvotes=0,
                trust_score=0.5,
                responder_notified=False
            )
            db.session.add(report)
            db.session.commit()
            report_id = report.id
        
        # Mock firebase reference and update
        mock_ref = MagicMock()
        mock_firebase_db.reference.return_value = mock_ref
        
        # Send request to vote on the report
        response = self.client.post(
            f'/crisis/vote/{report_id}',
            data=json.dumps({"vote": "up"}),
            content_type='application/json'
        )
        
        # Check response
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("previous_trust_score", response_data)
        self.assertIn("new_trust_score", response_data)
        
        # Verify report was updated in database
        with flask_app.app_context():
            updated_report = CrisisReport.query.get(report_id)
            self.assertEqual(updated_report.upvotes, 1)
            self.assertEqual(updated_report.downvotes, 0)
        
        # Verify Firebase was updated
        mock_firebase_db.reference.assert_called_once_with(f"/crisis_reports/{report_id}")
        mock_ref.update.assert_called_once()
    
    def test_vote_on_nonexistent_report(self):
        """Test voting on a non-existent crisis report."""
        # Send request to vote on a non-existent report
        response = self.client.post(
            '/crisis/vote/999999',  # Non-existent ID
            data=json.dumps({"vote": "up"}),
            content_type='application/json'
        )
        
        # Check response - should fail with 404
        self.assertEqual(response.status_code, 404)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("not found", response_data["message"].lower())
    
    def test_vote_with_invalid_vote_type(self):
        """Test voting with an invalid vote type."""
        # First create a crisis report
        with flask_app.app_context():
            report = CrisisReport(
                crisis_type=TEST_CRISIS_REPORT["crisis_type"],
                description=TEST_CRISIS_REPORT["description"],
                location=TEST_CRISIS_REPORT["location"],
                user_id=1,  # Assuming user ID 1 exists
                created_at=datetime.utcnow(),
                upvotes=0,
                downvotes=0,
                trust_score=0.5,
                responder_notified=False
            )
            db.session.add(report)
            db.session.commit()
            report_id = report.id
        
        # Send request with invalid vote type
        response = self.client.post(
            f'/crisis/vote/{report_id}',
            data=json.dumps({"vote": "invalid"}),  # Not "up" or "down"
            content_type='application/json'
        )
        
        # Check response - should fail with 400
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("invalid vote type", response_data["message"].lower())


class TestResourceMatching:
    """Test case for resource matching functionality using pytest."""
    
    @pytest.mark.asyncio
    @patch('aiohttp.ClientSession.get')
    async def test_match_resources(self, mock_get, fastapi_client):
        """Test the AI-powered resource matching endpoint."""
        # Mock the external API responses
        mock_fema_response = MagicMock()
        mock_fema_response.json.return_value = {
            "DisasterDeclarationsSummaries": [
                {"femaDeclarationString": "DR-4999", "state": "CA", "incidentType": "Flood"}
            ]
        }
        
        mock_redcross_response = MagicMock()
        mock_redcross_response.json.return_value = {
            "relief_efforts": [
                {"id": "relief-123", "location": "Springfield", "type": "Shelter"}
            ]
        }
        
        mock_who_response = MagicMock()
        mock_who_response.json.return_value = {
            "emergency_responses": [
                {"id": "who-123", "location": "US", "type": "Medical Mission"}
            ]
        }
        
        # Configure the mock to return different responses for different URLs
        def side_effect(*args, **kwargs):
            url = kwargs.get('url') or args[0]
            if "fema.gov" in url:
                return mock_fema_response
            elif "redcross.org" in url:
                return mock_redcross_response
            elif "who.int" in url:
                return mock_who_response
            return MagicMock()
        
        mock_get.side_effect = side_effect
        
        # Send resource matching request
        response = fastapi_client.post(
            "/ai/match_resources",
            json=TEST_RESOURCE_MATCH_REQUEST
        )
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Check key elements in response
        assert "matched_resources" in data
        assert "timestamp" in data
        assert "location" in data
        assert "crisis_type" in data
        assert "severity" in data
        assert "weather_data" in data
        assert "environmental_data" in data
        assert "safety_instructions" in data
        assert "evacuation_routes" in data
        assert "emergency_contacts" in data
        
        # Verify the resource matching logic worked
        resources = data["matched_resources"]
        assert len(resources) > 0
        
        # Verify special needs resources are included
        special_needs_resources = [r for r in resources if "disability" in r.lower() or "accessible" in r.lower()]
        assert len(special_needs_resources) > 0
        
        # Verify child-specific resources are included
        child_resources = [r for r in resources if "child" in r.lower() or "family" in r.lower()]
        assert len(child_resources) > 0
        
        # Verify pet-specific resources are included
        pet_resources = [r for r in resources if "pet" in r.lower() or "animal" in r.lower()]
        assert len(pet_resources) > 0
        
        # Verify transportation resources are included
        transportation_resources = [r for r in resources if "transportation" in r.lower() or "evacuation assistance" in r.lower()]
        assert len(transportation_resources) > 0
    
    @pytest.mark.asyncio
    @patch('aiohttp.ClientSession.get')
    @patch('main.translate_text')
    async def test_match_resources_with_translation(self, mock_translate, mock_get, fastapi_client):
        """Test resource matching with language translation."""
        # Mock the external API responses (simplified)
        mock_response = MagicMock()
        mock_response.json.return_value = {}
        mock_get.return_value = mock_response
        
        # Mock translation function
        async def translate_side_effect(text_list, target_language):
            # Simulate translation by adding a prefix
            if target_language == "es":
                return [f"ES: {text}" for text in text_list]
            elif target_language == "fr":
                return [f"FR: {text}" for text in text_list]
            return text_list
        
        mock_translate.side_effect = translate_side_effect
        
        # Test Spanish translation
        spanish_request = TEST_RESOURCE_MATCH_REQUEST.copy()
        spanish_request["language"] = "es"
        
        response = fastapi_client.post(
            "/ai/match_resources",
            json=spanish_request
        )
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify resources were translated
        resources = data["matched_resources"]
        assert len(resources) > 0
        assert all(r.startswith("ES: ") for r in resources)
        
        # Test French translation
        french_request = TEST_RESOURCE_MATCH_REQUEST.copy()
        french_request["language"] = "fr"
        
        response = fastapi_client.post(
            "/ai/match_resources",
            json=french_request
        )
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify resources were translated
        resources = data["matched_resources"]
        assert len(resources) > 0
        assert all(r.startswith("FR: ") for r in resources)
    
    def test_match_resources_missing_data(self, fastapi_client):
        """Test resource matching with missing required data."""
        # Request with missing location
        incomplete_request = {
            "crisis_type": "flood",
            # Missing location
            "severity": "high"
        }
        
        response = fastapi_client.post(
            "/ai/match_resources",
            json=incomplete_request
        )
        
        # Check response - should fail with 400
        assert response.status_code == 400
        data = response.json()
        assert "detail" in data
        assert "location" in data["detail"].lower()
    
    def test_safety_instructions_by_crisis_type(self, fastapi_client):
        """Test that different crisis types get appropriate safety instructions."""
        crisis_types = ["hurricane", "tornado", "earthquake", "flood", "wildfire", "pandemic", "chemical_spill"]
        
        for crisis_type in crisis_types:
            # Create request for this crisis type
            request_data = TEST_RESOURCE_MATCH_REQUEST.copy()
            request_data["crisis_type"] = crisis_type
            
            response = fastapi_client.post(
                "/ai/match_resources",
                json=request_data
            )
            
            # Check response
            assert response.status_code == 200
            data = response.json()
            
            # Verify safety instructions are present and specific to crisis type
            assert "safety_instructions" in data
            instructions = data["safety_instructions"]
            assert len(instructions) >= 5  # Should have at least 5 instructions
            
            # Different crisis types should have different safety instructions
            if crisis_type == "hurricane":
                has_hurricane_specific = any("wind" in i.lower() or "storm" in i.lower() or "evacuat" in i.lower() for i in instructions)
                assert has_hurricane_specific
            elif crisis_type == "tornado":
                has_tornado_specific = any("shelter" in i.lower() or "basement" in i.lower() for i in instructions)
                assert has_tornado_specific
            elif crisis_type == "earthquake":
                has_earthquake_specific = any("drop" in i.lower() or "cover" in i.lower() or "shake" in i.lower() for i in instructions)
                assert has_earthquake_specific


class TestTrustScoreCalculation(unittest.TestCase):
    """Test case for trust score calculation and responder notification."""
    
    def setUp(self):
        """Set up test environment."""
        # Set app to testing mode
        flask_app.config['TESTING'] = True
        
        # Use in-memory SQLite for testing
        flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        
        # Set up application context
        with flask_app.app_context():
            # Create all tables
            db.create_all()
    
    def tearDown(self):
        """Clean up after tests."""
        with flask_app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_calculate_trust_score(self):
        """Test trust score calculation based on votes."""
        with flask_app.app_context():
            # Create test report
            report = CrisisReport(
                crisis_type="flood",
                description="Test description",
                location="Test location",
                user_id=1,
                created_at=datetime.utcnow(),
                upvotes=0,
                downvotes=0,
                trust_score=0.5,  # Initial score
                responder_notified=False
            )
            
            # Test initial score
            self.assertEqual(report.trust_score, 0.5)
            
            # Test with upvotes only
            report.upvotes = 5
            report.downvotes = 0
            score = report.calculate_trust_score()
            self.assertTrue(score > 0.5)
            
            # Test with downvotes only
            report.upvotes = 0
            report.downvotes = 5
            score = report.calculate_trust_score()
            self.assertTrue(score < 0.5)
            
            # Test with equal upvotes and downvotes
            report.upvotes = 5
            report.downvotes = 5
            score = report.calculate_trust_score()
            self.assertAlmostEqual(score, 0.5, places=1)
            
            # Test with more upvotes than downvotes
            report.upvotes = 10
            report.downvotes = 5
            score = report.calculate_trust_score()
            self.assertTrue(score > 0.5)
            
            # Test with many votes
            report.upvotes = 100
            report.downvotes = 10
            score = report.calculate_trust_score()
            self.assertTrue(score > 0.8)  # Should be high confidence
    
    def test_responder_notification_threshold(self):
        """Test that responders are notified when trust score exceeds threshold."""
        with flask_app.app_context():
            # Create test report
            report = CrisisReport(
                crisis_type="flood",
                description="Test description",
                location="Test location",
                user_id=1,
                created_at=datetime.utcnow(),
                upvotes=0,
                downvotes=0,
                trust_score=0.4,  # Below threshold
                responder_notified=False
            )
            
            # Check initial state
            self.assertFalse(report.responder_notified)
            
            # Test below threshold
            notification_status = report.notify_responder()
            self.assertFalse(notification_status)
            self.assertFalse(report.responder_notified)
            
            # Test at threshold
            report.trust_score = 0.7  # Assuming threshold is 0.7
            notification_status = report.notify_responder()
            self.assertTrue(notification_status)
            self.assertTrue(report.responder_notified)
            
            # Test already notified
            report.trust_score = 0.8
            notification_status = report.notify_responder()
            self.assertTrue(notification_status)  # Should still return True
            self.assertTrue(report.responder_notified)
            
            # Test score decreases below threshold
            report.trust_score = 0.3
            report.responder_notified = True  # Already notified
            notification_status = report.notify_responder()
            self.assertTrue(notification_status)  # Should not un-notify
            self.assertTrue(report.responder_notified)


if __name__ == '__main__':
    unittest.main()