"""
test_auth.py - Test suite for authentication functionality in CrisisConnect

Tests for:
- User registration
- User login and logout
- Password validation and hashing
- JWT token generation and validation
- Social login authentication
- Role-based authorization
- Session management
- Security headers
- CSRF protection
"""

import unittest
import json
import time
import os
import re
from unittest.mock import patch, MagicMock

import jwt
import pytest
from werkzeug.security import generate_password_hash

# Import the Flask app and required modules
from main import flask_app
from database import db, User
from utils.security import (
    generate_token, verify_token, validate_email, 
    validate_password_strength, generate_password_hash as security_generate_password_hash
)

# Define constants for testing
TEST_USER_EMAIL = "test@example.com"
TEST_USER_PASSWORD = "Test1234!"
TEST_USER_FIRST_NAME = "Test"
TEST_USER_LAST_NAME = "User"


@pytest.fixture
def client():
    """Create a test client for the Flask app."""
    # Set app to testing mode
    flask_app.config['TESTING'] = True
    flask_app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for testing
    
    # Use in-memory SQLite for testing
    flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    # Create a test client
    with flask_app.test_client() as client:
        # Set up application context
        with flask_app.app_context():
            # Create all tables
            db.create_all()
            
            # Seed a test user
            test_user = User(
                email=TEST_USER_EMAIL,
                password_hash=generate_password_hash(TEST_USER_PASSWORD),
                first_name=TEST_USER_FIRST_NAME,
                last_name=TEST_USER_LAST_NAME,
                role="user"
            )
            db.session.add(test_user)
            db.session.commit()
            
            yield client
            
            # Clean up
            db.session.remove()
            db.drop_all()


class TestAuthentication(unittest.TestCase):
    """Test case for authentication functionality."""
    
    def setUp(self):
        """Set up test client and environment."""
        # Set app to testing mode
        flask_app.config['TESTING'] = True
        flask_app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for testing
        
        # Use in-memory SQLite for testing
        flask_app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        
        # Create a test client
        self.client = flask_app.test_client()
        
        # Set up application context
        with flask_app.app_context():
            # Create all tables
            db.create_all()
            
            # Seed a test user
            test_user = User(
                email=TEST_USER_EMAIL,
                password_hash=generate_password_hash(TEST_USER_PASSWORD),
                first_name=TEST_USER_FIRST_NAME,
                last_name=TEST_USER_LAST_NAME,
                role="user"
            )
            db.session.add(test_user)
            db.session.commit()
    
    def tearDown(self):
        """Clean up after tests."""
        with flask_app.app_context():
            db.session.remove()
            db.drop_all()
    
    def test_user_registration(self):
        """Test user registration functionality."""
        # Test data
        new_user_data = {
            "email": "newuser@example.com",
            "password": "SecurePass123!",
            "firstName": "New",
            "lastName": "User",
            "role": "user"
        }
        
        # Send registration request
        response = self.client.post(
            '/register',
            data=json.dumps(new_user_data),
            content_type='application/json'
        )
        
        # Check response
        self.assertEqual(response.status_code, 201)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("user_id", response_data)
        
        # Verify user was created in database
        with flask_app.app_context():
            user = User.find_by_email("newuser@example.com")
            self.assertIsNotNone(user)
            self.assertEqual(user.first_name, "New")
            self.assertEqual(user.last_name, "User")
            self.assertEqual(user.role, "user")
    
    def test_user_registration_duplicate_email(self):
        """Test registration with an email that already exists."""
        # Test data with existing email
        duplicate_user_data = {
            "email": TEST_USER_EMAIL,  # This email already exists
            "password": "AnotherPass456!",
            "firstName": "Duplicate",
            "lastName": "User",
            "role": "user"
        }
        
        # Send registration request
        response = self.client.post(
            '/register',
            data=json.dumps(duplicate_user_data),
            content_type='application/json'
        )
        
        # Check response - should fail with 400
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("already registered", response_data["message"].lower())
    
    def test_user_registration_invalid_email(self):
        """Test registration with an invalid email format."""
        # Test data with invalid email
        invalid_email_data = {
            "email": "not-an-email",  # Invalid email format
            "password": "ValidPass789!",
            "firstName": "Invalid",
            "lastName": "Email",
            "role": "user"
        }
        
        # Send registration request
        response = self.client.post(
            '/register',
            data=json.dumps(invalid_email_data),
            content_type='application/json'
        )
        
        # Check response - should fail with 400
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("invalid email", response_data["message"].lower())
    
    def test_user_registration_weak_password(self):
        """Test registration with a weak password."""
        # Test data with weak password
        weak_password_data = {
            "email": "weakpass@example.com",
            "password": "weak",  # Too short, no numbers
            "firstName": "Weak",
            "lastName": "Password",
            "role": "user"
        }
        
        # Send registration request
        response = self.client.post(
            '/register',
            data=json.dumps(weak_password_data),
            content_type='application/json'
        )
        
        # Check response - should fail with 400
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("password", response_data["message"].lower())
    
    def test_user_login_success(self):
        """Test successful user login."""
        # Login data
        login_data = {
            "email": TEST_USER_EMAIL,
            "password": TEST_USER_PASSWORD
        }
        
        # Send login request
        response = self.client.post(
            '/login',
            data=json.dumps(login_data),
            content_type='application/json'
        )
        
        # Check response
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("user_id", response_data)
        self.assertIn("user", response_data)
        
        # Check that session was created
        with self.client.session_transaction() as session:
            self.assertIn('user_id', session)
    
    def test_user_login_invalid_credentials(self):
        """Test login with invalid credentials."""
        # Login data with wrong password
        login_data = {
            "email": TEST_USER_EMAIL,
            "password": "WrongPassword123!"
        }
        
        # Send login request
        response = self.client.post(
            '/login',
            data=json.dumps(login_data),
            content_type='application/json'
        )
        
        # Check response - should fail with 401
        self.assertEqual(response.status_code, 401)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("invalid credentials", response_data["message"].lower())
        
        # Check that no session was created
        with self.client.session_transaction() as session:
            self.assertNotIn('user_id', session)
    
    def test_user_login_nonexistent_user(self):
        """Test login with a non-existent user."""
        # Login data with non-existent email
        login_data = {
            "email": "nonexistent@example.com",
            "password": "AnyPassword123!"
        }
        
        # Send login request
        response = self.client.post(
            '/login',
            data=json.dumps(login_data),
            content_type='application/json'
        )
        
        # Check response - should fail with 401
        self.assertEqual(response.status_code, 401)
        response_data = json.loads(response.data)
        self.assertIn("message", response_data)
        self.assertIn("invalid credentials", response_data["message"].lower())
    
    def test_user_logout(self):
        """Test user logout functionality."""
        # First login
        login_data = {
            "email": TEST_USER_EMAIL,
            "password": TEST_USER_PASSWORD
        }
        
        self.client.post(
            '/login',
            data=json.dumps(login_data),
            content_type='application/json'
        )
        
        # Verify login was successful
        with self.client.session_transaction() as session:
            self.assertIn('user_id', session)
        
        # Now logout
        response = self.client.get('/logout')
        
        # Check redirect
        self.assertEqual(response.status_code, 302)
        
        # Verify session was cleared
        with self.client.session_transaction() as session:
            self.assertNotIn('user_id', session)
    
    def test_dashboard_authenticated(self):
        """Test accessing dashboard when authenticated."""
        # First login
        login_data = {
            "email": TEST_USER_EMAIL,
            "password": TEST_USER_PASSWORD
        }
        
        self.client.post(
            '/login',
            data=json.dumps(login_data),
            content_type='application/json'
        )
        
        # Access dashboard
        response = self.client.get('/dashboard')
        
        # Check response
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.data)
        self.assertIn("user", response_data)
    
    def test_dashboard_unauthenticated(self):
        """Test accessing dashboard when not authenticated."""
        # Access dashboard without logging in
        response = self.client.get('/dashboard')
        
        # Check response - should redirect to login
        self.assertEqual(response.status_code, 302)
        self.assertTrue(re.search(r'/login$', response.location))
    
    @patch('main.oauth')
    def test_social_login_redirect(self, mock_oauth):
        """Test social login redirect."""
        # Mock oauth client
        mock_client = MagicMock()
        mock_oauth.create_client.return_value = mock_client
        mock_client.authorize_redirect.return_value = "redirect_response"
        
        # Test Google social login
        response = self.client.get('/login/google')
        
        # Check that oauth client was created and redirect was called
        mock_oauth.create_client.assert_called_once_with("google")
        mock_client.authorize_redirect.assert_called_once()
    
    @patch('main.oauth')
    def test_social_login_authorize(self, mock_oauth):
        """Test social login authorization callback."""
        # Mock oauth client
        mock_client = MagicMock()
        mock_oauth.create_client.return_value = mock_client
        
        # Mock token and user info
        mock_client.authorize_access_token.return_value = {"token": "sample_token"}
        mock_client.userinfo.return_value = {
            "email": "social@example.com",
            "name": "Social User"
        }
        
        # Test Google authorization callback
        response = self.client.get('/authorize/google')
        
        # Check redirect
        self.assertEqual(response.status_code, 302)
        self.assertTrue(re.search(r'/dashboard$', response.location))
        
        # Verify user creation
        with flask_app.app_context():
            user = User.find_by_email("social@example.com")
            self.assertIsNotNone(user)
            
        # Verify session was created
        with self.client.session_transaction() as session:
            self.assertIn('user_id', session)


class TestJWTFunctionality(unittest.TestCase):
    """Test case for JWT token functionality."""
    
    def test_generate_token(self):
        """Test JWT token generation."""
        # Generate a token
        token = generate_token("123", "user", {"custom": "claim"})
        
        # Verify token is not empty
        self.assertTrue(token)
        
        # Decode the token
        decoded = jwt.decode(token, os.getenv("JWT_SECRET_KEY", "supersecuresecretkey"), algorithms=["HS256"])
        
        # Check claims
        self.assertEqual(decoded["sub"], "123")
        self.assertEqual(decoded["role"], "user")
        self.assertEqual(decoded["custom"], "claim")
        
        # Check expiration
        self.assertTrue("exp" in decoded)
        self.assertTrue(decoded["exp"] > time.time())
    
    def test_verify_token(self):
        """Test JWT token verification."""
        # Generate a token
        token = generate_token("123", "user")
        
        # Verify the token
        payload = verify_token(token)
        
        # Check claims
        self.assertEqual(payload["sub"], "123")
        self.assertEqual(payload["role"], "user")
    
    def test_verify_token_expired(self):
        """Test verification of an expired JWT token."""
        # Create an expired token manually
        payload = {
            "sub": "123",
            "role": "user",
            "exp": time.time() - 3600  # Expired 1 hour ago
        }
        expired_token = jwt.encode(payload, os.getenv("JWT_SECRET_KEY", "supersecuresecretkey"), algorithm="HS256")
        
        # Verify the token - should raise ExpiredSignatureError
        with self.assertRaises(jwt.ExpiredSignatureError):
            verify_token(expired_token)
    
    def test_verify_token_invalid(self):
        """Test verification of an invalid JWT token."""
        # Create an invalid token
        invalid_token = "not.a.valid.token"
        
        # Verify the token - should raise InvalidTokenError
        with self.assertRaises(jwt.InvalidTokenError):
            verify_token(invalid_token)


class TestPasswordFunctionality(unittest.TestCase):
    """Test case for password functionality."""
    
    def test_password_hashing(self):
        """Test password hashing."""
        # Hash a password
        password = "SecurePassword123!"
        password_hash = security_generate_password_hash(password)
        
        # Verify hash is not the plaintext password
        self.assertNotEqual(password, password_hash)
        
        # Verify the same password generates a different hash (due to salt)
        another_hash = security_generate_password_hash(password)
        self.assertNotEqual(password_hash, another_hash)
    
    def test_validate_email(self):
        """Test email validation."""
        # Valid emails
        self.assertTrue(validate_email("user@example.com"))
        self.assertTrue(validate_email("user.name+tag@example.co.uk"))
        
        # Invalid emails
        self.assertFalse(validate_email("not an email"))
        self.assertFalse(validate_email("user@"))
        self.assertFalse(validate_email("@example.com"))
        self.assertFalse(validate_email(""))
        self.assertFalse(validate_email(None))
    
    def test_validate_password_strength(self):
        """Test password strength validation."""
        # Valid passwords
        self.assertTrue(validate_password_strength("SecurePass123"))
        self.assertTrue(validate_password_strength("1234abcd"))
        
        # Invalid passwords
        self.assertFalse(validate_password_strength("weak"))  # Too short
        self.assertFalse(validate_password_strength("onlyletters"))  # No numbers
        self.assertFalse(validate_password_strength("12345678"))  # No letters
        self.assertFalse(validate_password_strength(""))  # Empty
        self.assertFalse(validate_password_strength(None))  # None


@pytest.mark.parametrize(
    "email,expected",
    [
        ("user@example.com", True),
        ("user.name+tag@example.co.uk", True),
        ("not an email", False),
        ("user@", False),
        ("@example.com", False),
        ("", False),
        (None, False),
    ],
)
def test_validate_email_parametrized(email, expected):
    """Parametrized test for email validation."""
    assert validate_email(email) == expected


@pytest.mark.parametrize(
    "password,expected",
    [
        ("SecurePass123", True),
        ("1234abcd", True),
        ("weak", False),
        ("onlyletters", False),
        ("12345678", False),
        ("", False),
        (None, False),
    ],
)
def test_validate_password_strength_parametrized(password, expected):
    """Parametrized test for password strength validation."""
    assert validate_password_strength(password) == expected


def test_login_success(client):
    """Test successful login using pytest fixture."""
    # Login data
    login_data = {
        "email": TEST_USER_EMAIL,
        "password": TEST_USER_PASSWORD
    }
    
    # Send login request
    response = client.post(
        '/login',
        data=json.dumps(login_data),
        content_type='application/json'
    )
    
    # Check response
    assert response.status_code == 200
    response_data = json.loads(response.data)
    assert "message" in response_data
    assert "user_id" in response_data
    assert "user" in response_data
    
    # Check session
    with client.session_transaction() as session:
        assert 'user_id' in session


def test_security_headers(client):
    """Test security headers are set correctly."""
    # Make a request to any endpoint
    response = client.get('/')
    
    # Check security headers
    headers = response.headers
    
    # These are the headers we expect to see in secure applications
    expected_headers = {
        'Content-Security-Policy',
        'X-Content-Type-Options',
        'X-XSS-Protection',
        'X-Frame-Options',
        'Strict-Transport-Security'
    }
    
    # Check that all expected headers are present
    for header in expected_headers:
        assert header in headers, f"Missing security header: {header}"
    
    # Check specific header values
    assert headers['X-Content-Type-Options'] == 'nosniff'
    assert headers['X-XSS-Protection'] == '1; mode=block'
    assert headers['X-Frame-Options'] in ['DENY', 'SAMEORIGIN']


if __name__ == '__main__':
    unittest.main()