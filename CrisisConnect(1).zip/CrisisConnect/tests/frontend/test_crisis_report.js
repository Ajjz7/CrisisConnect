import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BrowserRouter } from 'react-router-dom';
import { act } from 'react-dom/test-utils';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import CrisisReportForm from '../../src/components/crisis/CrisisReportForm';
import { AuthProvider } from '../../src/contexts/AuthContext';
import { NotificationProvider } from '../../src/contexts/NotificationContext';

// Mock axios
const mockAxios = new MockAdapter(axios);

// Mock geolocation API
const mockGeolocation = {
  getCurrentPosition: jest.fn().mockImplementation((success) => {
    success({
      coords: {
        latitude: 40.7128,
        longitude: -74.0060
      }
    });
  }),
  watchPosition: jest.fn()
};

// Mock the Google Maps Geocoding API response
const mockGeocodingResponse = {
  results: [
    {
      formatted_address: 'New York, NY, USA',
      address_components: [
        { long_name: 'New York', short_name: 'NY', types: ['locality', 'political'] },
        { long_name: 'New York', short_name: 'NY', types: ['administrative_area_level_1', 'political'] },
        { long_name: 'United States', short_name: 'US', types: ['country', 'political'] }
      ],
      geometry: {
        location: {
          lat: 40.7128,
          lng: -74.0060
        }
      }
    }
  ],
  status: 'OK'
};

// Mock the redirect function from react-router-dom
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn()
}));

// Helper function to render with providers
const renderWithProviders = (ui) => {
  return render(
    <BrowserRouter>
      <AuthProvider>
        <NotificationProvider>
          {ui}
        </NotificationProvider>
      </AuthProvider>
    </BrowserRouter>
  );
};

describe('Crisis Report Form Tests', () => {
  beforeEach(() => {
    // Reset the mock adapter before each test
    mockAxios.reset();
    
    // Mock navigator.geolocation
    global.navigator.geolocation = mockGeolocation;
    
    // Mock Geocoding API
    mockAxios.onGet(/maps.googleapis.com\/maps\/api\/geocode/).reply(200, mockGeocodingResponse);
    
    // Set up the mock user in localStorage
    localStorage.setItem('user', JSON.stringify({
      id: '123',
      email: 'test@example.com',
      firstName: 'Test',
      lastName: 'User',
      role: 'user'
    }));
    
    // Reset all mocks
    jest.clearAllMocks();
  });

  afterEach(() => {
    localStorage.clear();
  });

  test('renders crisis report form correctly', () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Check for form elements
    expect(screen.getByRole('heading', { name: /report a crisis/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/crisis type/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/description/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/location/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /use my current location/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /submit report/i })).toBeInTheDocument();
  });

  test('validates required fields', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Get submit button
    const submitButton = screen.getByRole('button', { name: /submit report/i });
    
    // Submit without filling fields
    await act(async () => {
      fireEvent.click(submitButton);
    });
    
    // Check for validation errors
    expect(screen.getByText(/crisis type is required/i)).toBeInTheDocument();
    expect(screen.getByText(/description is required/i)).toBeInTheDocument();
    expect(screen.getByText(/location is required/i)).toBeInTheDocument();
  });

  test('uses current location when button is clicked', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Get location button and location input
    const locationButton = screen.getByRole('button', { name: /use my current location/i });
    const locationInput = screen.getByLabelText(/location/i);
    
    // Click the location button
    await act(async () => {
      fireEvent.click(locationButton);
    });
    
    // Wait for geolocation and geocoding to complete
    await waitFor(() => {
      // Verify geolocation was called
      expect(global.navigator.geolocation.getCurrentPosition).toHaveBeenCalled();
      
      // Verify location input was populated
      expect(locationInput.value).toBe('New York, NY, USA');
    });
  });

  test('handles crisis type selection', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Get crisis type select
    const crisisTypeSelect = screen.getByLabelText(/crisis type/i);
    
    // Select a crisis type
    await act(async () => {
      fireEvent.change(crisisTypeSelect, { target: { value: 'flood' } });
    });
    
    // Verify selection
    expect(crisisTypeSelect.value).toBe('flood');
  });

  test('handles description input', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Get description textarea
    const descriptionInput = screen.getByLabelText(/description/i);
    
    // Enter description
    await act(async () => {
      fireEvent.change(descriptionInput, { 
        target: { value: 'Flooding in downtown area. Water level is rising quickly.' } 
      });
    });
    
    // Verify input
    expect(descriptionInput.value).toBe('Flooding in downtown area. Water level is rising quickly.');
  });

  test('handles manual location input', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Get location input
    const locationInput = screen.getByLabelText(/location/i);
    
    // Enter location
    await act(async () => {
      fireEvent.change(locationInput, { target: { value: 'Los Angeles, CA' } });
    });
    
    // Verify input
    expect(locationInput.value).toBe('Los Angeles, CA');
  });

  test('handles successful crisis report submission', async () => {
    // Mock successful report submission
    mockAxios.onPost('/crisis/report').reply(201, {
      message: 'Crisis report created successfully',
      report_id: '456',
      trust_score: 75,
      responder_notified: false
    });
    
    renderWithProviders(<CrisisReportForm />);
    
    // Get form elements
    const crisisTypeSelect = screen.getByLabelText(/crisis type/i);
    const descriptionInput = screen.getByLabelText(/description/i);
    const locationInput = screen.getByLabelText(/location/i);
    const submitButton = screen.getByRole('button', { name: /submit report/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(crisisTypeSelect, { target: { value: 'flood' } });
      fireEvent.change(descriptionInput, { 
        target: { value: 'Flooding in downtown area. Water level is rising quickly.' } 
      });
      fireEvent.change(locationInput, { target: { value: 'New York, NY' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Verify axios was called with correct data
      expect(mockAxios.history.post[0].url).toBe('/crisis/report');
      const requestData = JSON.parse(mockAxios.history.post[0].data);
      expect(requestData.crisis_type).toBe('flood');
      expect(requestData.description).toBe('Flooding in downtown area. Water level is rising quickly.');
      expect(requestData.location).toBe('New York, NY');
    });
    
    // Check for success message
    expect(screen.getByText(/crisis report created successfully/i)).toBeInTheDocument();
    expect(screen.getByText(/trust score: 75/i)).toBeInTheDocument();
  });

  test('handles failed crisis report submission', async () => {
    // Mock failed report submission
    mockAxios.onPost('/crisis/report').reply(400, {
      message: 'Failed to create crisis report: Invalid data'
    });
    
    renderWithProviders(<CrisisReportForm />);
    
    // Get form elements
    const crisisTypeSelect = screen.getByLabelText(/crisis type/i);
    const descriptionInput = screen.getByLabelText(/description/i);
    const locationInput = screen.getByLabelText(/location/i);
    const submitButton = screen.getByRole('button', { name: /submit report/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(crisisTypeSelect, { target: { value: 'flood' } });
      fireEvent.change(descriptionInput, { 
        target: { value: 'Test description' } 
      });
      fireEvent.change(locationInput, { target: { value: 'Test location' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Check for error message
      expect(screen.getByText(/failed to create crisis report: invalid data/i)).toBeInTheDocument();
    });
  });

  test('handles server error during submission', async () => {
    // Mock server error
    mockAxios.onPost('/crisis/report').reply(500, {
      message: 'Server error'
    });
    
    renderWithProviders(<CrisisReportForm />);
    
    // Get form elements
    const crisisTypeSelect = screen.getByLabelText(/crisis type/i);
    const descriptionInput = screen.getByLabelText(/description/i);
    const locationInput = screen.getByLabelText(/location/i);
    const submitButton = screen.getByRole('button', { name: /submit report/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(crisisTypeSelect, { target: { value: 'flood' } });
      fireEvent.change(descriptionInput, { 
        target: { value: 'Test description' } 
      });
      fireEvent.change(locationInput, { target: { value: 'Test location' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Check for error message
      expect(screen.getByText(/an error occurred. please try again later/i)).toBeInTheDocument();
    });
  });

  test('shows loading state during submission', async () => {
    // Mock report submission with delay
    mockAxios.onPost('/crisis/report').reply(() => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve([201, {
            message: 'Crisis report created successfully',
            report_id: '456',
            trust_score: 75,
            responder_notified: false
          }]);
        }, 100);
      });
    });
    
    renderWithProviders(<CrisisReportForm />);
    
    // Get form elements
    const crisisTypeSelect = screen.getByLabelText(/crisis type/i);
    const descriptionInput = screen.getByLabelText(/description/i);
    const locationInput = screen.getByLabelText(/location/i);
    const submitButton = screen.getByRole('button', { name: /submit report/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(crisisTypeSelect, { target: { value: 'flood' } });
      fireEvent.change(descriptionInput, { 
        target: { value: 'Test description' } 
      });
      fireEvent.change(locationInput, { target: { value: 'Test location' } });
      fireEvent.click(submitButton);
    });
    
    // Check for loading state
    expect(screen.getByText(/submitting/i)).toBeInTheDocument();
    expect(submitButton).toBeDisabled();
    
    // Wait for the async operations to complete
    await waitFor(() => {
      expect(screen.getByText(/crisis report created successfully/i)).toBeInTheDocument();
    });
  });

  test('handles geolocation error', async () => {
    // Override the geolocation mock to simulate an error
    global.navigator.geolocation.getCurrentPosition = jest.fn().mockImplementation((success, error) => {
      error({ code: 1, message: 'User denied geolocation' });
    });
    
    renderWithProviders(<CrisisReportForm />);
    
    // Get location button
    const locationButton = screen.getByRole('button', { name: /use my current location/i });
    
    // Click the location button
    await act(async () => {
      fireEvent.click(locationButton);
    });
    
    // Wait for geolocation to fail
    await waitFor(() => {
      // Verify error message
      expect(screen.getByText(/could not get your location: user denied geolocation/i)).toBeInTheDocument();
    });
  });

  test('handles additional information input', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Check if additional information section exists
    const severitySelect = screen.getByLabelText(/severity/i);
    const peopleAffectedInput = screen.getByLabelText(/people affected/i);
    
    // Enter additional information
    await act(async () => {
      fireEvent.change(severitySelect, { target: { value: 'high' } });
      fireEvent.change(peopleAffectedInput, { target: { value: '50' } });
    });
    
    // Verify inputs
    expect(severitySelect.value).toBe('high');
    expect(peopleAffectedInput.value).toBe('50');
  });

  test('includes additional information in submission', async () => {
    // Mock successful report submission
    mockAxios.onPost('/crisis/report').reply(201, {
      message: 'Crisis report created successfully',
      report_id: '456',
      trust_score: 75,
      responder_notified: true
    });
    
    renderWithProviders(<CrisisReportForm />);
    
    // Get form elements
    const crisisTypeSelect = screen.getByLabelText(/crisis type/i);
    const descriptionInput = screen.getByLabelText(/description/i);
    const locationInput = screen.getByLabelText(/location/i);
    const severitySelect = screen.getByLabelText(/severity/i);
    const peopleAffectedInput = screen.getByLabelText(/people affected/i);
    const submitButton = screen.getByRole('button', { name: /submit report/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(crisisTypeSelect, { target: { value: 'flood' } });
      fireEvent.change(descriptionInput, { 
        target: { value: 'Flooding in downtown area. Water level is rising quickly.' } 
      });
      fireEvent.change(locationInput, { target: { value: 'New York, NY' } });
      fireEvent.change(severitySelect, { target: { value: 'high' } });
      fireEvent.change(peopleAffectedInput, { target: { value: '50' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Verify axios was called with correct data including additional information
      const requestData = JSON.parse(mockAxios.history.post[0].data);
      expect(requestData.crisis_type).toBe('flood');
      expect(requestData.severity).toBe('high');
      expect(requestData.people_affected).toBe('50');
    });
    
    // Check for responder notification status
    expect(screen.getByText(/emergency responders have been notified/i)).toBeInTheDocument();
  });

  test('validates image upload size', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Get image upload input
    const imageInput = screen.getByLabelText(/upload images/i);
    
    // Create a mock file that exceeds size limit (11MB)
    const largeFile = new File(['x'.repeat(11 * 1024 * 1024)], 'large-image.jpg', { type: 'image/jpeg' });
    
    // Upload file
    await act(async () => {
      fireEvent.change(imageInput, { target: { files: [largeFile] } });
    });
    
    // Verify error message
    expect(screen.getByText(/file size exceeds 10mb limit/i)).toBeInTheDocument();
  });

  test('handles image upload preview', async () => {
    renderWithProviders(<CrisisReportForm />);
    
    // Get image upload input
    const imageInput = screen.getByLabelText(/upload images/i);
    
    // Create a mock file
    const file = new File(['dummy content'], 'test-image.jpg', { type: 'image/jpeg' });
    Object.defineProperty(file, 'size', { value: 1024 * 1024 }); // 1MB
    
    // Create a URL for the file preview
    URL.createObjectURL = jest.fn(() => 'blob:test-url');
    
    // Upload file
    await act(async () => {
      fireEvent.change(imageInput, { target: { files: [file] } });
    });
    
    // Verify preview is shown
    const previewImg = screen.getByAltText(/crisis image preview/i);
    expect(previewImg).toBeInTheDocument();
    expect(previewImg).toHaveAttribute('src', 'blob:test-url');
  });

  test('handles anonymous reporting option', async () => {
    // Mock successful report submission
    mockAxios.onPost('/crisis/report').reply(201, {
      message: 'Crisis report created successfully',
      report_id: '456',
      trust_score: 60, // Lower trust score for anonymous report
      responder_notified: false
    });
    
    renderWithProviders(<CrisisReportForm />);
    
    // Get form elements
    const crisisTypeSelect = screen.getByLabelText(/crisis type/i);
    const descriptionInput = screen.getByLabelText(/description/i);
    const locationInput = screen.getByLabelText(/location/i);
    const anonymousCheckbox = screen.getByLabelText(/report anonymously/i);
    const submitButton = screen.getByRole('button', { name: /submit report/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(crisisTypeSelect, { target: { value: 'flood' } });
      fireEvent.change(descriptionInput, { 
        target: { value: 'Flooding in downtown area.' } 
      });
      fireEvent.change(locationInput, { target: { value: 'New York, NY' } });
      fireEvent.click(anonymousCheckbox);
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Verify axios was called with anonymous flag
      const requestData = JSON.parse(mockAxios.history.post[0].data);
      expect(requestData.anonymous).toBe(true);
    });
    
    // Check for lower trust score
    expect(screen.getByText(/trust score: 60/i)).toBeInTheDocument();
  });
});