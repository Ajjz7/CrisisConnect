import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BrowserRouter } from 'react-router-dom';
import { act } from 'react-dom/test-utils';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import Login from '../../src/components/auth/Login';
import { AuthProvider } from '../../src/contexts/AuthContext';

// Mock axios
const mockAxios = new MockAdapter(axios);

// Mock the redirect function from react-router-dom
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => jest.fn(),
}));

// Helper function to render with providers
const renderWithProviders = (ui) => {
  return render(
    <BrowserRouter>
      <AuthProvider>
        {ui}
      </AuthProvider>
    </BrowserRouter>
  );
};

describe('Login Component Tests', () => {
  beforeEach(() => {
    // Reset the mock adapter before each test
    mockAxios.reset();
    
    // Clear localStorage before each test
    localStorage.clear();
    
    // Reset all mocks
    jest.clearAllMocks();
  });

  test('renders login form correctly', () => {
    renderWithProviders(<Login />);
    
    // Check for form elements
    expect(screen.getByRole('heading', { name: /login/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /sign in/i })).toBeInTheDocument();
    
    // Check for social login buttons
    expect(screen.getByRole('button', { name: /google/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /facebook/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /linkedin/i })).toBeInTheDocument();
    
    // Check for registration link
    expect(screen.getByText(/don't have an account/i)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: /register/i })).toBeInTheDocument();
  });

  test('validates email format', async () => {
    renderWithProviders(<Login />);
    
    // Get form elements
    const emailInput = screen.getByLabelText(/email/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });
    
    // Type invalid email and submit
    await act(async () => {
      fireEvent.change(emailInput, { target: { value: 'invalidemail' } });
      fireEvent.click(submitButton);
    });
    
    // Check for validation error
    expect(screen.getByText(/please enter a valid email/i)).toBeInTheDocument();
  });

  test('validates required fields', async () => {
    renderWithProviders(<Login />);
    
    // Get submit button
    const submitButton = screen.getByRole('button', { name: /sign in/i });
    
    // Submit without filling fields
    await act(async () => {
      fireEvent.click(submitButton);
    });
    
    // Check for validation errors
    expect(screen.getByText(/email is required/i)).toBeInTheDocument();
    expect(screen.getByText(/password is required/i)).toBeInTheDocument();
  });

  test('handles successful login', async () => {
    // Mock successful login response
    mockAxios.onPost('/login').reply(200, {
      message: 'Login successful',
      user_id: '123',
      user: {
        id: '123',
        email: 'test@thecrisisconnect.com',
        firstName: 'Test',
        lastName: 'User',
        role: 'user'
      }
    });
    
    renderWithProviders(<Login />);
    
    // Get form elements
    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(emailInput, { target: { value: 'test@thecrisisconnect.com' } });
      fireEvent.change(passwordInput, { target: { value: 'password123' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Verify axios was called with correct data
      expect(mockAxios.history.post[0].data).toBe(JSON.stringify({
        email: 'test@thecrisisconnect.com',
        password: 'password123'
      }));
    });
    
    // Check for success message
    expect(screen.getByText(/login successful/i)).toBeInTheDocument();
  });

  test('handles failed login', async () => {
    // Mock failed login response
    mockAxios.onPost('/login').reply(401, {
      message: 'Invalid credentials'
    });
    
    renderWithProviders(<Login />);
    
    // Get form elements
    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(emailInput, { target: { value: 'test@thecrisisconnect.com' } });
      fireEvent.change(passwordInput, { target: { value: 'wrongpassword' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Check for error message
      expect(screen.getByText(/invalid credentials/i)).toBeInTheDocument();
    });
  });

  test('handles server error during login', async () => {
    // Mock server error
    mockAxios.onPost('/login').reply(500, {
      message: 'Server error'
    });
    
    renderWithProviders(<Login />);
    
    // Get form elements
    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(emailInput, { target: { value: 'test@thecrisisconnect.com' } });
      fireEvent.change(passwordInput, { target: { value: 'password123' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Check for error message
      expect(screen.getByText(/an error occurred. please try again later/i)).toBeInTheDocument();
    });
  });

  test('redirects to social login endpoints', () => {
    // Create a spy on window.location.href
    const locationSpy = jest.spyOn(window.location, 'href', 'set');
    
    renderWithProviders(<Login />);
    
    // Get social login buttons
    const googleButton = screen.getByRole('button', { name: /google/i });
    const facebookButton = screen.getByRole('button', { name: /facebook/i });
    const linkedinButton = screen.getByRole('button', { name: /linkedin/i });
    
    // Click Google login button
    fireEvent.click(googleButton);
    expect(locationSpy).toHaveBeenCalledWith('/login/google');
    
    // Click Facebook login button
    fireEvent.click(facebookButton);
    expect(locationSpy).toHaveBeenCalledWith('/login/facebook');
    
    // Click LinkedIn login button
    fireEvent.click(linkedinButton);
    expect(locationSpy).toHaveBeenCalledWith('/login/linkedin');
    
    // Restore the spy
    locationSpy.mockRestore();
  });

  test('navigates to registration page', () => {
    renderWithProviders(<Login />);
    
    // Find the registration link
    const registerLink = screen.getByRole('link', { name: /register/i });
    
    // Verify the link has the correct href
    expect(registerLink).toHaveAttribute('href', '/register');
  });

  test('persists user session after successful login', async () => {
    // Mock successful login response
    mockAxios.onPost('/login').reply(200, {
      message: 'Login successful',
      user_id: '123',
      user: {
        id: '123',
        email: 'test@thecrisisconnect.com',
        firstName: 'Test',
        lastName: 'User',
        role: 'user'
      }
    });
    
    renderWithProviders(<Login />);
    
    // Get form elements
    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(emailInput, { target: { value: 'test@thecrisisconnect.com' } });
      fireEvent.change(passwordInput, { target: { value: 'password123' } });
      fireEvent.click(submitButton);
    });
    
    // Wait for the async operations to complete
    await waitFor(() => {
      // Verify user data was stored in localStorage
      const storedUser = JSON.parse(localStorage.getItem('user'));
      expect(storedUser).toEqual({
        id: '123',
        email: 'test@thecrisisconnect.com',
        firstName: 'Test',
        lastName: 'User',
        role: 'user'
      });
    });
  });

  test('shows loading state during login process', async () => {
    // Mock login response with delay
    mockAxios.onPost('/login').reply(() => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve([200, {
            message: 'Login successful',
            user_id: '123',
            user: {
              id: '123',
              email: 'test@thecrisisconnect.com',
              firstName: 'Test',
              lastName: 'User',
              role: 'user'
            }
          }]);
        }, 100);
      });
    });
    
    renderWithProviders(<Login />);
    
    // Get form elements
    const emailInput = screen.getByLabelText(/email/i);
    const passwordInput = screen.getByLabelText(/password/i);
    const submitButton = screen.getByRole('button', { name: /sign in/i });
    
    // Fill form and submit
    await act(async () => {
      fireEvent.change(emailInput, { target: { value: 'test@example.com' } });
      fireEvent.change(passwordInput, { target: { value: 'password123' } });
      fireEvent.click(submitButton);
    });
    
    // Check for loading state
    expect(screen.getByText(/signing in/i)).toBeInTheDocument();
    expect(submitButton).toBeDisabled();
    
    // Wait for the async operations to complete
    await waitFor(() => {
      expect(screen.getByText(/login successful/i)).toBeInTheDocument();
    });
  });
});