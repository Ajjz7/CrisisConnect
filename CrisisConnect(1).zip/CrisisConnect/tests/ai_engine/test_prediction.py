import pytest
import numpy as np
import pandas as pd
import json
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock

# Import prediction modules (adjust these imports based on your actual structure)
from ai_engine.prediction import (
    CrisisPredictionModel,
    predict_crisis_evolution,
    load_model,
    preprocess_data,
    analyze_weather_impact,
    generate_prediction_report,
    PREDICTION_FEATURES
)


@pytest.fixture
def mock_model():
    """Mock the prediction model."""
    model = MagicMock()
    
    # Configure predict method to return realistic predictions
    model.predict.return_value = np.array([
        [0.85, 0.75, 0.65],  # Probability scores for different time horizons
    ])
    
    # Configure predict_proba method to return class probabilities
    model.predict_proba.return_value = np.array([
        [0.15, 0.25, 0.60],  # Probabilities for [improving, stable, worsening]
    ])
    
    return model


@pytest.fixture
def sample_crisis_data():
    """Create sample crisis data for testing."""
    return {
        "crisis_type": "flood",
        "severity": "high",
        "location": "new york",
        "reported_at": datetime.now().isoformat(),
        "current_metrics": {
            "water_level": 5.2,            # meters
            "affected_area": 12.5,         # square kilometers
            "population_density": 5000,    # people per square kilometer
            "infrastructure_damage": 0.35, # damage index (0-1)
            "resource_availability": 0.65, # resource index (0-1)
            "evacuation_rate": 0.45        # percentage evacuated (0-1)
        },
        "weather_forecast": {
            "precipitation_mm": 75.5,      # millimeters expected in next 24h
            "wind_speed_kmh": 45.2,        # kilometers per hour
            "temperature_c": 22.5,         # degrees Celsius
            "humidity": 0.85               # relative humidity (0-1)
        },
        "historical_data": {
            "previous_incidents": 3,       # number of similar incidents in area
            "recovery_time_days": 14.5,    # average recovery time in days
            "max_severity": 0.8            # historical maximum severity (0-1)
        }
    }


@pytest.fixture
def sample_historical_dataframe():
    """Create sample historical data DataFrame for testing."""
    # Create dates going back 14 days
    dates = [(datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(14)]
    
    # Create sample data
    data = {
        "date": dates,
        "crisis_type": ["flood"] * 14,
        "location": ["new york"] * 14,
        "severity_index": [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.85, 0.8, 0.7, 0.6, 0.5],
        "affected_area_km2": [2.0, 4.5, 7.0, 8.5, 10.0, 11.5, 12.0, 12.5, 12.5, 12.0, 11.0, 9.0, 7.5, 5.5],
        "water_level_m": [1.0, 1.8, 2.5, 3.2, 3.8, 4.5, 5.0, 5.2, 5.3, 5.2, 5.0, 4.5, 3.8, 3.2],
        "precipitation_mm": [25, 55, 65, 85, 70, 65, 45, 35, 30, 25, 15, 10, 5, 0],
        "temperature_c": [20, 21, 19, 18, 20, 22, 23, 22, 21, 22, 23, 24, 25, 26],
        "wind_speed_kmh": [15, 25, 35, 45, 40, 35, 30, 25, 20, 15, 10, 10, 5, 5],
        "evacuation_percentage": [0.05, 0.15, 0.25, 0.3, 0.35, 0.4, 0.45, 0.45, 0.45, 0.45, 0.4, 0.3, 0.2, 0.1]
    }
    
    return pd.DataFrame(data)


class TestCrisisPredictionModel:
    """Test the crisis prediction model class."""
    
    def test_model_initialization(self):
        """Test model initialization with default parameters."""
        model = CrisisPredictionModel()
        
        # Check default attributes
        assert model.model_type == "random_forest"
        assert model.feature_importance is None
        assert not model.is_trained
        
    def test_model_initialization_with_params(self):
        """Test model initialization with custom parameters."""
        model = CrisisPredictionModel(
            model_type="gradient_boosting",
            prediction_horizon=[24, 48, 72],
            features=["water_level", "precipitation", "temperature"]
        )
        
        # Check custom attributes
        assert model.model_type == "gradient_boosting"
        assert model.prediction_horizon == [24, 48, 72]
        assert model.features == ["water_level", "precipitation", "temperature"]
        
    @patch('ai_engine.prediction.joblib.load')
    def test_load_model(self, mock_joblib_load):
        """Test loading a model from file."""
        # Configure mock
        mock_model = MagicMock()
        mock_joblib_load.return_value = mock_model
        
        # Load model
        model = CrisisPredictionModel()
        model.load("dummy/path/model.joblib")
        
        # Verify model was loaded
        mock_joblib_load.assert_called_once_with("dummy/path/model.joblib")
        assert model.model == mock_model
        assert model.is_trained
        
    @patch('ai_engine.prediction.joblib.dump')
    def test_save_model(self, mock_joblib_dump):
        """Test saving a model to file."""
        # Create model with mock internal model
        model = CrisisPredictionModel()
        model.model = MagicMock()
        model.is_trained = True
        
        # Save model
        model.save("dummy/path/model.joblib")
        
        # Verify model was saved
        mock_joblib_dump.assert_called_once()
        args, kwargs = mock_joblib_dump.call_args
        assert args[0] == model.model
        assert args[1] == "dummy/path/model.joblib"
        
    def test_preprocess_features(self):
        """Test feature preprocessing for model input."""
        # Create model
        model = CrisisPredictionModel(features=["water_level", "precipitation", "affected_area"])
        
        # Sample data
        data = {
            "water_level": 5.2,
            "precipitation": 75.5,
            "affected_area": 12.5,
            "unused_feature": 100  # Should be ignored
        }
        
        # Preprocess features
        X = model.preprocess_features(data)
        
        # Verify result
        assert isinstance(X, np.ndarray)
        assert X.shape == (1, 3)
        assert X[0, 0] == 5.2
        assert X[0, 1] == 75.5
        assert X[0, 2] == 12.5
        
    @patch('ai_engine.prediction.RandomForestRegressor')
    def test_train_model(self, mock_rf):
        """Test model training."""
        # Configure mock
        mock_rf_instance = MagicMock()
        mock_rf.return_value = mock_rf_instance
        
        # Create sample data
        X = np.random.rand(100, 5)
        y = np.random.rand(100, 3)
        
        # Create and train model
        model = CrisisPredictionModel(features=["f1", "f2", "f3", "f4", "f5"])
        model.train(X, y)
        
        # Verify model was trained
        mock_rf.assert_called_once()
        mock_rf_instance.fit.assert_called_once_with(X, y)
        assert model.is_trained
        assert model.model == mock_rf_instance
        
    def test_predict(self, mock_model):
        """Test model prediction."""
        # Create model with mock
        model = CrisisPredictionModel()
        model.model = mock_model
        model.is_trained = True
        
        # Sample data
        data = {"water_level": 5.2, "precipitation": 75.5}
        
        # Make prediction
        prediction = model.predict(data)
        
        # Verify prediction
        assert isinstance(prediction, dict)
        assert "crisis_trend" in prediction
        assert "probability_scores" in prediction
        assert prediction["probability_scores"]["24h"] == 0.85
        assert prediction["probability_scores"]["48h"] == 0.75
        assert prediction["probability_scores"]["72h"] == 0.65
        assert prediction["crisis_trend"] == "worsening"  # Based on mock probabilities
        
    def test_predict_untrained_model(self):
        """Test prediction with untrained model raises error."""
        model = CrisisPredictionModel()
        
        # Attempt prediction with untrained model
        with pytest.raises(ValueError) as excinfo:
            model.predict({"water_level": 5.2})
        
        # Verify error message
        assert "Model is not trained" in str(excinfo.value)
        
    def test_get_feature_importance(self, mock_model):
        """Test feature importance extraction."""
        # Configure mock model with feature importance
        mock_model.feature_importances_ = np.array([0.3, 0.5, 0.2])
        
        # Create model with mock
        model = CrisisPredictionModel(features=["water_level", "precipitation", "affected_area"])
        model.model = mock_model
        model.is_trained = True
        
        # Get feature importance
        importance = model.get_feature_importance()
        
        # Verify result
        assert isinstance(importance, dict)
        assert len(importance) == 3
        assert importance["precipitation"] == 0.5  # Highest importance
        assert importance["water_level"] == 0.3
        assert importance["affected_area"] == 0.2


class TestPredictionFunctions:
    """Test individual prediction-related functions."""
    
    @patch('ai_engine.prediction.joblib.load')
    def test_load_model_function(self, mock_joblib_load):
        """Test the standalone load_model function."""
        # Configure mock
        mock_model = MagicMock()
        mock_joblib_load.return_value = mock_model
        
        # Load model
        result = load_model("dummy/path/model.joblib")
        
        # Verify
        mock_joblib_load.assert_called_once_with("dummy/path/model.joblib")
        assert result == mock_model
        
    def test_preprocess_data(self, sample_crisis_data):
        """Test data preprocessing function."""
        # Define features to extract
        features = ["water_level", "precipitation_mm", "affected_area", "evacuation_rate"]
        
        # Preprocess data
        result = preprocess_data(sample_crisis_data, features)
        
        # Verify results
        assert isinstance(result, dict)
        assert "water_level" in result
        assert result["water_level"] == 5.2
        assert "precipitation_mm" in result
        assert result["precipitation_mm"] == 75.5
        assert "affected_area" in result
        assert result["affected_area"] == 12.5
        assert "evacuation_rate" in result
        assert result["evacuation_rate"] == 0.45
        
    def test_analyze_weather_impact(self, sample_crisis_data):
        """Test weather impact analysis function."""
        # Analyze weather impact
        impact = analyze_weather_impact(
            sample_crisis_data["crisis_type"],
            sample_crisis_data["weather_forecast"]
        )
        
        # Verify result
        assert isinstance(impact, dict)
        assert "severity_modifier" in impact
        assert "duration_modifier" in impact
        assert "key_factors" in impact
        
        # For floods, high precipitation should increase severity
        assert impact["severity_modifier"] > 0
        assert "precipitation" in impact["key_factors"]
        
    @patch('ai_engine.prediction.CrisisPredictionModel')
    def test_predict_crisis_evolution(self, mock_model_class, sample_crisis_data):
        """Test the crisis evolution prediction function."""
        # Configure mock
        mock_model_instance = MagicMock()
        mock_model_class.return_value = mock_model_instance
        
        # Configure predict method
        mock_model_instance.predict.return_value = {
            "crisis_trend": "worsening",
            "probability_scores": {
                "24h": 0.85,
                "48h": 0.75,
                "72h": 0.65
            }
        }
        
        # Make prediction
        prediction = predict_crisis_evolution(sample_crisis_data)
        
        # Verify prediction
        assert isinstance(prediction, dict)
        assert "trend" in prediction
        assert prediction["trend"] == "worsening"
        assert "confidence" in prediction
        assert 0 <= prediction["confidence"] <= 1
        assert "expected_duration" in prediction
        assert "next_48_hours" in prediction
        
    def test_generate_prediction_report(self, sample_crisis_data):
        """Test prediction report generation."""
        # Sample prediction
        prediction = {
            "trend": "worsening",
            "confidence": 0.85,
            "expected_duration": "72 hours",
            "next_48_hours": "Conditions expected to intensify"
        }
        
        # Generate report
        report = generate_prediction_report(sample_crisis_data, prediction)
        
        # Verify report
        assert isinstance(report, dict)
        assert "summary" in report
        assert "detailed_assessment" in report
        assert "key_factors" in report
        assert "action_recommendations" in report
        
        # Check for critical content
        assert "high" in report["summary"].lower()  # Severity mentioned
        assert "flood" in report["summary"].lower()  # Crisis type mentioned
        assert "worsening" in report["summary"].lower()  # Trend mentioned
        
        # Check for action recommendations
        assert len(report["action_recommendations"]) >= 3
        assert any("evacuat" in rec.lower() for rec in report["action_recommendations"])
        

class TestIntegrationWithHistoricalData:
    """Test integration with historical data for prediction."""
    
    def test_historical_data_analysis(self, sample_historical_dataframe):
        """Test analysis of historical data for model input."""
        # Create model
        model = CrisisPredictionModel()
        
        # Extract trends from historical data
        trends = model.analyze_historical_trends(sample_historical_dataframe)
        
        # Verify trends analysis
        assert isinstance(trends, dict)
        assert "severity_trend" in trends
        assert "duration_estimate" in trends
        assert "peak_timing" in trends
        
        # Based on our sample data, severity peaked and is now decreasing
        assert trends["severity_trend"] == "decreasing"
        
    @patch('ai_engine.prediction.CrisisPredictionModel.predict')
    def test_prediction_with_historical_context(self, mock_predict, sample_crisis_data, sample_historical_dataframe):
        """Test prediction with historical context integration."""
        # Configure mock
        mock_predict.return_value = {
            "crisis_trend": "improving",
            "probability_scores": {
                "24h": 0.65,
                "48h": 0.55,
                "72h": 0.45
            }
        }
        
        # Integrate historical data into prediction
        combined_prediction = predict_crisis_evolution(
            sample_crisis_data, 
            historical_data=sample_historical_dataframe
        )
        
        # Verify prediction includes historical context
        assert "historical_context" in combined_prediction
        assert "peak_comparison" in combined_prediction["historical_context"]
        assert "recovery_pattern" in combined_prediction["historical_context"]
        
        # The trend from historical data should influence the confidence
        assert 0 <= combined_prediction["confidence"] <= 1
        

class TestErrorHandling:
    """Test error handling in prediction functions."""
    
    def test_missing_required_features(self, sample_crisis_data):
        """Test handling of missing required features."""
        # Remove critical data
        incomplete_data = sample_crisis_data.copy()
        del incomplete_data["current_metrics"]["water_level"]
        
        # Attempt prediction
        with pytest.raises(ValueError) as excinfo:
            predict_crisis_evolution(incomplete_data)
            
        # Verify error message
        assert "Missing required feature" in str(excinfo.value)
        
    def test_unsupported_crisis_type(self):
        """Test handling of unsupported crisis types."""
        # Create data with unsupported crisis type
        data = {
            "crisis_type": "alien_invasion",
            "severity": "high",
            "current_metrics": {
                "water_level": 0,
                "affected_area": 50,
                "population_density": 5000
            },
            "weather_forecast": {
                "precipitation_mm": 0,
                "wind_speed_kmh": 20
            }
        }
        
        # Attempt prediction
        with pytest.raises(ValueError) as excinfo:
            predict_crisis_evolution(data)
            
        # Verify error message
        assert "Unsupported crisis type" in str(excinfo.value)
        
    @patch('ai_engine.prediction.CrisisPredictionModel.predict')
    def test_model_prediction_error(self, mock_predict, sample_crisis_data):
        """Test handling of model prediction errors."""
        # Configure mock to raise exception
        mock_predict.side_effect = Exception("Model prediction failed")
        
        # Attempt prediction
        with pytest.raises(RuntimeError) as excinfo:
            predict_crisis_evolution(sample_crisis_data)
            
        # Verify error message
        assert "Failed to generate prediction" in str(excinfo.value)
        

class TestPredictionValidation:
    """Test validation of prediction results."""
    
    @patch('ai_engine.prediction.CrisisPredictionModel')
    def test_validation_with_confidence_threshold(self, mock_model_class, sample_crisis_data):
        """Test validation of predictions against confidence threshold."""
        # Configure mock
        mock_model_instance = MagicMock()
        mock_model_class.return_value = mock_model_instance
        
        # Configure predict method with low confidence
        mock_model_instance.predict.return_value = {
            "crisis_trend": "worsening",
            "probability_scores": {
                "24h": 0.55,  # Lower confidence
                "48h": 0.52,
                "72h": 0.51
            }
        }
        
        # Make prediction with high threshold
        prediction = predict_crisis_evolution(
            sample_crisis_data,
            confidence_threshold=0.7  # Higher than our mocked values
        )
        
        # Verify prediction is appropriately flagged as low confidence
        assert prediction["confidence"] < 0.7
        assert "low_confidence_warning" in prediction
        assert prediction["low_confidence_warning"] is True
        
    @patch('ai_engine.prediction.CrisisPredictionModel')
    def test_contradictory_signals_handling(self, mock_model_class, sample_crisis_data):
        """Test handling of contradictory prediction signals."""
        # Configure mock
        mock_model_instance = MagicMock()
        mock_model_class.return_value = mock_model_instance
        
        # Configure predict method with contradictory signals
        # (improving short-term but worsening long-term)
        mock_model_instance.predict.return_value = {
            "crisis_trend": "mixed",
            "probability_scores": {
                "24h": 0.40,  # Improving
                "48h": 0.55,  # Neutral
                "72h": 0.75   # Worsening
            }
        }
        
        # Make prediction
        prediction = predict_crisis_evolution(sample_crisis_data)
        
        # Verify contradictory signals are highlighted
        assert "signal_consistency" in prediction
        assert prediction["signal_consistency"] == "contradictory"
        assert "detailed_trend" in prediction
        assert "short_term" in prediction["detailed_trend"]
        assert "long_term" in prediction["detailed_trend"]
        

if __name__ == '__main__':
    pytest.main()