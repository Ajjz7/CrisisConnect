import pytest
import json
import os
from unittest.mock import patch, MagicMock
from flask import session
from werkzeug.security import generate_password_hash

# Import the Flask app and database models
from main import flask_app, db, User
from database import validate_email, validate_password


@pytest.fixture
def client():
    """Create a test client for the Flask app."""
    # Configure the app for testing
    flask_app.config.update({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'SECRET_KEY': 'test_secret_key'
    })
    
    # Create the database and tables
    with flask_app.app_context():
        db.create_all()
    
    # Setup test client
    with flask_app.test_client() as client:
        # Enable session handling in tests
        with client.session_transaction() as sess:
            sess['_fresh'] = True
        yield client
    
    # Clean up
    with flask_app.app_context():
        db.drop_all()


@pytest.fixture
def auth_headers():
    """Return basic headers for authentication requests."""
    return {
        'Content-Type': 'application/json'
    }


@pytest.fixture
def sample_user():
    """Create a sample user for tests."""
    with flask_app.app_context():
        user = User(
            email='test@thecrisisconnect.com',
            password_hash=generate_password_hash('Password123'),
            first_name='Test',
            last_name='User',
            role='user'
        )
        db.session.add(user)
        db.session.commit()
        return user


@pytest.fixture
def mock_oauth():
    """Mock OAuth for social login testing."""
    with patch('main.oauth.create_client') as mock_oauth_client:
        # Set up the mock
        mock_client = MagicMock()
        mock_oauth_client.return_value = mock_client
        
        # Mock authorize_redirect
        mock_client.authorize_redirect.return_value = 'mock_redirect_response'
        
        # Mock authorize_access_token
        mock_client.authorize_access_token.return_value = {'token': 'mock_token'}
        
        # Mock userinfo
        mock_client.userinfo.return_value = {
            'email': 'social@thecrisisconnect.com',
            'name': 'Social User',
            'sub': '12345'
        }
        
        yield mock_oauth_client


class TestUserValidation:
    """Test user validation functions."""
    
    def test_validate_email_valid(self):
        """Test valid email addresses."""
        assert validate_email('user@example.com') is True
        assert validate_email('name.surname@domain.co.uk') is True
        assert validate_email('user+tag@example.com') is True
    
    def test_validate_email_invalid(self):
        """Test invalid email addresses."""
        assert validate_email('user@') is False
        assert validate_email('@example.com') is False
        assert validate_email('user@example') is False
        assert validate_email('plaintext') is False
        assert validate_email('') is False
        assert validate_email(None) is False
    
    def test_validate_password_valid(self):
        """Test valid passwords."""
        assert validate_password('Password123') is True
        assert validate_password('Secure-Password-789') is True
        assert validate_password('p@ssw0rd!') is True
    
    def test_validate_password_invalid(self):
        """Test invalid passwords."""
        # Too short
        assert validate_password('Pass1') is False
        # No numbers
        assert validate_password('PasswordOnly') is False
        # No letters
        assert validate_password('12345678') is False
        # Empty
        assert validate_password('') is False
        # None
        assert validate_password(None) is False


class TestRegistration:
    """Test user registration functionality."""
    
    def test_register_success(self, client, auth_headers):
        """Test successful user registration."""
        # Create user data
        user_data = {
            'email': 'newuser@example.com',
            'password': 'NewPassword123',
            'firstName': 'New',
            'lastName': 'User',
            'role': 'user'
        }
        
        # Register the user
        response = client.post(
            '/register',
            data=json.dumps(user_data),
            headers=auth_headers
        )
        
        # Check response
        assert response.status_code == 201
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'User registered successfully' in json_data['message']
        assert 'user_id' in json_data
        
        # Verify user was added to the database
        with flask_app.app_context():
            user = User.query.filter_by(email='newuser@example.com').first()
            assert user is not None
            assert user.first_name == 'New'
            assert user.last_name == 'User'
            assert user.role == 'user'
            assert user.verify_password('NewPassword123')
    
    def test_register_email_exists(self, client, auth_headers, sample_user):
        """Test registration with an email that already exists."""
        # Create user data with existing email
        user_data = {
            'email': 'test@example.com',  # Email used in sample_user fixture
            'password': 'AnotherPassword123',
            'firstName': 'Another',
            'lastName': 'User',
            'role': 'user'
        }
        
        # Attempt to register
        response = client.post(
            '/register',
            data=json.dumps(user_data),
            headers=auth_headers
        )
        
        # Check response
        assert response.status_code == 400
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'Email already registered' in json_data['message']
    
    def test_register_invalid_email(self, client, auth_headers):
        """Test registration with invalid email format."""
        # Create user data with invalid email
        user_data = {
            'email': 'invalid-email',
            'password': 'Password123',
            'firstName': 'New',
            'lastName': 'User',
            'role': 'user'
        }
        
        # Attempt to register
        response = client.post(
            '/register',
            data=json.dumps(user_data),
            headers=auth_headers
        )
        
        # Check response
        assert response.status_code == 400
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'Invalid email format' in json_data['message']
    
    def test_register_weak_password(self, client, auth_headers):
        """Test registration with weak password."""
        # Create user data with weak password
        user_data = {
            'email': 'newuser@example.com',
            'password': 'weak',
            'firstName': 'New',
            'lastName': 'User',
            'role': 'user'
        }
        
        # Attempt to register
        response = client.post(
            '/register',
            data=json.dumps(user_data),
            headers=auth_headers
        )
        
        # Check response
        assert response.status_code == 400
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'Password must be at least 8 characters' in json_data['message']


class TestLogin:
    """Test user login functionality."""
    
    def test_login_success(self, client, auth_headers, sample_user):
        """Test successful login."""
        # Create login data
        login_data = {
            'email': 'test@example.com',
            'password': 'Password123'
        }
        
        # Login
        response = client.post(
            '/login',
            data=json.dumps(login_data),
            headers=auth_headers
        )
        
        # Check response
        assert response.status_code == 200
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'Login successful' in json_data['message']
        assert 'user_id' in json_data
        assert 'user' in json_data
        
        # Check user data
        user = json_data['user']
        assert user['email'] == 'test@example.com'
        assert user['firstName'] == 'Test'
        assert user['lastName'] == 'User'
        assert 'password_hash' not in user  # Make sure sensitive data is not included
        
        # Verify session
        with client.session_transaction() as sess:
            assert 'user_id' in sess
            assert sess['user_id'] == sample_user.id
    
    def test_login_wrong_password(self, client, auth_headers, sample_user):
        """Test login with wrong password."""
        # Create login data with wrong password
        login_data = {
            'email': 'test@example.com',
            'password': 'WrongPassword123'
        }
        
        # Attempt to login
        response = client.post(
            '/login',
            data=json.dumps(login_data),
            headers=auth_headers
        )
        
        # Check response
        assert response.status_code == 401
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'Invalid credentials' in json_data['message']
        
        # Verify session (user_id should not be set)
        with client.session_transaction() as sess:
            assert 'user_id' not in sess
    
    def test_login_nonexistent_email(self, client, auth_headers):
        """Test login with email that doesn't exist."""
        # Create login data with non-existent email
        login_data = {
            'email': 'nonexistent@example.com',
            'password': 'Password123'
        }
        
        # Attempt to login
        response = client.post(
            '/login',
            data=json.dumps(login_data),
            headers=auth_headers
        )
        
        # Check response
        assert response.status_code == 401
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'Invalid credentials' in json_data['message']


class TestSocialLogin:
    """Test social login functionality."""
    
    def test_social_login_redirect(self, client, mock_oauth):
        """Test social login redirect."""
        # Test for each provider
        for provider in ['google', 'facebook', 'linkedin']:
            response = client.get(f'/login/{provider}')
            
            # Check that the OAuth client was created with the right provider
            mock_oauth.assert_called_with(provider)
            
            # Check that authorize_redirect was called
            mock_instance = mock_oauth.return_value
            mock_instance.authorize_redirect.assert_called_once()
            
            # Reset the mock for next iteration
            mock_oauth.reset_mock()
    
    def test_social_login_invalid_provider(self, client):
        """Test social login with invalid provider."""
        response = client.get('/login/invalid_provider')
        
        # Check response
        assert response.status_code == 400
        json_data = response.get_json()
        assert 'message' in json_data
        assert 'Unsupported provider' in json_data['message']
    
    def test_social_login_callback(self, client, mock_oauth):
        """Test social login callback (authorize endpoint)."""
        # Test the callback for Google
        with patch('main.User.find_by_email', return_value=None):
            with patch('main.User.create') as mock_create:
                # Set up the mock
                mock_user = MagicMock()
                mock_user.id = 999
                mock_create.return_value = mock_user
                
                # Call the authorize endpoint
                response = client.get('/authorize/google')
                
                # Check that the OAuth functions were called
                mock_oauth.assert_called_with('google')
                mock_instance = mock_oauth.return_value
                mock_instance.authorize_access_token.assert_called_once()
                mock_instance.userinfo.assert_called_once()
                
                # Check user was created
                mock_create.assert_called_once()
                
                # Verify session
                with client.session_transaction() as sess:
                    assert 'user_id' in sess
                    assert sess['user_id'] == 999
    
    def test_social_login_existing_user(self, client, mock_oauth, sample_user):
        """Test social login for existing user."""
        # Mock find_by_email to return our sample user
        with patch('main.User.find_by_email', return_value=sample_user):
            # Call the authorize endpoint
            response = client.get('/authorize/google')
            
            # Check OAuth functions were called
            mock_oauth.assert_called_with('google')
            mock_instance = mock_oauth.return_value
            mock_instance.authorize_access_token.assert_called_once()
            mock_instance.userinfo.assert_called_once()
            
            # Verify session
            with client.session_transaction() as sess:
                assert 'user_id' in sess
                assert sess['user_id'] == sample_user.id


class TestLogout:
    """Test logout functionality."""
    
    def test_logout(self, client, sample_user):
        """Test successful logout."""
        # First, login the user
        with client.session_transaction() as sess:
            sess['user_id'] = sample_user.id
        
        # Verify user is logged in
        with client.session_transaction() as sess:
            assert 'user_id' in sess
        
        # Logout
        response = client.get('/logout')
        
        # Check response is a redirect
        assert response.status_code == 302
        
        # Verify user is logged out (session cleared)
        with client.session_transaction() as sess:
            assert 'user_id' not in sess


if __name__ == '__main__':
    pytest.main()