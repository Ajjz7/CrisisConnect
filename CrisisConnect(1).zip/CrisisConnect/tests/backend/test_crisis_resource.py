import pytest
import json
import datetime
from unittest.mock import patch, MagicMock, AsyncMock
import asyncio

# Import the FastAPI app and functions
from main import fastapi_app, match_resources, translate_text
from fastapi.testclient import TestClient


@pytest.fixture
def client():
    """Create a test client for the FastAPI app."""
    return TestClient(fastapi_app)


@pytest.fixture
def mock_firebase():
    """Mock Firebase for crisis reports testing."""
    with patch('main.firebase_db.reference') as mock_ref:
        # Set up the mock
        mock_ref_instance = MagicMock()
        mock_ref.return_value = mock_ref_instance
        
        # Mock get method to return sample crisis reports
        mock_ref_instance.get.return_value = {
            'report1': {
                'id': 'report1',
                'crisis_type': 'flood',
                'location': 'new york',
                'description': 'Flooding in downtown area',
                'upvotes': 5,
                'downvotes': 1,
                'trust_score': 80,
                'responder_notified': True,
                'created_at': '2023-06-15T14:30:00Z'
            },
            'report2': {
                'id': 'report2',
                'crisis_type': 'wildfire',
                'location': 'los angeles',
                'description': 'Wildfire spreading in hills',
                'upvotes': 3,
                'downvotes': 0,
                'trust_score': 75,
                'responder_notified': True,
                'created_at': '2023-06-15T15:45:00Z'
            }
        }
        
        yield mock_ref


@pytest.fixture
def mock_aiohttp_session():
    """Mock aiohttp ClientSession for external API calls."""
    with patch('aiohttp.ClientSession') as mock_session:
        # Create mock for session
        session_instance = MagicMock()
        mock_session.return_value.__aenter__.return_value = session_instance
        
        # Mock response objects for various APIs
        fema_response = AsyncMock()
        fema_response.json.return_value = {
            'DisasterDeclarationsSummaries': [
                {
                    'disasterNumber': 4733,
                    'state': 'NY',
                    'declarationDate': '2023-06-14T00:00:00Z',
                    'disasterType': 'Flood'
                }
            ]
        }
        
        red_cross_response = AsyncMock()
        red_cross_response.json.return_value = {
            'relief_efforts': [
                {
                    'id': 'rc001',
                    'type': 'Shelter',
                    'location': 'New York High School',
                    'capacity': 200,
                    'currentOccupancy': 75
                }
            ]
        }
        
        who_response = AsyncMock()
        who_response.json.return_value = {
            'emergency_responses': [
                {
                    'id': 'who001',
                    'type': 'Medical',
                    'location': 'New York Central Hospital',
                    'status': 'Active'
                }
            ]
        }
        
        # Mock get method with different responses for different URLs
        async def mock_get(url, *args, **kwargs):
            if 'fema.gov' in url:
                return fema_response
            elif 'redcross.org' in url:
                return red_cross_response
            elif 'who.int' in url:
                return who_response
            else:
                raise ValueError(f"Unexpected URL: {url}")
                
        session_instance.get = mock_get
        
        # Mock post method for translation API
        translate_response = AsyncMock()
        translate_response.json.return_value = {
            'data': {
                'translations': [
                    {'translatedText': 'Refugios de Emergencia'},
                    {'translatedText': 'Bancos de Alimentos'},
                    {'translatedText': 'Ayuda Médica'}
                ]
            }
        }
        
        async def mock_post(url, *args, **kwargs):
            if 'translate' in url:
                return translate_response
            else:
                raise ValueError(f"Unexpected URL: {url}")
                
        session_instance.post = mock_post
        
        yield session_instance


class TestResourceMatching:
    """Test the AI-powered resource matching functionality."""
    
    @pytest.mark.asyncio
    async def test_match_resources_basic(self, client, mock_firebase, mock_aiohttp_session):
        """Test basic resource matching with minimal parameters."""
        # Define test data
        test_data = {
            'location': 'new york',
            'crisis_type': 'flood'
        }
        
        # Make the request
        response = client.post("/ai/match_resources", json=test_data)
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify basic structure
        assert 'timestamp' in data
        assert 'location' in data
        assert 'crisis_type' in data
        assert 'matched_resources' in data
        assert 'real_time_data' in data
        assert 'safety_instructions' in data
        
        # Verify location and crisis type
        assert data['location'] == 'new york'
        assert data['crisis_type'] == 'flood'
        
        # Verify resources were matched
        assert len(data['matched_resources']) > 0
        assert 'Flood Rescue Teams' in data['matched_resources']
        assert 'Drinking Water Distribution' in data['matched_resources']
        
        # Verify real-time data
        assert 'FEMA' in data['real_time_data']
        assert 'RedCross' in data['real_time_data']
        assert 'WHO' in data['real_time_data']
        
        # Verify safety instructions
        assert len(data['safety_instructions']) > 0
        assert any('higher ground' in instr.lower() for instr in data['safety_instructions'])
    
    @pytest.mark.asyncio
    async def test_match_resources_comprehensive(self, client, mock_firebase, mock_aiohttp_session):
        """Test comprehensive resource matching with all parameters."""
        # Define test data
        test_data = {
            'location': 'new york',
            'crisis_type': 'flood',
            'user_needs': ['medical', 'shelter', 'transportation'],
            'severity': 'high',
            'special_needs': True,
            'has_children': True,
            'has_pets': True,
            'transportation': False,
            'language': 'es'  # Spanish
        }
        
        # Make the request
        response = client.post("/ai/match_resources", json=test_data)
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify all fields are present
        assert 'timestamp' in data
        assert 'location' in data
        assert 'crisis_type' in data
        assert 'severity' in data
        assert 'matched_resources' in data
        assert 'real_time_data' in data
        assert 'crowdsourced_reports' in data
        assert 'weather_data' in data
        assert 'environmental_data' in data
        assert 'safety_instructions' in data
        assert 'crisis_prediction' in data
        assert 'evacuation_routes' in data
        assert 'emergency_contacts' in data
        
        # Verify specialized resources based on parameters
        resources = data['matched_resources']
        
        # Should have medical resources (from user_needs)
        assert 'Ayuda Médica' in resources  # Spanish translation of Medical Aid
        
        # Should have high severity resources
        assert any('Critical' in res for res in resources) or any('Emergency' in res for res in resources)
        
        # Should have special needs resources
        assert any('Accesible' in res.lower() for res in resources) or any('Disability' in res for res in resources)
        
        # Should have child-specific resources
        assert any('Child' in res for res in resources) or any('Family' in res for res in resources)
        
        # Should have pet-specific resources
        assert any('Pet' in res for res in resources) or any('Animal' in res for res in resources)
        
        # Should have transportation resources (since transportation=False)
        assert any('Transport' in res for res in resources)
        
        # Verify high severity safety instructions
        assert any('LIFE-THREATENING' in instr for instr in data['safety_instructions'])
        
        # Verify evacuation routes
        assert 'primary_route' in data['evacuation_routes']
        assert 'secondary_route' in data['evacuation_routes']
        
        # Verify emergency contacts
        assert 'emergency_services' in data['emergency_contacts']
        assert 'shelter_coordination' in data['emergency_contacts']
    
    @pytest.mark.asyncio
    async def test_match_resources_validation(self, client):
        """Test validation of required parameters."""
        # Missing location
        response = client.post("/ai/match_resources", json={
            'crisis_type': 'flood'
        })
        assert response.status_code == 400
        
        # Missing crisis_type
        response = client.post("/ai/match_resources", json={
            'location': 'new york'
        })
        assert response.status_code == 400
        
        # Empty strings
        response = client.post("/ai/match_resources", json={
            'location': '',
            'crisis_type': 'flood'
        })
        assert response.status_code == 400
        
        response = client.post("/ai/match_resources", json={
            'location': 'new york',
            'crisis_type': ''
        })
        assert response.status_code == 400
    
    @pytest.mark.asyncio
    async def test_crowdsourced_reports_integration(self, client, mock_firebase):
        """Test integration of crowdsourced reports in resource matching."""
        # Define test data
        test_data = {
            'location': 'new york',  # Matches location in mock Firebase data
            'crisis_type': 'flood'
        }
        
        # Make the request
        response = client.post("/ai/match_resources", json=test_data)
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify crowdsourced reports were included
        assert 'crowdsourced_reports' in data
        assert len(data['crowdsourced_reports']) > 0
        
        # Verify matched resources include crowdsourced info
        resources = data['matched_resources']
        assert any('Crowdsourced Report' in res for res in resources)
    
    @pytest.mark.asyncio
    async def test_translate_text_function(self):
        """Test the translate_text function directly."""
        with patch('aiohttp.ClientSession') as mock_session:
            # Create mock session and response
            session_instance = MagicMock()
            mock_session.return_value.__aenter__.return_value = session_instance
            
            translate_response = AsyncMock()
            translate_response.json.return_value = {
                'data': {
                    'translations': [
                        {'translatedText': 'Hola'},
                        {'translatedText': 'Mundo'}
                    ]
                }
            }
            
            session_instance.post = AsyncMock(return_value=translate_response)
            
            # Test translation
            result = await translate_text(['Hello', 'World'], 'es')
            
            # Verify results
            assert result == ['Hola', 'Mundo']
            
            # Verify correct API call
            session_instance.post.assert_called_once()
            args, kwargs = session_instance.post.call_args
            assert 'translate' in args[0]
            assert kwargs['json']['target'] == 'es'
            assert kwargs['json']['q'] == ['Hello', 'World']
    
    @pytest.mark.asyncio
    async def test_translate_text_english(self):
        """Test that translate_text returns original text for English."""
        # No need for mocks when target language is English
        result = await translate_text(['Hello', 'World'], 'en')
        
        # Should return original text unchanged
        assert result == ['Hello', 'World']
    
    @pytest.mark.asyncio
    async def test_translate_text_error_handling(self):
        """Test error handling in translate_text function."""
        with patch('aiohttp.ClientSession') as mock_session:
            # Create mock session that raises an exception
            session_instance = MagicMock()
            mock_session.return_value.__aenter__.return_value = session_instance
            
            session_instance.post = AsyncMock(side_effect=Exception("API Error"))
            
            # Test translation with error
            text_list = ['Hello', 'World']
            result = await translate_text(text_list, 'fr')
            
            # Should return original text on error
            assert result == text_list


class TestSafetyInstructions:
    """Test safety instructions generator functionality."""
    
    def test_generate_safety_instructions_basic_crisis_types(self, client):
        """Test safety instructions for basic crisis types."""
        # Test a few common crisis types
        crisis_types = ['hurricane', 'earthquake', 'flood', 'wildfire', 'pandemic']
        
        for crisis_type in crisis_types:
            # Make a request for each crisis type
            response = client.post("/ai/match_resources", json={
                'location': 'test city',
                'crisis_type': crisis_type
            })
            
            # Check response
            assert response.status_code == 200
            data = response.json()
            
            # Verify safety instructions
            assert 'safety_instructions' in data
            instructions = data['safety_instructions']
            
            # Check that we have reasonable number of instructions
            assert len(instructions) >= 4
            
            # Check that instructions are relevant to the crisis type
            if crisis_type == 'hurricane':
                assert any('windows' in instr.lower() for instr in instructions)
                assert any('evacuat' in instr.lower() for instr in instructions)
            
            elif crisis_type == 'earthquake':
                assert any('drop' in instr.lower() for instr in instructions)
                assert any('cover' in instr.lower() for instr in instructions)
            
            elif crisis_type == 'flood':
                assert any('water' in instr.lower() for instr in instructions)
                assert any('higher ground' in instr.lower() for instr in instructions)
            
            elif crisis_type == 'wildfire':
                assert any('evacuat' in instr.lower() for instr in instructions)
                assert any('smoke' in instr.lower() for instr in instructions)
            
            elif crisis_type == 'pandemic':
                assert any('health' in instr.lower() for instr in instructions)
                assert any('distance' in instr.lower() for instr in instructions)
    
    def test_generate_safety_instructions_severity_levels(self, client):
        """Test safety instructions with different severity levels."""
        # Test with different severity levels
        severity_levels = ['low', 'medium', 'high']
        
        for severity in severity_levels:
            # Make a request with the severity level
            response = client.post("/ai/match_resources", json={
                'location': 'test city',
                'crisis_type': 'flood',
                'severity': severity
            })
            
            # Check response
            assert response.status_code == 200
            data = response.json()
            
            # Verify safety instructions
            instructions = data['safety_instructions']
            
            if severity == 'high':
                # High severity should have urgent language
                assert any('LIFE-THREATENING' in instr for instr in instructions)
                assert any('IMMEDIATE' in instr for instr in instructions)
            
            elif severity == 'low':
                # Low severity should be more cautious/monitoring
                assert any('alert' in instr.lower() for instr in instructions)
                assert any('monitor' in instr.lower() for instr in instructions)
            
            # All severity levels should have basic instructions
            assert any('water' in instr.lower() for instr in instructions)
    
    def test_generate_safety_instructions_unknown_crisis(self, client):
        """Test safety instructions for unknown crisis types."""
        # Make a request with an unknown crisis type
        response = client.post("/ai/match_resources", json={
            'location': 'test city',
            'crisis_type': 'unknown_crisis_type'
        })
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify default safety instructions
        instructions = data['safety_instructions']
        
        # Should have reasonable number of instructions
        assert len(instructions) >= 3
        
        # Should have generic safety advice
        assert any('emergency' in instr.lower() for instr in instructions)
        assert any('supplies' in instr.lower() for instr in instructions)


class TestEvacuationAndEmergencyContacts:
    """Test evacuation routes and emergency contacts functionality."""
    
    def test_get_evacuation_routes(self, client):
        """Test evacuation routes generation."""
        # Make request for different crisis types
        crisis_types = ['flood', 'wildfire', 'hurricane']
        
        for crisis_type in crisis_types:
            response = client.post("/ai/match_resources", json={
                'location': 'test city',
                'crisis_type': crisis_type
            })
            
            # Check response
            assert response.status_code == 200
            data = response.json()
            
            # Verify evacuation routes
            routes = data['evacuation_routes']
            
            # Check route types
            assert 'primary_route' in routes
            assert 'secondary_route' in routes
            assert 'walking_route' in routes
            assert 'public_transportation' in routes
            assert 'special_needs_transportation' in routes
            
            # Check content
            assert len(routes['primary_route']) > 10
            assert len(routes['secondary_route']) > 10
    
    def test_get_emergency_contacts(self, client):
        """Test emergency contacts generation."""
        # Make request for different locations
        locations = ['new york', 'los angeles', 'chicago']
        
        for location in locations:
            response = client.post("/ai/match_resources", json={
                'location': location,
                'crisis_type': 'flood'
            })
            
            # Check response
            assert response.status_code == 200
            data = response.json()
            
            # Verify emergency contacts
            contacts = data['emergency_contacts']
            
            # Check contact types
            assert 'emergency_services' in contacts
            assert 'local_emergency_management' in contacts
            assert 'shelter_coordination' in contacts
            assert 'medical_emergency' in contacts
            assert 'poison_control' in contacts
            
            # Check consistency
            assert contacts['emergency_services'] == '911'  # Should be standard in US
            assert contacts['poison_control'] == '1-800-222-1222'  # Standard US poison control


class TestWeatherAndEnvironmentalData:
    """Test weather and environmental data functionality."""
    
    def test_weather_data_integration(self, client):
        """Test weather data in resource matching."""
        # Make the request
        response = client.post("/ai/match_resources", json={
            'location': 'new york',
            'crisis_type': 'flood'
        })
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify weather data
        assert 'weather_data' in data
        weather = data['weather_data']
        
        # Check weather fields
        assert 'current_conditions' in weather
        assert 'temperature' in weather
        assert 'wind_speed' in weather
        assert 'precipitation_chance' in weather
        assert 'alerts' in weather
        
        # Check types
        assert isinstance(weather['temperature'], int)
        assert isinstance(weather['wind_speed'], int)
        assert isinstance(weather['precipitation_chance'], int)
        assert isinstance(weather['alerts'], list)
    
    def test_environmental_data_integration(self, client):
        """Test environmental data in resource matching."""
        # Make the request
        response = client.post("/ai/match_resources", json={
            'location': 'new york',
            'crisis_type': 'chemical_spill'  # Environmental crisis
        })
        
        # Check response
        assert response.status_code == 200
        data = response.json()
        
        # Verify environmental data
        assert 'environmental_data' in data
        env_data = data['environmental_data']
        
        # Check environmental fields
        assert 'air_quality_index' in env_data
        assert 'water_safety' in env_data
        assert 'hazardous_materials' in env_data
        
        # Check types
        assert isinstance(env_data['air_quality_index'], int)
        assert isinstance(env_data['water_safety'], str)
        assert isinstance(env_data['hazardous_materials'], list)


class TestCrisisPrediction:
    """Test crisis prediction functionality."""
    
    def test_crisis_prediction_integration(self, client):
        """Test crisis prediction in resource matching."""
        # Test for different severity levels
        severity_levels = ['low', 'medium', 'high']
        
        for severity in severity_levels:
            # Make the request
            response = client.post("/ai/match_resources", json={
                'location': 'new york',
                'crisis_type': 'flood',
                'severity': severity
            })
            
            # Check response
            assert response.status_code == 200
            data = response.json()
            
            # Verify crisis prediction
            assert 'crisis_prediction' in data
            prediction = data['crisis_prediction']
            
            # Check prediction fields
            assert 'expected_duration' in prediction
            assert 'trend' in prediction
            assert 'confidence' in prediction
            assert 'next_48_hours' in prediction
            
            # Check severity correlation with trend
            if severity == 'high':
                assert prediction['trend'] == 'worsening'
            else:
                assert prediction['trend'] == 'stabilizing'
            
            # Check types
            assert isinstance(prediction['expected_duration'], str)
            assert isinstance(prediction['confidence'], float)
            assert 0 <= prediction['confidence'] <= 1  # Confidence should be between 0 and 1


if __name__ == '__main__':
    pytest.main()